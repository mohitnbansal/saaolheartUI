(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customer-search-customer-search-module"],{

/***/ "./src/app/pages/customer/customer-search/customer-search.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/customer/customer-search/customer-search.module.ts ***!
  \**************************************************************************/
/*! exports provided: CustomerSearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerSearchPageModule", function() { return CustomerSearchPageModule; });
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _customer_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./customer-search.page */ "./src/app/pages/customer/customer-search/customer-search.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        component: _customer_search_page__WEBPACK_IMPORTED_MODULE_6__["CustomerSearchPage"]
    }
];
var CustomerSearchPageModule = /** @class */ (function () {
    function CustomerSearchPageModule() {
    }
    CustomerSearchPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__["NgxDatatableModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_customer_search_page__WEBPACK_IMPORTED_MODULE_6__["CustomerSearchPage"]]
        })
    ], CustomerSearchPageModule);
    return CustomerSearchPageModule;
}());



/***/ }),

/***/ "./src/app/pages/customer/customer-search/customer-search.page.html":
/*!**************************************************************************!*\
  !*** ./src/app/pages/customer/customer-search/customer-search.page.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\r\n    <ion-toolbar>\r\n        <ion-title>customer-search</ion-title>\r\n    </ion-toolbar>\r\n</ion-header> -->\r\n\r\n<ion-content padding>\r\n    <ion-card>\r\n        <ion-card-header>\r\n            <ion-card-title>\r\n                Search Customer\r\n            </ion-card-title>\r\n            <ion-card-subtitle>\r\n                Registered Only Customer\r\n            </ion-card-subtitle>\r\n        </ion-card-header>\r\n        <ion-card-content>\r\n            <!-- Animated Searchbar -->\r\n\r\n            <ion-searchbar (ionInput)=\"getCustomerListBySearch($event)\" animated showCancelButton cancelButtonText=\"Custom Cancel\"></ion-searchbar>\r\n            <ngx-datatable #myTable class='material' [columnMode]=\"'standard'\" [headerHeight]=\"50\"\r\n             [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"50\" \r\n            limit=\"10\" [scrollbarV]=\"'true'\" [scrollbarH]=\"'true'\" [rows]='rows' (page)=\"onPage($event)\">\r\n                <!-- Row Detail Template -->\r\n                <ngx-datatable-row-detail [rowHeight]=\"getHeight()\" #myDetailRow>\r\n                    <ng-template let-row=\"row\" let-rowIndex=\"rowIndex\" ngx-datatable-row-detail-template>\r\n                        <div><strong>Address</strong></div>\r\n                        <div class=\"row-wrap\">{{row.address}}</div>\r\n                    </ng-template>\r\n                </ngx-datatable-row-detail>\r\n                <!-- Column Templates -->\r\n                <ngx-datatable-column [width]=\"50\">\r\n                    <ng-template let-row=\"row\" let-expanded=\"expanded\" ngx-datatable-cell-template>\r\n                        <a href=\"javascript:void(0)\" [class.datatable-icon-right]=\"!expanded\" [class.datatable-icon-down]=\"expanded\" title=\"Expand/Collapse Row\" (click)=\"toggleExpandRow(row,expanded)\">\r\n                        </a>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Sr No\" width=\"80\">\r\n                    <ng-template let-rowIndex=\"rowIndex\" let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{rowIndex+1}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Customer Id\" width=\"180\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <a [routerDirection]=\"'forward'\" [routerLink]=\"['/customer/details/',row.id]\">\r\n                            <b><i> {{row.customerRefId}}  </i></b>\r\n                        </a>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Name\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.firstName}} {{row.lastName}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Age\" width=\"50\">\r\n                    <ng-template let-value=\"value\" ngx-datatable-cell-template>\r\n                        <strong>{{value}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Gender\" width=\"75\">\r\n                    <ng-template let-value=\"value\" ngx-datatable-cell-template>\r\n                        <strong>{{value}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Email Id\" width=\"100\">\r\n                    <ng-template let-value=\"value\" ngx-datatable-cell-template>\r\n                        <strong>{{value}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Mobile No\" width=\"100\">\r\n                    <ng-template let-value=\"value\" ngx-datatable-cell-template>\r\n                        <strong>{{value}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Alt Mobile No\" width=\"100\">\r\n                    <ng-template let-value=\"value\" ngx-datatable-cell-template>\r\n                        <strong>{{value}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Added On (Date and Time) \" width=\"300\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.dateOfCreation | date : 'MMM d, y, h:mm:ss a' }} </strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n            </ngx-datatable>\r\n\r\n        </ion-card-content>\r\n    </ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/customer/customer-search/customer-search.page.scss":
/*!**************************************************************************!*\
  !*** ./src/app/pages/customer/customer-search/customer-search.page.scss ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ngx-datatable,\n.info {\n  text-align: left;\n  width: 98% !important;\n  margin: 0 auto; }\n\ndatatable-scroller {\n  width: 100% !important; }\n\n.row-wrap {\n  white-space: pre-wrap; }\n\n:host /deep/ .datatable-row-group {\n  will-change: transform; }\n\n:host /deep/ .ngx-datatable.material .datatable-header .datatable-row-right {\n  margin-left: -8px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY3VzdG9tZXIvY3VzdG9tZXItc2VhcmNoL0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXHBhZ2VzXFxjdXN0b21lclxcY3VzdG9tZXItc2VhcmNoXFxjdXN0b21lci1zZWFyY2gucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFJOztFQUVJLGlCQUFnQjtFQUNoQixzQkFBcUI7RUFDckIsZUFBYyxFQUNqQjs7QUFFRDtFQUNJLHVCQUFzQixFQUN6Qjs7QUFFRDtFQUNJLHNCQUNKLEVBQUM7O0FBRUE7RUFDRyx1QkFBc0IsRUFDekI7O0FBRUE7RUFDRyxrQkFBaUIsRUFDcEIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9jdXN0b21lci9jdXN0b21lci1zZWFyY2gvY3VzdG9tZXItc2VhcmNoLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiAgICAubmd4LWRhdGF0YWJsZSxcclxuICAgIC5pbmZvIHtcclxuICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICAgIHdpZHRoOiA5OCUgIWltcG9ydGFudDtcclxuICAgICAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIH1cclxuICAgIFxyXG4gICAgZGF0YXRhYmxlLXNjcm9sbGVyIHtcclxuICAgICAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAucm93LXdyYXAge1xyXG4gICAgICAgIHdoaXRlLXNwYWNlOiBwcmUtd3JhcFxyXG4gICAgfVxyXG4gICAgXHJcbiAgICAgOmhvc3QgL2RlZXAvIC5kYXRhdGFibGUtcm93LWdyb3VwIHtcclxuICAgICAgICB3aWxsLWNoYW5nZTogdHJhbnNmb3JtO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAgOmhvc3QgL2RlZXAvIC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LXJpZ2h0IHtcclxuICAgICAgICBtYXJnaW4tbGVmdDogLThweDtcclxuICAgIH0iXX0= */"

/***/ }),

/***/ "./src/app/pages/customer/customer-search/customer-search.page.ts":
/*!************************************************************************!*\
  !*** ./src/app/pages/customer/customer-search/customer-search.page.ts ***!
  \************************************************************************/
/*! exports provided: CustomerSearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerSearchPage", function() { return CustomerSearchPage; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var CustomerSearchPage = /** @class */ (function () {
    function CustomerSearchPage(custService, activate) {
        this.custService = custService;
        this.activate = activate;
        this.selected = [];
        this.tablestyle = 'bootstrap';
        var list = this.activate.snapshot.data['list'];
        if (list != null) {
            this.setDatatable(list);
            this.rows = this.rows.slice();
        }
    }
    CustomerSearchPage.prototype.onPage = function (event) {
        // clearTimeout(this.timeout);
        // this.timeout = setTimeout(() => {
        //   console.log('paged!', event);
        // }, 100);
    };
    CustomerSearchPage.prototype.getHeight = function () {
        return 150;
    };
    CustomerSearchPage.prototype.getCustomerListBySearch = function (event) {
        var val = event.target.value.toLowerCase();
        // get the amount of columns in the table
        var colsAmt = this.columns.length;
        // get the key names of each column in the dataset
        var keys = Object.keys(this.customerList[0]);
        // assign filtered matches to the active datatable
        this.rows = this.customerList.filter(function (item) {
            // iterate through each row's column data
            for (var i = 0; i < colsAmt; i++) {
                // check for a match
                if (item[keys[i]] != null) {
                    if (item[keys[i]].toString().toLowerCase().indexOf(val) !== -1 || !val) {
                        // found match, return true to add to result set
                        return true;
                    }
                }
            }
        });
    };
    CustomerSearchPage.prototype.ngOnInit = function () {
        var _this = this;
        this.custService.getAllCustomerSortedList().subscribe(function (res) {
            _this.setDatatable(res);
            _this.rows = _this.rows.slice();
        }, function (err) {
            console.log(err);
        });
    };
    CustomerSearchPage.prototype.setDatatable = function (res) {
        this.customerList = res;
        this.rows = res;
        this.columns = Object.keys(res[0]).map(function (key) {
            return {
                'prop': key
            };
        });
    };
    CustomerSearchPage.prototype.toggleExpandRow = function (row, expanded) {
        if (expanded !== true) {
            this.table.rowDetail.collapseAllRows();
        }
        this.table.rowDetail.toggleExpandRow(row);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])('myTable'),
        __metadata("design:type", _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_3__["DatatableComponent"])
    ], CustomerSearchPage.prototype, "table", void 0);
    CustomerSearchPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-customer-search',
            template: __webpack_require__(/*! ./customer-search.page.html */ "./src/app/pages/customer/customer-search/customer-search.page.html"),
            styles: [__webpack_require__(/*! ./customer-search.page.scss */ "./src/app/pages/customer/customer-search/customer-search.page.scss")]
        }),
        __metadata("design:paramtypes", [_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_1__["CustomerService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_0__["ActivatedRoute"]])
    ], CustomerSearchPage);
    return CustomerSearchPage;
}());



/***/ })

}]);
//# sourceMappingURL=customer-search-customer-search-module.js.map