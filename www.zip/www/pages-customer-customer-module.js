(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-customer-customer-module"],{

/***/ "./src/app/pages/customer/customer-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/customer/customer-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: CustomerRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerRoutingModule", function() { return CustomerRoutingModule; });
/* harmony import */ var _services_customer_customer_list_resolve_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/customer/customer-list-resolve.service */ "./src/app/services/customer/customer-list-resolve.service.ts");
/* harmony import */ var _services_master_invoice_master_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/master/invoice-master.service */ "./src/app/services/master/invoice-master.service.ts");
/* harmony import */ var _customer_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./customer.page */ "./src/app/pages/customer/customer.page.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_customer_customer_details_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/customer/customer-details.service */ "./src/app/services/customer/customer-details.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _customer_page__WEBPACK_IMPORTED_MODULE_2__["CustomerPage"],
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'search'
            },
            {
                path: 'details',
                children: [
                    {
                        path: '',
                        loadChildren: './customer-details/customer-details.module#CustomerDetailsPageModule'
                    },
                    {
                        path: ':id',
                        loadChildren: './customer-details/customer-details.module#CustomerDetailsPageModule',
                        resolve: {
                            data: src_app_services_customer_customer_details_service__WEBPACK_IMPORTED_MODULE_5__["CustomerDetailsService"],
                            invoiceType: _services_master_invoice_master_service__WEBPACK_IMPORTED_MODULE_1__["InvoiceMasterService"]
                        }
                    }
                ]
            },
            { path: 'register',
                children: [
                    {
                        path: '',
                        loadChildren: './customer-registration/customer-registration.module#CustomerRegistrationPageModule'
                    },
                    {
                        path: ':id',
                        loadChildren: './customer-registration/customer-registration.module#CustomerRegistrationPageModule',
                        resolve: {
                            data: src_app_services_customer_customer_details_service__WEBPACK_IMPORTED_MODULE_5__["CustomerDetailsService"],
                        }
                    }
                ]
            },
            {
                path: 'search', loadChildren: './customer-search/customer-search.module#CustomerSearchPageModule',
                resolve: {
                    list: _services_customer_customer_list_resolve_service__WEBPACK_IMPORTED_MODULE_0__["CustomerListResolveService"]
                }
            }
        ]
    }
];
var CustomerRoutingModule = /** @class */ (function () {
    function CustomerRoutingModule() {
    }
    CustomerRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]]
        })
    ], CustomerRoutingModule);
    return CustomerRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/customer/customer.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/customer/customer.module.ts ***!
  \***************************************************/
/*! exports provided: CustomerPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerPageModule", function() { return CustomerPageModule; });
/* harmony import */ var src_app_services_customer_customer_details_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/customer/customer-details.service */ "./src/app/services/customer/customer-details.service.ts");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _customer_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./customer.page */ "./src/app/pages/customer/customer.page.ts");
/* harmony import */ var _customer_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./customer-routing.module */ "./src/app/pages/customer/customer-routing.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var CustomerPageModule = /** @class */ (function () {
    function CustomerPageModule() {
    }
    CustomerPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            entryComponents: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                src_app_components_component_module__WEBPACK_IMPORTED_MODULE_2__["ComponentModule"],
                _customer_routing_module__WEBPACK_IMPORTED_MODULE_8__["CustomerRoutingModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_1__["NgxDatatableModule"]
            ],
            providers: [src_app_services_customer_customer_details_service__WEBPACK_IMPORTED_MODULE_0__["CustomerDetailsService"]],
            declarations: [_customer_page__WEBPACK_IMPORTED_MODULE_7__["CustomerPage"]]
        })
    ], CustomerPageModule);
    return CustomerPageModule;
}());



/***/ }),

/***/ "./src/app/pages/customer/customer.page.html":
/*!***************************************************!*\
  !*** ./src/app/pages/customer/customer.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\r\n\r\n<ion-content padding>\r\n    <ng-container>\r\n\r\n    </ng-container>\r\n    <ng-template>\r\n        <ion-card>\r\n            <ion-router-outlet></ion-router-outlet>\r\n        </ion-card>\r\n\r\n    </ng-template>\r\n\r\n    <ion-tabs>\r\n        <ion-tab-bar slot=\"top\">\r\n            <ion-tab-button tab=\"register\">\r\n                <ion-icon name=\"person-add\"></ion-icon>\r\n                <ion-label>Add Customers</ion-label>\r\n\r\n            </ion-tab-button>\r\n\r\n            <ion-tab-button tab=\"search\">\r\n                <ion-icon name=\"search\"></ion-icon>\r\n                <ion-label>Search/Update</ion-label>\r\n            </ion-tab-button>\r\n\r\n            <ion-tab-button tab=\"details\">\r\n                <ion-icon name=\"grid\"></ion-icon>\r\n                <ion-label>Request</ion-label>\r\n            </ion-tab-button>\r\n\r\n        </ion-tab-bar>\r\n    </ion-tabs>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/customer/customer.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/customer/customer.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2N1c3RvbWVyL2N1c3RvbWVyLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/customer/customer.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/customer/customer.page.ts ***!
  \*************************************************/
/*! exports provided: CustomerPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerPage", function() { return CustomerPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CustomerPage = /** @class */ (function () {
    function CustomerPage() {
        this.isLoggedIn = true;
    }
    CustomerPage.prototype.ngOnInit = function () {
    };
    CustomerPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-customer',
            template: __webpack_require__(/*! ./customer.page.html */ "./src/app/pages/customer/customer.page.html"),
            styles: [__webpack_require__(/*! ./customer.page.scss */ "./src/app/pages/customer/customer.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], CustomerPage);
    return CustomerPage;
}());



/***/ }),

/***/ "./src/app/services/customer/customer-details.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/services/customer/customer-details.service.ts ***!
  \***************************************************************/
/*! exports provided: CustomerDetailsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerDetailsService", function() { return CustomerDetailsService; });
/* harmony import */ var _customer_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CustomerDetailsService = /** @class */ (function () {
    function CustomerDetailsService(custService) {
        this.custService = custService;
    }
    CustomerDetailsService.prototype.resolve = function (route, state) {
        var id = route.paramMap.get('id');
        return this.custService.getCustomerById(id);
    };
    CustomerDetailsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_customer_service__WEBPACK_IMPORTED_MODULE_0__["CustomerService"]])
    ], CustomerDetailsService);
    return CustomerDetailsService;
}());



/***/ }),

/***/ "./src/app/services/customer/customer-list-resolve.service.ts":
/*!********************************************************************!*\
  !*** ./src/app/services/customer/customer-list-resolve.service.ts ***!
  \********************************************************************/
/*! exports provided: CustomerListResolveService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerListResolveService", function() { return CustomerListResolveService; });
/* harmony import */ var _customer_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CustomerListResolveService = /** @class */ (function () {
    function CustomerListResolveService(custService) {
        this.custService = custService;
    }
    CustomerListResolveService.prototype.resolve = function (route, state) {
        return this.custService.getAllCustomerSortedList();
    };
    CustomerListResolveService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_customer_service__WEBPACK_IMPORTED_MODULE_0__["CustomerService"]])
    ], CustomerListResolveService);
    return CustomerListResolveService;
}());



/***/ }),

/***/ "./src/app/services/master/invoice-master.service.ts":
/*!***********************************************************!*\
  !*** ./src/app/services/master/invoice-master.service.ts ***!
  \***********************************************************/
/*! exports provided: InvoiceMasterService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoiceMasterService", function() { return InvoiceMasterService; });
/* harmony import */ var _master_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./master.service */ "./src/app/services/master/master.service.ts");
/* harmony import */ var _customer_customer_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var InvoiceMasterService = /** @class */ (function () {
    function InvoiceMasterService(custService, masterservice) {
        this.custService = custService;
        this.masterservice = masterservice;
    }
    InvoiceMasterService.prototype.resolve = function (route, state) {
        return this.masterservice.getAllInvoiceMasterTypes();
    };
    InvoiceMasterService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_customer_customer_service__WEBPACK_IMPORTED_MODULE_1__["CustomerService"],
            _master_service__WEBPACK_IMPORTED_MODULE_0__["MasterService"]])
    ], InvoiceMasterService);
    return InvoiceMasterService;
}());



/***/ }),

/***/ "./src/app/services/master/master.service.ts":
/*!***************************************************!*\
  !*** ./src/app/services/master/master.service.ts ***!
  \***************************************************/
/*! exports provided: MasterService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MasterService", function() { return MasterService; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment_prod__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment.prod */ "./src/environments/environment.prod.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var MasterService = /** @class */ (function () {
    function MasterService(http) {
        this.http = http;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        };
    }
    MasterService.prototype.getAllInvoiceMasterTypes = function () {
        console.log(src_environments_environment_prod__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl);
        return this.http.get(src_environments_environment_prod__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'master/invoicemaster', this.httpOptions);
    };
    MasterService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]])
    ], MasterService);
    return MasterService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-customer-customer-module.js.map