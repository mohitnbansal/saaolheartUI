(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-sales-search-sales-module"],{

/***/ "./src/app/pages/sales/search-sales/search-sales.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/sales/search-sales/search-sales.module.ts ***!
  \*****************************************************************/
/*! exports provided: SearchSalesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchSalesPageModule", function() { return SearchSalesPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _search_sales_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./search-sales.page */ "./src/app/pages/sales/search-sales/search-sales.page.ts");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        component: _search_sales_page__WEBPACK_IMPORTED_MODULE_5__["SearchSalesPage"]
    }
];
var SearchSalesPageModule = /** @class */ (function () {
    function SearchSalesPageModule() {
    }
    SearchSalesPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_6__["NgxDatatableModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_search_sales_page__WEBPACK_IMPORTED_MODULE_5__["SearchSalesPage"]]
        })
    ], SearchSalesPageModule);
    return SearchSalesPageModule;
}());



/***/ }),

/***/ "./src/app/pages/sales/search-sales/search-sales.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/pages/sales/search-sales/search-sales.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\r\n    <ion-toolbar>\r\n        <ion-title>customer-search</ion-title>\r\n    </ion-toolbar>\r\n</ion-header> -->\r\n\r\n<ion-content padding>\r\n    <ion-card>\r\n        <ion-card-header>\r\n            <ion-card-title>\r\n                 Search Sales By Customer\r\n            </ion-card-title>\r\n            <ion-card-subtitle>\r\n                Registered Only Customer\r\n            </ion-card-subtitle>\r\n        </ion-card-header>\r\n        <ion-card-content>\r\n            <!-- Animated Searchbar -->\r\n\r\n            <ion-searchbar (ionInput)=\"updateFilter($event)\" animated showCancelButton cancelButtonText=\"Custom Cancel\"></ion-searchbar>\r\n            <ngx-datatable #myTable class='material' [columnMode]=\"'standard'\" [headerHeight]=\"50\" [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"50\" [scrollbarV]=\"'true'\" [scrollbarH]=\"'true'\" [rows]='rows' >\r\n\r\n                <ngx-datatable-column name=\"Sr No\" width=\"80\">\r\n                    <ng-template let-rowIndex=\"rowIndex\" let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{rowIndex+1}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Customer Name\" width=\"180\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <a [routerDirection]=\"'forward'\" [routerLink]=\"['/sales/salesdetails/',row.id]\">\r\n                            <b><i> {{row.customerName}}  </i></b>\r\n                        </a>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Id\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.invoiceOfPurchase.id}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Customer Id\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.invoiceOfPurchase.customerId}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Amount\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.invoiceOfPurchase.totalInvoiceAmt}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Generated By\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.invoiceOfPurchase.generetedByName}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Date\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.invoiceOfPurchase.createdDate | date : 'MMM d, y, h:mm:ss a'}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                \r\n\r\n\r\n            </ngx-datatable>\r\n\r\n        </ion-card-content>\r\n    </ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/sales/search-sales/search-sales.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/pages/sales/search-sales/search-sales.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NhbGVzL3NlYXJjaC1zYWxlcy9zZWFyY2gtc2FsZXMucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/sales/search-sales/search-sales.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/sales/search-sales/search-sales.page.ts ***!
  \***************************************************************/
/*! exports provided: SearchSalesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchSalesPage", function() { return SearchSalesPage; });
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var SearchSalesPage = /** @class */ (function () {
    function SearchSalesPage(activate) {
        this.activate = activate;
        this.rows = [];
        this.columns = [];
        this.temp = [];
        this.salesList = this.activate.snapshot.data['dataList'];
        if (this.salesList.document !== null) {
            this.temp = this.salesList.document.slice();
        }
        // push our inital complete list
        this.rows = this.salesList.document;
    }
    SearchSalesPage.prototype.updateFilter = function (event) {
        var val = event.target.value.toLowerCase();
        // filter our data
        var temp = this.temp.filter(function (d) {
            return d.customerName.toLowerCase().indexOf(val) !== -1 || !val;
        });
        // update the rows
        this.rows = temp;
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
    };
    SearchSalesPage.prototype.ngOnInit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewChild"])(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__["DatatableComponent"]),
        __metadata("design:type", _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__["DatatableComponent"])
    ], SearchSalesPage.prototype, "table", void 0);
    SearchSalesPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-search-sales',
            template: __webpack_require__(/*! ./search-sales.page.html */ "./src/app/pages/sales/search-sales/search-sales.page.html"),
            styles: [__webpack_require__(/*! ./search-sales.page.scss */ "./src/app/pages/sales/search-sales/search-sales.page.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"]])
    ], SearchSalesPage);
    return SearchSalesPage;
}());



/***/ })

}]);
//# sourceMappingURL=search-sales-search-sales-module.js.map