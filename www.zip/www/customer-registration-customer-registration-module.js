(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customer-registration-customer-registration-module"],{

/***/ "./src/app/pages/customer/customer-registration/customer-registration.module.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/customer/customer-registration/customer-registration.module.ts ***!
  \**************************************************************************************/
/*! exports provided: CustomerRegistrationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerRegistrationPageModule", function() { return CustomerRegistrationPageModule; });
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../pipes/pipes.module */ "./src/app/pipes/pipes.module.ts");
/* harmony import */ var ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ng-pick-datetime/dialog */ "./node_modules/ng-pick-datetime/dialog/index.js");
/* harmony import */ var ng_pick_datetime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng-pick-datetime */ "./node_modules/ng-pick-datetime/picker.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _customer_registration_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./customer-registration.page */ "./src/app/pages/customer/customer-registration/customer-registration.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var routes = [
    {
        path: '',
        component: _customer_registration_page__WEBPACK_IMPORTED_MODULE_8__["CustomerRegistrationPage"]
    }
];
var CustomerRegistrationPageModule = /** @class */ (function () {
    function CustomerRegistrationPageModule() {
    }
    CustomerRegistrationPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_2__["OwlDateTimeModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_2__["OwlNativeDateTimeModule"],
                ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_1__["OwlDialogModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"].forChild(routes),
                _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_0__["PipesModule"]
            ],
            declarations: [_customer_registration_page__WEBPACK_IMPORTED_MODULE_8__["CustomerRegistrationPage"]],
            exports: [_customer_registration_page__WEBPACK_IMPORTED_MODULE_8__["CustomerRegistrationPage"]],
            providers: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]]
        })
    ], CustomerRegistrationPageModule);
    return CustomerRegistrationPageModule;
}());



/***/ }),

/***/ "./src/app/pages/customer/customer-registration/customer-registration.page.html":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/customer/customer-registration/customer-registration.page.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header size=\"2\">\r\n    <ion-toolbar>\r\n        <ion-title>Customer Registration</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n    <ion-card>\r\n        <ion-card-header color=\"secondary\">\r\n            <ion-card-title>\r\n\r\n                <b> Personal Details</b>\r\n\r\n            </ion-card-title>\r\n            <ion-card-subtitle>\r\n                Fill in the details to registor\r\n            </ion-card-subtitle>\r\n\r\n        </ion-card-header>\r\n\r\n        <ion-card-content>\r\n            <form [formGroup]=\"custformGroup\" (ngSubmit)=\"onSubmit()\">\r\n                <ion-grid>\r\n                    <ion-row>\r\n                        <ion-col>\r\n                            <ion-grid>\r\n                                <ion-row>\r\n                                    <ion-col size=\"6\">\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Customer Type</ion-label>\r\n                                            <ion-select formControlName=\"vistingFor\" [interfaceOptions]=\"customPopover\" interface=\"popover\" placeholder=\"Select\">\r\n                                                <ion-select-option value=\"store\">Products</ion-select-option>\r\n                                                <ion-select-option value=\"treatment\">Treatment</ion-select-option>\r\n                                            </ion-select>\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['vistingFor'].errors && custformGroup.controls['vistingFor'].dirty\" color=\"danger\" padding>Please Select Type Of Customer.</ion-text>\r\n\r\n                                    </ion-col>\r\n                                </ion-row>\r\n                                <ion-row>\r\n                                    <ion-col>\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">First Name</ion-label>\r\n                                            <ion-input [value]=\"custformGroup.controls['firstName'].value  | uppercase\"  type=\"text\" formControlName=\"firstName\" id=\"firstName\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['firstName'].errors && custformGroup.controls['firstName'].dirty\" color=\"danger\" padding>Please Enter First Name.</ion-text>\r\n\r\n                                    </ion-col>\r\n                                    <ion-col>\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Middle Name</ion-label>\r\n                                            <ion-input   [value]=\"custformGroup.controls['middleName'].value  | uppercase\"  type=\"text\" formControlName=\"middleName\" id=\"middleName\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                    </ion-col>\r\n                                    <ion-col>\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Last Name</ion-label>\r\n                                            <ion-input [value]=\"custformGroup.controls['lastName'].value  | uppercase\" type=\"text\" formControlName=\"lastName\" id=\"lastName\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['lastName'].errors && custformGroup.controls['lastName'].dirty\" color=\"danger\" padding>Please Enter Last Name.</ion-text>\r\n\r\n                                    </ion-col>\r\n                                </ion-row>\r\n                                <ion-row>\r\n                                    <ion-col>\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Email Id</ion-label>\r\n                                            <ion-input type=\"email\" formControlName=\"emailId\" id=\"emailId\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['emailId'].errors && custformGroup.controls['emailId'].dirty\" color=\"danger\" padding>Email is not valid.</ion-text>\r\n\r\n                                    </ion-col>\r\n                                    <ion-col *ngIf=\"showHide\">\r\n                                        <ion-item>\r\n                                            <ion-label position=\"stacked\" >Date of Birth</ion-label>\r\n                                            <!-- <ion-datetime formControlName=\"dob\" id=\"dob\" display-format=\"MMM DD, YYYY\"></ion-datetime> -->\r\n                                            <input  [(ngModel)]=\"dob\"  class=\"ion-input\" [owlDateTime]=\"dt1\" id=\"consulatationDate\"  formControlName=\"dob\"   [owlDateTimeTrigger]=\"dt1\" placeholder=\"Date Time\"/>\r\n                                            <owl-date-time  #dt1 hour12Timer=\"true\" stepHour=\"1\" pickerType=\"calendar\" stepMinute=\"30\"> </owl-date-time>\r\n                                    \r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['dob'].errors && custformGroup.controls['dob'].dirty\" color=\"danger\" padding>Please Input Date of birth.</ion-text>\r\n\r\n                                    </ion-col>\r\n                                    <ion-col *ngIf=\"showHide\">\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Age</ion-label>\r\n                                            <ion-input name=\"age\" formControlName=\"age\" type=\"text\" readonly=\"true\" id=\"age\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n\r\n                                    </ion-col>\r\n                                </ion-row>\r\n                                <ion-row>\r\n                                    <ion-col *ngIf=\"showHide\">\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Gender</ion-label>\r\n                                            <ion-select formControlName=\"gender\" interface=\"popover\" id=\"gender\" placeholder=\"Select\">\r\n                                                <ion-select-option value=\"male\">Male</ion-select-option>\r\n                                                <ion-select-option value=\"female\">Female</ion-select-option>\r\n                                                <ion-select-option value=\"others\">Others</ion-select-option>\r\n                                            </ion-select>\r\n\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['gender'].errors && custformGroup.controls['gender'].dirty\" color=\"danger\" padding>Please Select Gender.</ion-text>\r\n\r\n                                    </ion-col>\r\n                                    <ion-col *ngIf=\"showHide\">\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Occupation</ion-label>\r\n                                            <ion-input type=\"text\" formControlName=\"occupation\" id=\"occupation\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['occupation'].errors && custformGroup.controls['occupation'].dirty\" color=\"danger\" padding>Please Input Occupation.</ion-text>\r\n                                    </ion-col>\r\n                                    <ion-col *ngIf=\"showHide\">\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Aadhar number</ion-label>\r\n                                            <ion-input  type=\"text\" maxlength=\"14\" [value]=\"custformGroup.controls['aadharNumber'].value  | aadharTranform\" formControlName=\"aadharNumber\" id=\"aadharNumber\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['aadharNumber'].errors && custformGroup.controls['aadharNumber'].dirty\" color=\"danger\" padding>Please Input Valid Aadhar Number.</ion-text>\r\n                                    </ion-col>\r\n                                </ion-row>\r\n                            </ion-grid>\r\n                        </ion-col>\r\n                        <!-- <ion-col>\r\n                            <ion-img style=\"width:50%;height:50%;\" src=\"https://picsum.photos/100\"></ion-img>\r\n                        </ion-col> -->\r\n                </ion-row>\r\n                    <ion-row>\r\n                        <ion-col>\r\n                            <ion-grid>\r\n                                <ion-row>\r\n                                    <ion-col *ngIf=\"showHide\">\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">PAN Number</ion-label>\r\n                                            <ion-input [value]=\"custformGroup.controls['panNumber'].value  | uppercase\" type=\"text\" formControlName=\"panNumber\" id=\"panNumber\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['panNumber'].errors && custformGroup.controls['panNumber'].dirty\" color=\"danger\" padding>Please Input Valid PAN Number.</ion-text>\r\n\r\n                                    </ion-col>\r\n\r\n                                </ion-row>\r\n                                <ion-row>\r\n                                    <ion-col>\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Mobile (Primary)</ion-label>\r\n                                            <ion-input type=\"text\" formControlName=\"mobileNo\" id=\"mobileNo\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                        <ion-text *ngIf=\"custformGroup.controls['mobileNo'].errors && custformGroup.controls['mobileNo'].dirty\" color=\"danger\" padding>Please Enter Mobile No.</ion-text>\r\n\r\n                                    </ion-col>\r\n                                    <ion-col *ngIf=\"showHide\">\r\n                                        <ion-item>\r\n                                            <ion-label position=\"floating\">Mobile (Alternate)</ion-label>\r\n                                            <ion-input type=\"text\" formControlName=\"altMobileNo\" id=\"altMobileNo\">\r\n                                            </ion-input>\r\n                                        </ion-item>\r\n                                    </ion-col>\r\n                                </ion-row>\r\n\r\n                            </ion-grid>\r\n                        </ion-col>\r\n                        <ion-col *ngIf=\"showHide\">\r\n                            <ion-item>\r\n                                <ion-label position=\"floating\">Address</ion-label>\r\n                                <ion-textarea rows=\"10\" type=\"text\" formControlName=\"address\" id=\"address\">\r\n                                </ion-textarea>\r\n                            </ion-item>\r\n                            <ion-text *ngIf=\"custformGroup.controls['address'].errors && custformGroup.controls['address'].dirty\" color=\"danger\" padding>Please Enter Address .</ion-text>\r\n\r\n                        </ion-col>\r\n                    </ion-row>\r\n\r\n                </ion-grid>\r\n                <ion-item>\r\n                    <ion-button *ngIf=\"customerDetails['id'] == null\" shape=\"round\" size=\"default\" slot=\"end\" type=\"submit\"  [disabled]=\"!custformGroup.valid\">\r\n                        <ion-icon size=\"default\" name=\"person-add\"></ion-icon> &nbsp; Add Customer</ion-button>\r\n                        <ion-button *ngIf=\"customerDetails['id'] != null\" shape=\"round\" size=\"default\" slot=\"end\" type=\"submit\"  [disabled]=\"!custformGroup.valid\">\r\n                                <ion-icon size=\"default\" name=\"person-add\"></ion-icon> &nbsp; Update Customer</ion-button>\r\n                    <ion-button shape=\"round\" size=\"default\" slot=\"end\" type=\"reset\">Reset</ion-button>\r\n\r\n                </ion-item>\r\n\r\n            </form>\r\n        </ion-card-content>\r\n    </ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/customer/customer-registration/customer-registration.page.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/customer/customer-registration/customer-registration.page.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host(.ng-invalid) {\n  --highlight-background: var(--highlight-color-invalid); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY3VzdG9tZXIvY3VzdG9tZXItcmVnaXN0cmF0aW9uL0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXHBhZ2VzXFxjdXN0b21lclxcY3VzdG9tZXItcmVnaXN0cmF0aW9uXFxjdXN0b21lci1yZWdpc3RyYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksdURBQXVCLEVBQ3hCIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY3VzdG9tZXIvY3VzdG9tZXItcmVnaXN0cmF0aW9uL2N1c3RvbWVyLXJlZ2lzdHJhdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCgubmctaW52YWxpZCkge1xyXG4gICAgLS1oaWdobGlnaHQtYmFja2dyb3VuZDogdmFyKC0taGlnaGxpZ2h0LWNvbG9yLWludmFsaWQpO1xyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/pages/customer/customer-registration/customer-registration.page.ts":
/*!************************************************************************************!*\
  !*** ./src/app/pages/customer/customer-registration/customer-registration.page.ts ***!
  \************************************************************************************/
/*! exports provided: CustomerRegistrationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerRegistrationPage", function() { return CustomerRegistrationPage; });
/* harmony import */ var _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @auth0/angular-jwt */ "./node_modules/@auth0/angular-jwt/index.js");
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var CustomerRegistrationPage = /** @class */ (function () {
    function CustomerRegistrationPage(fb, customerService, flashProvider, jwt, route, activate, datePipe) {
        this.fb = fb;
        this.customerService = customerService;
        this.flashProvider = flashProvider;
        this.jwt = jwt;
        this.route = route;
        this.activate = activate;
        this.datePipe = datePipe;
        this.dob = new Date();
        this.customPopover = {
            subHeader: 'Select Customer Type'
        };
        this.customerDetails = this.activate.snapshot.data['data'] != null ? this.activate.snapshot.data['data'] : {};
        this.altMobNumer = this.customerDetails.altMobileNo != null ? Number(this.customerDetails.altMobileNo) : null;
        this.age = this.customerDetails.age != null ? this.customerDetails.age : null;
        console.log(this.customerDetails);
        this.buildForm(this.age, this.altMobNumer);
        if (this.customerDetails != null && this.customerDetails.vistingFor != null && this.customerDetails.vistingFor === 'store') {
            this.removeControlsForStore();
        }
    }
    CustomerRegistrationPage.prototype.buildForm = function (age, altMobNumer) {
        this.custformGroup = this.createForm({
            id: [this.customerDetails != null ? this.customerDetails.id : null],
            firstName: [this.customerDetails.firstName != null ? this.customerDetails.firstName : '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            lastName: [this.customerDetails.lastName != null ? this.customerDetails.lastName : '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            middleName: [this.customerDetails.middleName != null ? this.customerDetails.middleName : ''],
            address: [this.customerDetails.address != null ? this.customerDetails.address : '', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            emailId: [this.customerDetails.emailId != null ? this.customerDetails.emailId : '',
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].email])],
            gender: [this.customerDetails.gender != null ? this.customerDetails.gender : '',
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            martialStatus: [this.customerDetails.martialStatus != null ? this.customerDetails.martialStatus : ''],
            dob: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            age: [age, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(2)])],
            mobileNo: [this.customerDetails.mobileNo != null ? this.customerDetails.mobileNo : null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10)])],
            altMobileNo: [altMobNumer, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10)])],
            vistingFor: [this.customerDetails != null ? this.customerDetails.vistingFor : '',
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            aadharNumber: [this.customerDetails.aadharNumber != null ? this.customerDetails.aadharNumber : null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(14)])],
            occupation: [this.customerDetails.occupation != null ? this.customerDetails.occupation : null],
            panNumber: [this.customerDetails.panNumber != null ? this.customerDetails.panNumber : null,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('[A-Z]{5}[0-9]{4}[A-Z]{1}')])]
        });
        this.changeEvent();
    };
    CustomerRegistrationPage.prototype.ngOnInit = function () {
        if (this.customerDetails != null && this.customerDetails.vistingFor === 'store') {
            this.showHide = false;
        }
        else {
            this.showHide = true;
        }
        this.buildForm(this.age, this.altMobNumer);
        if (this.customerDetails != null && this.customerDetails.vistingFor != null && this.customerDetails.vistingFor === 'store') {
            this.removeControlsForStore();
        }
    };
    CustomerRegistrationPage.prototype.ngAfterViewInit = function () {
        console.log(this.customerDetails.dob);
        if (this.customerDetails != null && this.customerDetails.dob != null) {
            var birthYear = Number(this.datePipe.transform(this.customerDetails.dob, 'yyyy'));
            var birthMonth = Number(this.datePipe.transform(this.customerDetails.dob, 'MM'));
            var birthDay = Number(this.datePipe.transform(this.customerDetails.dob, 'dd'));
            this.dob = new Date(birthYear, birthMonth - 1, birthDay);
        }
    };
    CustomerRegistrationPage.prototype.onSubmit = function () {
        var _this = this;
        console.log(this.custformGroup);
        this.customerService.saveCustomer(this.custformGroup.value).subscribe(function (res) {
            console.log(res.error);
            _this.flashProvider.showGreen(res.error, 4000);
            _this.custformGroup.reset();
            if (res.document.vistingFor === 'store') {
                _this.route.navigate(['sales/newsales']);
            }
            else {
                _this.route.navigate(['customer/details/' + res.document.id]);
            }
        }, function (err) {
            _this.flashProvider.showRed(err.error, 4000);
        });
    };
    CustomerRegistrationPage.prototype.createForm = function (model) {
        return this.fb.group(model);
    };
    CustomerRegistrationPage.prototype.updateForm = function (model) {
        this.custformGroup.patchValue(model);
    };
    CustomerRegistrationPage.prototype.changeEvent = function () {
        var _this = this;
        /**
         * Below is the event to capture changes in date and covert it into age.
         */
        this.custformGroup.get('dob').valueChanges.subscribe(function (val) {
            var today = new Date();
            var selectedDate = new Date(Date.parse(val));
            var diffMillisec = (today.getTime() - selectedDate.getTime());
            var theDays = Math.round(diffMillisec / (1000 * 60 * 60 * 24));
            var theAge;
            if (theDays >= 365) {
                theAge = Math.round(theDays / 365);
            }
            else {
                theAge = 0;
            }
            _this.custformGroup.get('age').setValue(theAge);
        });
        console.log(this.custformGroup);
        /**
         * Below is the change event to capture the change in customer type and set the boolean value
         */
        this.custformGroup.get('vistingFor').valueChanges.subscribe(function (val) {
            console.log(val);
            if (val === 'store') {
                _this.removeControlsForStore();
            }
            else {
                _this.customerDetails.vistingFor = 'treatment';
                _this.showHide = true;
                _this.buildForm(_this.age, _this.altMobNumer);
            }
        });
    };
    CustomerRegistrationPage.prototype.removeControlsForStore = function () {
        this.showHide = false;
        this.custformGroup.removeControl('address');
        this.custformGroup.removeControl('gender');
        this.custformGroup.removeControl('martialStatus');
        this.custformGroup.removeControl('dob');
        this.custformGroup.removeControl('age');
        this.custformGroup.removeControl('aadharNumber');
        this.custformGroup.removeControl('panNumber');
        if (this.customerDetails != null && this.customerDetails.vistingFor != null) {
            this.customerDetails.vistingFor = 'store';
        }
    };
    CustomerRegistrationPage.prototype.ngOnChanges = function () {
        console.log(this.custformGroup);
    };
    CustomerRegistrationPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-customer-registration',
            template: __webpack_require__(/*! ./customer-registration.page.html */ "./src/app/pages/customer/customer-registration/customer-registration.page.html"),
            styles: [__webpack_require__(/*! ./customer-registration.page.scss */ "./src/app/pages/customer/customer-registration/customer-registration.page.scss")]
        }),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_1__["CustomerService"],
            src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_4__["FlashMessageService"],
            _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_0__["JwtHelperService"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
            _angular_common__WEBPACK_IMPORTED_MODULE_6__["DatePipe"]])
    ], CustomerRegistrationPage);
    return CustomerRegistrationPage;
}());



/***/ })

}]);
//# sourceMappingURL=customer-registration-customer-registration-module.js.map