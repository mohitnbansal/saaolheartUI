(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["update-stock-items-update-stock-items-module"],{

/***/ "./src/app/pages/stockmanagment/update-stock-items/update-stock-items.module.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/stockmanagment/update-stock-items/update-stock-items.module.ts ***!
  \**************************************************************************************/
/*! exports provided: UpdateStockItemsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateStockItemsPageModule", function() { return UpdateStockItemsPageModule; });
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _update_stock_items_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./update-stock-items.page */ "./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        component: _update_stock_items_page__WEBPACK_IMPORTED_MODULE_6__["UpdateStockItemsPage"]
    }
];
var UpdateStockItemsPageModule = /** @class */ (function () {
    function UpdateStockItemsPageModule() {
    }
    UpdateStockItemsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__["NgxDatatableModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_update_stock_items_page__WEBPACK_IMPORTED_MODULE_6__["UpdateStockItemsPage"]]
        })
    ], UpdateStockItemsPageModule);
    return UpdateStockItemsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.html":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.html ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\r\n    <ion-toolbar>\r\n        <ion-title>customer-search</ion-title>\r\n    </ion-toolbar>\r\n</ion-header> -->\r\n\r\n<ion-content padding>\r\n    <ion-card>\r\n        <ion-card-header>\r\n            <ion-card-title>\r\n                Search Stock\r\n            </ion-card-title>\r\n            <ion-card-subtitle>\r\n                Update Stock/Items\r\n            </ion-card-subtitle>\r\n        </ion-card-header>\r\n        <ion-card-content>\r\n            <!-- Animated Searchbar -->\r\n\r\n            <ion-searchbar (ionInput)=\"getCustomerListBySearch($event)\" animated showCancelButton cancelButtonText=\"Custom Cancel\"></ion-searchbar>\r\n\r\n            <ngx-datatable #myTable class='material' [columnMode]=\"'standard'\" [headerHeight]=\"50\" [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"50\" [scrollbarV]=\"'true'\" [scrollbarH]=\"'true'\" [rows]='rows' (page)=\"onPage($event)\">\r\n                <!-- Row Detail Template \r\n                <ngx-datatable-row-detail [rowHeight]=\"getHeight()\" #myDetailRow>\r\n                    <ng-template let-row=\"row\" let-rowIndex=\"rowIndex\" ngx-datatable-row-detail-template>\r\n                        <div><strong>Address</strong></div>\r\n                        <div class=\"row-wrap\">{{row.address}}</div>\r\n                    </ng-template>\r\n                </ngx-datatable-row-detail> -->\r\n                <!-- Column Templates \r\n                <ngx-datatable-column [width]=\"50\">\r\n                    <ng-template let-row=\"row\" let-expanded=\"expanded\" ngx-datatable-cell-template>\r\n                        <a href=\"javascript:void(0)\" [class.datatable-icon-right]=\"!expanded\" [class.datatable-icon-down]=\"expanded\" title=\"Expand/Collapse Row\" (click)=\"toggleExpandRow(row,expanded)\">\r\n                        </a>\r\n                    </ng-template>\r\n                </ngx-datatable-column> -->\r\n                <ngx-datatable-column name=\"Sr No\" width=\"80\">\r\n                    <ng-template let-rowIndex=\"rowIndex\" let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{rowIndex+1}}</strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Stock/Item Id\" width=\"180\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <a [routerDirection]=\"'forward'\" [routerLink]=\"['/stock/details/',row.id]\">\r\n                            <b><i> {{row.id}}  </i></b>\r\n                        </a>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Item Name\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.stockName}} </strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Available QTY\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.qtyOfStockAvailable}} </strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Current Rate\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.currentRateOfStock}} </strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Item Category\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.stockCategoryDomain.categoryName}} </strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n                <ngx-datatable-column name=\"Net Stock Value\" width=\"150\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.curentStockValue}} </strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Added On (Date and Time) \" width=\"300\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.addedOn | date : 'MMM d, y, h:mm:ss a' }} </strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Last Updated On (Date and Time) \" width=\"300\">\r\n                    <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                        <strong>{{row.lastUpdatedOn | date : 'MMM d, y, h:mm:ss a' }} </strong>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n            </ngx-datatable>\r\n\r\n        </ion-card-content>\r\n    </ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.scss":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.scss ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ngx-datatable,\n.info {\n  text-align: left;\n  width: 98% !important;\n  margin: 0 auto; }\n\ndatatable-scroller {\n  width: 100% !important; }\n\n.row-wrap {\n  white-space: pre-wrap; }\n\n:host /deep/ .datatable-row-group {\n  will-change: transform; }\n\n:host /deep/ .ngx-datatable.material .datatable-header .datatable-row-right {\n  margin-left: -8px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc3RvY2ttYW5hZ21lbnQvdXBkYXRlLXN0b2NrLWl0ZW1zL0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXHBhZ2VzXFxzdG9ja21hbmFnbWVudFxcdXBkYXRlLXN0b2NrLWl0ZW1zXFx1cGRhdGUtc3RvY2staXRlbXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUVJLGlCQUFnQjtFQUNoQixzQkFBcUI7RUFDckIsZUFBYyxFQUNqQjs7QUFFRDtFQUNJLHVCQUFzQixFQUN6Qjs7QUFFRDtFQUNJLHNCQUNKLEVBQUM7O0FBRUE7RUFDRyx1QkFBc0IsRUFDekI7O0FBRUE7RUFDRyxrQkFBaUIsRUFDcEIiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9zdG9ja21hbmFnbWVudC91cGRhdGUtc3RvY2staXRlbXMvdXBkYXRlLXN0b2NrLWl0ZW1zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5uZ3gtZGF0YXRhYmxlLFxyXG4uaW5mbyB7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgd2lkdGg6IDk4JSAhaW1wb3J0YW50O1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbn1cclxuXHJcbmRhdGF0YWJsZS1zY3JvbGxlciB7XHJcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucm93LXdyYXAge1xyXG4gICAgd2hpdGUtc3BhY2U6IHByZS13cmFwXHJcbn1cclxuXHJcbiA6aG9zdCAvZGVlcC8gLmRhdGF0YWJsZS1yb3ctZ3JvdXAge1xyXG4gICAgd2lsbC1jaGFuZ2U6IHRyYW5zZm9ybTtcclxufVxyXG5cclxuIDpob3N0IC9kZWVwLyAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLXJvdy1yaWdodCB7XHJcbiAgICBtYXJnaW4tbGVmdDogLThweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.ts":
/*!************************************************************************************!*\
  !*** ./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.ts ***!
  \************************************************************************************/
/*! exports provided: UpdateStockItemsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateStockItemsPage", function() { return UpdateStockItemsPage; });
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_stock_stock_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/stock/stock.service */ "./src/app/services/stock/stock.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var UpdateStockItemsPage = /** @class */ (function () {
    function UpdateStockItemsPage(stockservice) {
        this.stockservice = stockservice;
        this.selected = [];
        this.tablestyle = 'bootstrap';
    }
    UpdateStockItemsPage.prototype.onPage = function (event) {
        // clearTimeout(this.timeout);
        // this.timeout = setTimeout(() => {
        //   console.log('paged!', event);
        // }, 100);
    };
    UpdateStockItemsPage.prototype.getHeight = function () {
        return 150;
    };
    ;
    UpdateStockItemsPage.prototype.getCustomerListBySearch = function (event) {
        var val = event.target.value.toLowerCase();
        // get the amount of columns in the table
        var colsAmt = this.columns.length;
        // get the key names of each column in the dataset
        var keys = Object.keys(this.stockList[0]);
        // assign filtered matches to the active datatable
        this.rows = this.stockList.filter(function (item) {
            // iterate through each row's column data
            for (var i = 0; i < colsAmt; i++) {
                // check for a match
                if (item[keys[i]] != null) {
                    if (item[keys[i]].toString().toLowerCase().indexOf(val) !== -1 || !val) {
                        // found match, return true to add to result set
                        return true;
                    }
                }
            }
        });
    };
    ;
    UpdateStockItemsPage.prototype.ngOnInit = function () {
        var _this = this;
        this.stockservice.getAllStockByOrder().subscribe(function (res) {
            console.log(res);
            _this.stockList = res;
            _this.rows = res;
            if (res !== null && res.length > 0) {
                _this.columns = Object.keys(res[0]).map(function (key) {
                    return {
                        'prop': key
                    };
                });
            }
        }, function (err) {
            console.log(err);
        });
    };
    UpdateStockItemsPage.prototype.toggleExpandRow = function (row, expanded) {
        if (expanded !== true) {
            this.table.rowDetail.collapseAllRows();
        }
        this.table.rowDetail.toggleExpandRow(row);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('myTable'),
        __metadata("design:type", _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__["DatatableComponent"])
    ], UpdateStockItemsPage.prototype, "table", void 0);
    UpdateStockItemsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-update-stock-items',
            template: __webpack_require__(/*! ./update-stock-items.page.html */ "./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.html"),
            styles: [__webpack_require__(/*! ./update-stock-items.page.scss */ "./src/app/pages/stockmanagment/update-stock-items/update-stock-items.page.scss")]
        }),
        __metadata("design:paramtypes", [src_app_services_stock_stock_service__WEBPACK_IMPORTED_MODULE_2__["StockService"]])
    ], UpdateStockItemsPage);
    return UpdateStockItemsPage;
}());



/***/ })

}]);
//# sourceMappingURL=update-stock-items-update-stock-items-module.js.map