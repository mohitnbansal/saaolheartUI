(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["new-stock-new-stock-module"],{

/***/ "./src/app/pages/stockmanagment/new-stock/new-stock.module.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/stockmanagment/new-stock/new-stock.module.ts ***!
  \********************************************************************/
/*! exports provided: NewStockPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewStockPageModule", function() { return NewStockPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _new_stock_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./new-stock.page */ "./src/app/pages/stockmanagment/new-stock/new-stock.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _new_stock_page__WEBPACK_IMPORTED_MODULE_5__["NewStockPage"]
    }
];
var NewStockPageModule = /** @class */ (function () {
    function NewStockPageModule() {
    }
    NewStockPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_new_stock_page__WEBPACK_IMPORTED_MODULE_5__["NewStockPage"]]
        })
    ], NewStockPageModule);
    return NewStockPageModule;
}());



/***/ }),

/***/ "./src/app/pages/stockmanagment/new-stock/new-stock.page.html":
/*!********************************************************************!*\
  !*** ./src/app/pages/stockmanagment/new-stock/new-stock.page.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header size=\"2\">\r\n    <ion-toolbar>\r\n        <ion-title>Stock/Item Registration</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n    <ion-card>\r\n        <ion-card-header color=\"secondary\">\r\n            <ion-card-title>\r\n\r\n                <b> Item Details</b>\r\n\r\n            </ion-card-title>\r\n            <ion-card-subtitle>\r\n                Fill in the details to registor\r\n            </ion-card-subtitle>\r\n\r\n        </ion-card-header>\r\n\r\n        <ion-card-content>\r\n            <form [formGroup]=\"stockform\" (ngSubmit)=\"onSubmit()\">\r\n                <ion-grid>\r\n                    <ion-row>\r\n                        <ion-col size=\"6\">\r\n                            <ion-item>\r\n                                <ion-label>Item Category</ion-label>\r\n                                <ion-select formControlName=\"stockCategoryid\" [interfaceOptions]=\"customPopOver\" interface=\"popover\" placeholder=\"Select\">\r\n                                    <ion-select-option *ngFor=\"let stock of stockCategories\" value=\"{{stock.id}}\">{{stock.categoryName}}</ion-select-option>\r\n                                </ion-select>\r\n                            </ion-item>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-item-divider color=\"black\">\r\n                        </ion-item-divider>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col>\r\n                            <ion-item>\r\n                                <ion-label position=\"floating\">Stock Name</ion-label>\r\n                                <ion-input type=\"text\" formControlName=\"stockName\" id=\"stockName\"></ion-input>\r\n                               \r\n                               \r\n                            </ion-item>\r\n                            <ion-card class=\"zIndex\"  *ngIf=\"stockShow\">\r\n                                    <ion-card-content>\r\n                                            <ion-list>\r\n                                      <ion-item *ngFor=\"let stock of stockList\">\r\n                                                    <ion-label>{{stock.stockName}} -- {{stock.id}}</ion-label>\r\n                                               \r\n                                                </ion-item>\r\n                                                \r\n                                               \r\n                                    </ion-list>\r\n                                    </ion-card-content>\r\n                                </ion-card>\r\n                        </ion-col>\r\n                        <ion-col>\r\n                            <ion-item>\r\n                                <ion-label position=\"floating\">Rate</ion-label>\r\n                                <ion-input type=\"text\" formControlName=\"currentRateOfStock\" id=\"currentRateOfStock\">\r\n                                </ion-input>\r\n                            </ion-item>\r\n                        </ion-col>\r\n                        <ion-col>\r\n                                <ion-item>\r\n                                        <ion-label position=\"floating\">Quantity of Stock</ion-label>\r\n                                        <ion-input type=\"email\" formControlName=\"qtyOfStockAvailable\" id=\"qtyOfStockAvailable\">\r\n                                        </ion-input>\r\n                                    </ion-item>\r\n                          \r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col>\r\n                                <ion-item>\r\n                                        <ion-label position=\"floating\">Available Stock Value</ion-label>\r\n                                        <ion-input type=\"text\" readonly formControlName=\"curentStockValue\" id=\"curentStockValue\">\r\n                                        </ion-input>\r\n                                    </ion-item>\r\n                        </ion-col>\r\n                        <ion-col>\r\n                            <ion-item>\r\n                                <ion-label position=\"floating\">Stock/Item Description</ion-label>\r\n                                <ion-textarea type=\"text\" formControlName=\"stockDescription\" id=\"stockDescription\">\r\n                                </ion-textarea>\r\n                            </ion-item>\r\n                        </ion-col>\r\n\r\n                    </ion-row>\r\n\r\n            \r\n\r\n                </ion-grid>\r\n                <ion-item>\r\n                    <ion-button shape=\"round\" size=\"default\" slot=\"end\" type=\"submit\" [disabled]=\"!stockform.valid\">\r\n                        <ion-icon size=\"default\" name=\"person-add\"></ion-icon> &nbsp; Add Item</ion-button>\r\n                    <ion-button shape=\"round\" size=\"default\" slot=\"end\" type=\"reset\">Reset</ion-button>\r\n                </ion-item>\r\n\r\n            </form>\r\n        </ion-card-content>\r\n    </ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/stockmanagment/new-stock/new-stock.page.scss":
/*!********************************************************************!*\
  !*** ./src/app/pages/stockmanagment/new-stock/new-stock.page.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-item-divider {\n  color: black; }\n\n.zIndex {\n  z-index: 2000; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc3RvY2ttYW5hZ21lbnQvbmV3LXN0b2NrL0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXHBhZ2VzXFxzdG9ja21hbmFnbWVudFxcbmV3LXN0b2NrXFxuZXctc3RvY2sucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksYUFBWSxFQUNmOztBQUNEO0VBQ0ksY0FBYSxFQUNoQiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N0b2NrbWFuYWdtZW50L25ldy1zdG9jay9uZXctc3RvY2sucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmlvbi1pdGVtLWRpdmlkZXIge1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG59XHJcbi56SW5kZXh7XHJcbiAgICB6LWluZGV4OiAyMDAwO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/stockmanagment/new-stock/new-stock.page.ts":
/*!******************************************************************!*\
  !*** ./src/app/pages/stockmanagment/new-stock/new-stock.page.ts ***!
  \******************************************************************/
/*! exports provided: NewStockPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewStockPage", function() { return NewStockPage; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @auth0/angular-jwt */ "./node_modules/@auth0/angular-jwt/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_stock_stock_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/stock/stock.service */ "./src/app/services/stock/stock.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var NewStockPage = /** @class */ (function () {
    function NewStockPage(fb, stockservice, flashProvider, jwt, route) {
        this.fb = fb;
        this.stockservice = stockservice;
        this.flashProvider = flashProvider;
        this.jwt = jwt;
        this.route = route;
        this.stockList = [];
        this.stockShow = false;
        this.customPopOver = {
            subHeader: 'Select Item Category'
        };
    }
    NewStockPage.prototype.ngOnInit = function () {
        var _this = this;
        this.stockform = this.createForm({
            id: [],
            stockCategoryid: [],
            stockCategory: [],
            stockName: [],
            stockDescription: [],
            qtyOfStockAvailable: [],
            currentRateOfStock: [],
            curentStockValue: [],
            addedOn: [],
            lastUpdatedOn: [],
            qtyOfStockToUpdate: [],
            reasonForUpdate: []
        });
        this.stockservice.getAllStockCategory().subscribe(function (res) {
            _this.stockCategories = res;
        }, function (err) {
            console.log(err);
        });
        this.changeEvent();
    };
    NewStockPage.prototype.createForm = function (model) {
        return this.fb.group(model);
    };
    NewStockPage.prototype.updateForm = function (model) {
        this.stockform.patchValue(model);
    };
    NewStockPage.prototype.onSubmit = function () {
        var _this = this;
        console.log(this.stockform.value);
        this.stockservice.saveStock(this.stockform.value).subscribe(function (res) {
            _this.flashProvider.showGreen(res.error, 4000);
            _this.stockform.reset();
            if (res.document.vistingFor === 'store') {
                //this.route.navigate(['store/' + res.document.id]);
            }
            else {
                // this.route.navigate(['stock/details/' + res.document.id]);
            }
        }, function (err) {
            _this.flashProvider.showRed(err.error, 4000);
        });
    };
    NewStockPage.prototype.changeEvent = function () {
        var _this = this;
        /**
         * Below is the event to capture changes in date and covert it into age.
         */
        this.stockform.get('stockName').valueChanges.subscribe(function (val) {
            if (val.length >= 3) {
                _this.stockservice.getStockByLikeName(val).subscribe(function (res) {
                    console.log(res);
                    _this.stockList = res;
                    _this.stockShow = true;
                }, function (err) {
                    console.log(err);
                    _this.stockShow = false;
                    _this.stockList = [];
                });
            }
            else {
                _this.stockList = [];
                _this.stockShow = false;
            }
        });
        this.stockform.get('currentRateOfStock').valueChanges.subscribe(function (val) {
            var stckVal = 0;
            var currentVal = val;
            var qty = _this.stockform.get('qtyOfStockAvailable').value;
            if (currentVal !== null && qty != null) {
                stckVal = currentVal * qty;
                if (isNaN(stckVal)) {
                    stckVal = 0;
                }
            }
            _this.stockform.get('curentStockValue').setValue(stckVal.toFixed(2));
        });
        this.stockform.get('qtyOfStockAvailable').valueChanges.subscribe(function (val) {
            var stckVal = 0;
            var currentVal = val;
            var qty = _this.stockform.get('currentRateOfStock').value;
            if (currentVal !== null && qty != null) {
                stckVal = currentVal * qty;
            }
            _this.stockform.get('curentStockValue').setValue(stckVal);
        });
    };
    NewStockPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-new-stock',
            template: __webpack_require__(/*! ./new-stock.page.html */ "./src/app/pages/stockmanagment/new-stock/new-stock.page.html"),
            styles: [__webpack_require__(/*! ./new-stock.page.scss */ "./src/app/pages/stockmanagment/new-stock/new-stock.page.scss")]
        }),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"],
            src_app_services_stock_stock_service__WEBPACK_IMPORTED_MODULE_5__["StockService"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_2__["FlashMessageService"],
            _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_3__["JwtHelperService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_0__["Router"]])
    ], NewStockPage);
    return NewStockPage;
}());



/***/ })

}]);
//# sourceMappingURL=new-stock-new-stock-module.js.map