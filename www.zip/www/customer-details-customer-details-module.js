(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customer-details-customer-details-module"],{

/***/ "./src/app/pages/customer/customer-details/customer-details.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/pages/customer/customer-details/customer-details.module.ts ***!
  \****************************************************************************/
/*! exports provided: CustomerDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerDetailsPageModule", function() { return CustomerDetailsPageModule; });
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var _customer_details_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./customer-details.page */ "./src/app/pages/customer/customer-details/customer-details.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var routes = [
    {
        path: '',
        component: _customer_details_page__WEBPACK_IMPORTED_MODULE_7__["CustomerDetailsPage"]
    }
];
var CustomerDetailsPageModule = /** @class */ (function () {
    function CustomerDetailsPageModule() {
    }
    CustomerDetailsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                src_app_components_component_module__WEBPACK_IMPORTED_MODULE_6__["ComponentModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__["NgxDatatableModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_customer_details_page__WEBPACK_IMPORTED_MODULE_7__["CustomerDetailsPage"]]
        })
    ], CustomerDetailsPageModule);
    return CustomerDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/customer/customer-details/customer-details.page.html":
/*!****************************************************************************!*\
  !*** ./src/app/pages/customer/customer-details/customer-details.page.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar>\r\n        <ion-title>Customer Details</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content padding>\r\n\r\n    <ion-card>\r\n        <ion-card-header color=\"primary\">\r\n            <ion-card-title>\r\n                {{customerFormDetails.firstName}} {{customerFormDetails.lastName}} - Counsultation ID {{customerFormDetails.id}}\r\n            </ion-card-title>\r\n        </ion-card-header>\r\n        <ion-card-content>\r\n\r\n            <ion-grid>\r\n\r\n                <ion-row>\r\n\r\n                    <ion-col align-self-stretch size=\"3\">\r\n                        <ion-segment [(ngModel)]=\"customercomp\" (ionChange)=\"onSegmentChange($event)\" color=\"primary\">\r\n\r\n\r\n                            <ion-segment-button value=\"customerdetails\" float-left>\r\n                                Customer Details\r\n                            </ion-segment-button>\r\n                            <div *ngIf=\"customerFormDetails['vistingFor'] =='treatment'\">\r\n                            <ion-segment-button float-left value=\"doctordetails\">\r\n                                Doctor Consultation\r\n                            </ion-segment-button>\r\n                            <ion-segment-button float-left value=\"ctangiographydetails\">\r\n                                Ct Angiography MOU\r\n                            </ion-segment-button>\r\n                         \r\n                            <ion-segment-button float-left value=\"treatmentinvoicedetails\">\r\n                                Treatment Invoice\r\n                            </ion-segment-button>\r\n                            <ion-segment-button float-left value=\"treatmentplandetails\">\r\n                                Treatment Plan\r\n                            </ion-segment-button>\r\n                        </div>\r\n                        </ion-segment>\r\n                    </ion-col>\r\n\r\n\r\n                    <ion-col [ngSwitch]=\"customercomp\">\r\n                        <app-customer-detail  *ngSwitchCase=\"'customerdetails'\"></app-customer-detail>\r\n                       \r\n                        <app-doctor-details *ngSwitchCase=\"'doctordetails'\"></app-doctor-details>\r\n                        <app-ct-angiography-details *ngSwitchCase=\"'ctangiographydetails'\"></app-ct-angiography-details>\r\n                        <app-treatment-invoice-details *ngSwitchCase=\"'treatmentinvoicedetails'\"></app-treatment-invoice-details>\r\n                        <app-treatment-plan-detail *ngSwitchCase=\"'treatmentplandetails'\"></app-treatment-plan-detail>\r\n                        <!-- <app-invoice-details *ngSwitchCase=\"'invociedetails'\"></app-invoice-details> -->\r\n\r\n                    </ion-col>\r\n              \r\n                </ion-row>\r\n\r\n            </ion-grid>\r\n\r\n        </ion-card-content>\r\n\r\n    </ion-card>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/customer/customer-details/customer-details.page.scss":
/*!****************************************************************************!*\
  !*** ./src/app/pages/customer/customer-details/customer-details.page.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-segment {\n  display: block;\n  white-space: nowrap;\n  font-size: 0;\n  overflow: auto; }\n  ion-segment::-webkit-scrollbar {\n    width: 0;\n    height: 0;\n    display: none; }\n  ion-segment ion-segment-button.segment-button {\n    display: inline-block;\n    min-width: 100px;\n    width: auto; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY3VzdG9tZXIvY3VzdG9tZXItZGV0YWlscy9DOlxcQmFzaWNzXFxDXFxwb2ludGVyc1xcc2Fhb2xoZWFydFVJL3NyY1xcYXBwXFxwYWdlc1xcY3VzdG9tZXJcXGN1c3RvbWVyLWRldGFpbHNcXGN1c3RvbWVyLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBYztFQUNkLG9CQUFtQjtFQUNuQixhQUFZO0VBQ1osZUFBYyxFQVdqQjtFQWZEO0lBTVEsU0FBUTtJQUNSLFVBQVM7SUFDVCxjQUFhLEVBQ2hCO0VBVEw7SUFXUSxzQkFBcUI7SUFDckIsaUJBQWdCO0lBQ2hCLFlBQVcsRUFDZCIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2N1c3RvbWVyL2N1c3RvbWVyLWRldGFpbHMvY3VzdG9tZXItZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2VnbWVudCB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICBmb250LXNpemU6IDA7XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxuICAgICY6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcclxuICAgICAgICB3aWR0aDogMDtcclxuICAgICAgICBoZWlnaHQ6IDA7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgIH1cclxuICAgIGlvbi1zZWdtZW50LWJ1dHRvbi5zZWdtZW50LWJ1dHRvbiB7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIG1pbi13aWR0aDogMTAwcHg7XHJcbiAgICAgICAgd2lkdGg6IGF1dG87XHJcbiAgICB9XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/customer/customer-details/customer-details.page.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/customer/customer-details/customer-details.page.ts ***!
  \**************************************************************************/
/*! exports provided: CustomerDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerDetailsPage", function() { return CustomerDetailsPage; });
/* harmony import */ var _components_customer_detail_customer_detail_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../components/customer-detail/customer-detail.component */ "./src/app/components/customer-detail/customer-detail.component.ts");
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var CustomerDetailsPage = /** @class */ (function () {
    function CustomerDetailsPage(activate, fb, customerService, flashProvider, active, route) {
        this.activate = activate;
        this.fb = fb;
        this.customerService = customerService;
        this.flashProvider = flashProvider;
        this.active = active;
        this.route = route;
        this.customercomp = '';
        this.customerDetails = this.activate.snapshot.data['data'];
    }
    CustomerDetailsPage.prototype.ngOnInit = function () {
        this.customercomp = 'customerdetails';
        this.customerFormDetails = this.activate.snapshot.data['data'];
    };
    CustomerDetailsPage.prototype.ngAfterViewInit = function () {
        var _this = this;
        // console.log(this.doctorDetail.initializeForm());
        this.customerDetailsComp['first'].navigateTo.subscribe(function (res) {
            _this.route.navigateByUrl('/customer/register/' + res);
        });
    };
    CustomerDetailsPage.prototype.onSegmentChange = function (eve) {
        console.log(eve.detail.value);
        if (eve.detail.value === 'doctordetails') {
            console.log(454);
            // this.doctorDetail.initializeForm();
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ViewChildren"])(_components_customer_detail_customer_detail_component__WEBPACK_IMPORTED_MODULE_0__["CustomerDetailComponent"]),
        __metadata("design:type", _components_customer_detail_customer_detail_component__WEBPACK_IMPORTED_MODULE_0__["CustomerDetailComponent"])
    ], CustomerDetailsPage.prototype, "customerDetailsComp", void 0);
    CustomerDetailsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
            selector: 'app-customer-details',
            template: __webpack_require__(/*! ./customer-details.page.html */ "./src/app/pages/customer/customer-details/customer-details.page.html"),
            providers: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
            styles: [__webpack_require__(/*! ./customer-details.page.scss */ "./src/app/pages/customer/customer-details/customer-details.page.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_2__["CustomerService"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_1__["FlashMessageService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], CustomerDetailsPage);
    return CustomerDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=customer-details-customer-details-module.js.map