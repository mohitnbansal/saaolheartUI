(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["new-sales-new-sales-module"],{

/***/ "./src/app/pages/sales/new-sales/new-sales.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/sales/new-sales/new-sales.module.ts ***!
  \***********************************************************/
/*! exports provided: NewSalesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewSalesPageModule", function() { return NewSalesPageModule; });
/* harmony import */ var src_app_components_component_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ionic-selectable */ "./node_modules/ionic-selectable/esm5/ionic-selectable.min.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _new_sales_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./new-sales.page */ "./src/app/pages/sales/new-sales/new-sales.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var routes = [
    {
        path: '',
        component: _new_sales_page__WEBPACK_IMPORTED_MODULE_8__["NewSalesPage"]
    }
];
var NewSalesPageModule = /** @class */ (function () {
    function NewSalesPageModule() {
    }
    NewSalesPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            entryComponents: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__["NgxDatatableModule"],
                src_app_components_component_module__WEBPACK_IMPORTED_MODULE_0__["ComponentModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"].forChild(routes),
                ionic_selectable__WEBPACK_IMPORTED_MODULE_1__["IonicSelectableModule"]
            ],
            declarations: [_new_sales_page__WEBPACK_IMPORTED_MODULE_8__["NewSalesPage"]]
        })
    ], NewSalesPageModule);
    return NewSalesPageModule;
}());



/***/ }),

/***/ "./src/app/pages/sales/new-sales/new-sales.page.html":
/*!***********************************************************!*\
  !*** ./src/app/pages/sales/new-sales/new-sales.page.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header size=\"2\">\r\n    <ion-toolbar>\r\n        <ion-title>Sales</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n\r\n    <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n        <ion-fab-button>\r\n            <ion-icon name=\"apps\"></ion-icon>\r\n        </ion-fab-button>\r\n\r\n        <ion-fab-list side=\"top\">\r\n            <ion-fab-button (click)=\"saveInvoice('print')\">\r\n                <ion-icon name=\"print\"></ion-icon>\r\n            </ion-fab-button>\r\n            <ion-fab-button (click)=\"saveInvoice('mail')\">\r\n                <ion-icon name=\"mail\"></ion-icon>\r\n            </ion-fab-button>\r\n            <ion-fab-button (click)=\"resetForm()\">\r\n                <ion-icon name=\"refresh-circle\"></ion-icon>\r\n            </ion-fab-button>\r\n        </ion-fab-list>\r\n\r\n    </ion-fab>\r\n\r\n    <ion-card>\r\n        <ion-card-header color=\"secondary\">\r\n            <ion-card-title>\r\n\r\n                <b>Search Customer</b>\r\n\r\n            </ion-card-title>\r\n\r\n\r\n        </ion-card-header>\r\n\r\n\r\n        <ion-card-content>\r\n\r\n\r\n            <ion-searchbar [(ngModel)]=\"customerString\" (ionInput)=\"getCustomerListBySearch($event)\" animated showCancelButton cancelButtonText=\"Custom Cancel\"></ion-searchbar>\r\n            <br>\r\n            <ion-list radio-group>\r\n                <ion-item *ngFor=\"let item of customerList\">\r\n                    <ion-label>{{item.firstName}} {{item.lastName}}</ion-label>\r\n                    <ion-radio color=\"dark\" (ionSelect)=\"getCustomerDetails($event)\" value=\"{{item.id}}\"></ion-radio>\r\n                </ion-item>\r\n            </ion-list>\r\n\r\n\r\n        </ion-card-content>\r\n    </ion-card>\r\n    <div *ngIf=\"showHide\">\r\n        <ion-card>\r\n            <ion-card-header color=\"secondary\">\r\n                <ion-card-title>\r\n                    <ion-grid>\r\n                        <ion-row>\r\n                            <ion-col> <b> Invoice Details</b></ion-col>\r\n                            <ion-col size=\"2\" float-right><b>Invoice no</b></ion-col>\r\n                            <ion-col size=\"1\" float-right><b>0058</b></ion-col>\r\n                        </ion-row>\r\n                    </ion-grid>\r\n\r\n                </ion-card-title>\r\n\r\n\r\n            </ion-card-header>\r\n\r\n            <ion-card-content>\r\n                <ion-grid>\r\n                    <ion-row>\r\n                        <ion-col>\r\n                            <ion-item>\r\n                                <ion-label position=\"floating\">Customer Name</ion-label>\r\n                                <ion-input type=\"text\" readonly id=\"panNumber\" value=\"{{customerDbObj.firstName}} {{customerDbObj.lastName}}\">\r\n                                </ion-input>\r\n                            </ion-item>\r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row>\r\n                        <ion-col>\r\n\r\n                            <ion-searchbar #productString placeholder=\"Search Stock/Items\" (ionInput)=\"getStockBySearch($event)\" animated showCancelButton cancelButtonText=\"Custom Cancel\"></ion-searchbar>\r\n                            <br>\r\n                            <ion-list radio-group>\r\n                                <ion-item *ngFor=\"let item of stockItems\">\r\n                                    <ion-label>{{item.stockName}}</ion-label>\r\n                                    <ion-radio color=\"dark\" (ionSelect)=\"setStockProduct($event)\" value=\"{{item.id}}\"></ion-radio>\r\n                                </ion-item>\r\n                            </ion-list>\r\n\r\n                        </ion-col>\r\n                    </ion-row>\r\n\r\n                    <ion-row>\r\n                        <ion-item-divider></ion-item-divider>\r\n                    </ion-row>\r\n                </ion-grid>\r\n                <ngx-datatable #invTable class='material' [columnMode]=\"'standard'\" [rows]='rows' [headerHeight]=\"50\" [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"50\" [scrollbarV]=\"'true'\" [scrollbarH]=\"'true'\">\r\n\r\n\r\n                    <!-- Column Templates -->\r\n\r\n                    <ngx-datatable-column name=\"Sr No\">\r\n                        <ng-template let-rowIndex=\"rowIndex\" let-row=\"row\" ngx-datatable-cell-template>\r\n                            <strong>{{rowIndex+1}}</strong>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n\r\n                    <ngx-datatable-column name=\"Stock Name\">\r\n                        <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                            <strong>{{row.stockName}}</strong>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Rate\">\r\n                        <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                            <strong>{{row.currentRateOfStock}}</strong>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Quantity\">\r\n                        <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                            <strong>{{row.stockQty}}</strong>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Price\">\r\n                        <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                            <strong>{{row.stockQty * row.currentRateOfStock}}</strong>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                    <ngx-datatable-column name=\"Delete\" [width]=\"50\">\r\n                        <ng-template let-row=\"row\" let-rowIndex=\"rowIndex\" let-expanded=\"expanded\" ngx-datatable-cell-template>\r\n                            <a>\r\n                                <ion-icon class=\"ionicons\" (click)=\"deleteThisRow(rowIndex,row)\" name=\"trash\"></ion-icon>\r\n                            </a>\r\n                        </ng-template>\r\n                    </ngx-datatable-column>\r\n                </ngx-datatable>\r\n                <ion-grid>\r\n                    <ion-row>\r\n                        <ion-col>\r\n                            <ion-item float-right>\r\n                                <ion-label>Total Price</ion-label>\r\n                                <ion-input text-right type=\"number\" [(ngModel)]=\"totalPriceOfInv\" readonly value=\"{{totalPriceOfInv}}\"></ion-input>\r\n                            </ion-item>\r\n\r\n                        </ion-col>\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-card-content>\r\n        </ion-card>\r\n\r\n    </div>\r\n\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/sales/new-sales/new-sales.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/sales/new-sales/new-sales.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".ngx-datatable,\n.info {\n  text-align: left;\n  width: 98% !important;\n  margin: 0 auto; }\n\ndatatable-scroller {\n  width: 100% !important; }\n\n.ionicons:hover {\n  cursor: pointer; }\n\n.row-wrap {\n  white-space: pre-wrap; }\n\n:host .datatable-row-group {\n  will-change: transform; }\n\n:host .ngx-datatable.material .datatable-header .datatable-row-right {\n  margin-left: -8px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc2FsZXMvbmV3LXNhbGVzL0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXHBhZ2VzXFxzYWxlc1xcbmV3LXNhbGVzXFxuZXctc2FsZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUVJLGlCQUFnQjtFQUNoQixzQkFBcUI7RUFDckIsZUFBYyxFQUNqQjs7QUFFRDtFQUNJLHVCQUFzQixFQUN6Qjs7QUFFRDtFQUNJLGdCQUFlLEVBQ2xCOztBQUVEO0VBQ0ksc0JBQ0osRUFBQzs7QUFFQTtFQUNHLHVCQUFzQixFQUN6Qjs7QUFFQTtFQUNHLGtCQUFpQixFQUNwQiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3NhbGVzL25ldy1zYWxlcy9uZXctc2FsZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5neC1kYXRhdGFibGUsXHJcbi5pbmZvIHtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICB3aWR0aDogOTglICFpbXBvcnRhbnQ7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxufVxyXG5cclxuZGF0YXRhYmxlLXNjcm9sbGVyIHtcclxuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5pb25pY29uczpob3ZlciB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5yb3ctd3JhcCB7XHJcbiAgICB3aGl0ZS1zcGFjZTogcHJlLXdyYXBcclxufVxyXG5cclxuIDpob3N0ICAuZGF0YXRhYmxlLXJvdy1ncm91cCB7XHJcbiAgICB3aWxsLWNoYW5nZTogdHJhbnNmb3JtO1xyXG59XHJcblxyXG4gOmhvc3QgIC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LXJpZ2h0IHtcclxuICAgIG1hcmdpbi1sZWZ0OiAtOHB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/sales/new-sales/new-sales.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/sales/new-sales/new-sales.page.ts ***!
  \*********************************************************/
/*! exports provided: NewSalesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewSalesPage", function() { return NewSalesPage; });
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _services_sales_sales_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../services/sales/sales.service */ "./src/app/services/sales/sales.service.ts");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var src_app_services_stock_stock_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/stock/stock.service */ "./src/app/services/stock/stock.service.ts");
/* harmony import */ var src_app_components_stock_quantity_stock_quantity_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/stock-quantity/stock-quantity.page */ "./src/app/components/stock-quantity/stock-quantity.page.ts");
/* harmony import */ var src_app_services_common_common_util_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/common/common-util.service */ "./src/app/services/common/common-util.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};









var NewSalesPage = /** @class */ (function () {
    function NewSalesPage(customerService, stockService, salesService, flashService, modalController, commonService) {
        this.customerService = customerService;
        this.stockService = stockService;
        this.salesService = salesService;
        this.flashService = flashService;
        this.modalController = modalController;
        this.commonService = commonService;
        this.showHide = false;
        this.currentDate = new Date();
        this.rows = [];
        this.selected = [];
        this.customerDbObj = [];
        this.customerSaleData = {};
    }
    NewSalesPage.prototype.ngOnInit = function () {
    };
    NewSalesPage.prototype.getCustomerListBySearch = function (event) {
        var _this = this;
        console.log(event.target.value);
        if (event.target.value !== '') {
            this.customerService.getCustomerListByNameOrMobile(event.target.value).subscribe(function (res) {
                _this.customerList = res;
                console.log(res);
            }, function (err) {
                delete _this.customerList;
                console.log(err);
            });
        }
        else {
            delete this.customerList;
        }
    };
    NewSalesPage.prototype.getCustomerDetails = function (ev) {
        var _this = this;
        console.log(ev.target.value);
        this.customerService.getCustomerById(ev.target.value).subscribe(function (res) {
            _this.customerDbObj = res;
            _this.showHide = true;
            console.log(res);
        }, function (err) {
            console.log(err);
        });
        console.log(this.customerString);
        this.customerString = '';
        delete this.customerList;
    };
    NewSalesPage.prototype.getStockBySearch = function (stck) {
        var _this = this;
        console.log(stck.target.value);
        this.stockService.getStockByLikeName(stck.target.value).subscribe(function (res) {
            console.log(res);
            _this.stockItems = res;
        }, function (err) {
            console.log(err);
        });
    };
    NewSalesPage.prototype.setStockProduct = function (prdct) {
        console.log(prdct.target.value);
        var stockSelected = this.stockItems.filter(function (key) { return (key.id == prdct.target.value); });
        this.stockItemsForRows = stockSelected;
        console.log(this.stockItemsForRows);
        this.presentModal();
    };
    NewSalesPage.prototype.presentModal = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal, data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: src_app_components_stock_quantity_stock_quantity_page__WEBPACK_IMPORTED_MODULE_7__["StockQuantityPage"],
                            cssClass: 'my-custom-modal-css',
                            componentProps: {
                                stockName: this.stockItemsForRows[0].stockName, stockQty: this.stockQty, totalStck: this.stockItemsForRows[0].qtyOfStockAvailable
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, modal.onDidDismiss()];
                    case 3:
                        data = (_a.sent()).data;
                        console.log(data);
                        delete this.stockItems;
                        console.log(this.stockItemsForRows);
                        this.productString.value = '';
                        this.addToRows(data);
                        return [2 /*return*/];
                }
            });
        });
    };
    NewSalesPage.prototype.addToRows = function (dat) {
        console.log(23);
        this.stockItemsForRows[0].stockQty = dat.stockQty;
        this.stockItemsForRows[0].price = dat.stockQty * this.stockItemsForRows[0].currentRateOfStock;
        this.rows.push(this.stockItemsForRows[0]);
        console.log(this.rows);
        this.rows = this.rows.slice();
        this.calculateTotal();
    };
    NewSalesPage.prototype.deleteThisRow = function (eve, rw) {
        console.log(eve);
        this.rows.splice(eve, 1);
        this.rows = this.rows.slice();
        this.calculateTotal();
    };
    NewSalesPage.prototype.calculateTotal = function () {
        var totalPrice = 0;
        this.rows.forEach(function (k, v) {
            var totalTemp = k.stockQty * k.currentRateOfStock;
            totalPrice = totalPrice + totalTemp;
        });
        this.totalPriceOfInv = totalPrice;
    };
    NewSalesPage.prototype.saveInvoice = function (action) {
        var _this = this;
        this.customerSaleData.customerPurchasesList = [];
        this.rows.forEach(function (k, v) {
            var customerTemp = {};
            customerTemp.stockDomainId = k.id;
            customerTemp.quantityPurchased = k.stockQty;
            customerTemp.rateOfStock = k.currentRateOfStock;
            customerTemp.price = k.price;
            customerTemp.customerId = _this.customerDbObj.id;
            customerTemp.totalInvoiceAmt = _this.totalPriceOfInv;
            customerTemp.isCancelled = 'NEW';
            _this.customerSaleData.customerPurchasesList.push(customerTemp);
        });
        this.customerSaleData.customerId = this.customerDbObj.id;
        this.customerSaleData.paymentAmount = this.totalPriceOfInv;
        this.customerSaleData.paymentMode = '';
        this.customerSaleData.paymentReferenceNo = '';
        this.customerSaleData.totalInvoiceAmt = this.totalPriceOfInv;
        console.log(this.customerSaleData);
        this.salesService.saveStock(this.customerSaleData).subscribe(function (res) {
            console.log(res);
            _this.flashService.showGreen(res.error, 4000);
            _this.resetForm();
            if (action === 'print') {
                _this.salesService.printSalesRecipt(res.document).subscribe(function (response) {
                    console.log(response);
                    _this.commonService.saveFile(response);
                }, function (err) {
                    console.log(err);
                });
            }
            else if (action === 'mail') {
                _this.salesService.emailReciept(res.document).subscribe(function (response) {
                    console.log(response);
                }, function (err) {
                    console.log(err);
                });
            }
        }, function (err) {
            _this.flashService.showRed(err.error, 4000);
            console.log(err);
        });
    };
    NewSalesPage.prototype.resetForm = function () {
        this.showHide = false;
        this.rows = [];
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"])('invTable'),
        __metadata("design:type", _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__["DatatableComponent"])
    ], NewSalesPage.prototype, "invTable", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"])('productString'),
        __metadata("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonSearchbar"])
    ], NewSalesPage.prototype, "productString", void 0);
    NewSalesPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-new-sales',
            template: __webpack_require__(/*! ./new-sales.page.html */ "./src/app/pages/sales/new-sales/new-sales.page.html"),
            styles: [__webpack_require__(/*! ./new-sales.page.scss */ "./src/app/pages/sales/new-sales/new-sales.page.scss")]
        }),
        __metadata("design:paramtypes", [_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__["CustomerService"],
            src_app_services_stock_stock_service__WEBPACK_IMPORTED_MODULE_6__["StockService"],
            _services_sales_sales_service__WEBPACK_IMPORTED_MODULE_1__["SalesService"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__["FlashMessageService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"],
            src_app_services_common_common_util_service__WEBPACK_IMPORTED_MODULE_8__["CommonUtilService"]])
    ], NewSalesPage);
    return NewSalesPage;
}());



/***/ })

}]);
//# sourceMappingURL=new-sales-new-sales-module.js.map