(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-stockmanagment-store-module"],{

/***/ "./src/app/pages/stockmanagment/store-routing.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/pages/stockmanagment/store-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: StoreRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StoreRoutingModule", function() { return StoreRoutingModule; });
/* harmony import */ var _services_stock_stock_sales_resolve_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/stock/stock-sales-resolve.service */ "./src/app/services/stock/stock-sales-resolve.service.ts");
/* harmony import */ var _services_stock_stock_details_resolve_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/stock/stock-details-resolve.service */ "./src/app/services/stock/stock-details-resolve.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _store_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./store.page */ "./src/app/pages/stockmanagment/store.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var routes = [
    {
        path: '',
        component: _store_page__WEBPACK_IMPORTED_MODULE_4__["StorePage"],
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'newstock'
            },
            {
                path: 'newstock',
                children: [
                    {
                        path: '',
                        loadChildren: './new-stock/new-stock.module#NewStockPageModule'
                    },
                ]
            },
            {
                path: 'searchstock',
                children: [
                    {
                        path: '',
                        loadChildren: './update-stock-items/update-stock-items.module#UpdateStockItemsPageModule'
                    },
                ]
            },
            { path: 'details',
                children: [
                    {
                        path: ':id',
                        loadChildren: './stock-details/stock-details.module#StockDetailsPageModule',
                        resolve: {
                            data: _services_stock_stock_details_resolve_service__WEBPACK_IMPORTED_MODULE_1__["StockDetailsResolveService"],
                            stockSales: _services_stock_stock_sales_resolve_service__WEBPACK_IMPORTED_MODULE_0__["StockSalesResolveService"]
                        }
                    }
                ]
            }
        ]
    },
];
var StoreRoutingModule = /** @class */ (function () {
    function StoreRoutingModule() {
    }
    StoreRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], StoreRoutingModule);
    return StoreRoutingModule;
}());



/***/ }),

/***/ "./src/app/pages/stockmanagment/store.module.ts":
/*!******************************************************!*\
  !*** ./src/app/pages/stockmanagment/store.module.ts ***!
  \******************************************************/
/*! exports provided: StorePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorePageModule", function() { return StorePageModule; });
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_component_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _store_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./store.page */ "./src/app/pages/stockmanagment/store.page.ts");
/* harmony import */ var _store_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./store-routing.module */ "./src/app/pages/stockmanagment/store-routing.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var StorePageModule = /** @class */ (function () {
    function StorePageModule() {
    }
    StorePageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _components_component_module__WEBPACK_IMPORTED_MODULE_1__["ComponentModule"],
                _store_routing_module__WEBPACK_IMPORTED_MODULE_7__["StoreRoutingModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_0__["NgxDatatableModule"]
            ],
            declarations: [_store_page__WEBPACK_IMPORTED_MODULE_6__["StorePage"]]
        })
    ], StorePageModule);
    return StorePageModule;
}());



/***/ }),

/***/ "./src/app/pages/stockmanagment/store.page.html":
/*!******************************************************!*\
  !*** ./src/app/pages/stockmanagment/store.page.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\r\n\r\n<ion-content padding>\r\n    <ng-container>\r\n\r\n    </ng-container>\r\n    <ng-template>\r\n        <ion-card>\r\n            <ion-router-outlet></ion-router-outlet>\r\n        </ion-card>\r\n\r\n    </ng-template>\r\n\r\n    <ion-tabs>\r\n        <ion-tab-bar slot=\"top\">\r\n            <ion-tab-button tab=\"newstock\">\r\n                <ion-icon name=\"person-add\"></ion-icon>\r\n                <ion-label>New Stock/Items</ion-label>\r\n\r\n            </ion-tab-button>\r\n\r\n            <ion-tab-button tab=\"searchstock\">\r\n                <ion-icon name=\"search\"></ion-icon>\r\n                <ion-label>Search/Update Items</ion-label>\r\n            </ion-tab-button>\r\n\r\n            <ion-tab-button tab=\"details\">\r\n                <ion-icon name=\"grid\"></ion-icon>\r\n                <ion-label>Details Page</ion-label>\r\n            </ion-tab-button>\r\n        </ion-tab-bar>\r\n    </ion-tabs>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/stockmanagment/store.page.scss":
/*!******************************************************!*\
  !*** ./src/app/pages/stockmanagment/store.page.scss ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N0b2NrbWFuYWdtZW50L3N0b3JlLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/stockmanagment/store.page.ts":
/*!****************************************************!*\
  !*** ./src/app/pages/stockmanagment/store.page.ts ***!
  \****************************************************/
/*! exports provided: StorePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorePage", function() { return StorePage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var StorePage = /** @class */ (function () {
    function StorePage() {
    }
    StorePage.prototype.ngOnInit = function () {
    };
    StorePage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-store',
            template: __webpack_require__(/*! ./store.page.html */ "./src/app/pages/stockmanagment/store.page.html"),
            styles: [__webpack_require__(/*! ./store.page.scss */ "./src/app/pages/stockmanagment/store.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], StorePage);
    return StorePage;
}());



/***/ }),

/***/ "./src/app/services/stock/stock-details-resolve.service.ts":
/*!*****************************************************************!*\
  !*** ./src/app/services/stock/stock-details-resolve.service.ts ***!
  \*****************************************************************/
/*! exports provided: StockDetailsResolveService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsResolveService", function() { return StockDetailsResolveService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _stock_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stock.service */ "./src/app/services/stock/stock.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var StockDetailsResolveService = /** @class */ (function () {
    function StockDetailsResolveService(stockService) {
        this.stockService = stockService;
    }
    StockDetailsResolveService.prototype.resolve = function (route, state) {
        var id = route.paramMap.get('id');
        return this.stockService.getStockbyId(id);
    };
    StockDetailsResolveService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_stock_service__WEBPACK_IMPORTED_MODULE_1__["StockService"]])
    ], StockDetailsResolveService);
    return StockDetailsResolveService;
}());



/***/ }),

/***/ "./src/app/services/stock/stock-sales-resolve.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/services/stock/stock-sales-resolve.service.ts ***!
  \***************************************************************/
/*! exports provided: StockSalesResolveService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockSalesResolveService", function() { return StockSalesResolveService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _stock_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stock.service */ "./src/app/services/stock/stock.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var StockSalesResolveService = /** @class */ (function () {
    function StockSalesResolveService(stockService) {
        this.stockService = stockService;
    }
    StockSalesResolveService.prototype.resolve = function (route, state) {
        var id = route.paramMap.get('id');
        return this.stockService.getSalesStockDetailsById(Number(id));
    };
    StockSalesResolveService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_stock_service__WEBPACK_IMPORTED_MODULE_1__["StockService"]])
    ], StockSalesResolveService);
    return StockSalesResolveService;
}());



/***/ })

}]);
//# sourceMappingURL=pages-stockmanagment-store-module.js.map