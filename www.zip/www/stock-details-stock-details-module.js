(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["stock-details-stock-details-module"],{

/***/ "./src/app/pages/stockmanagment/stock-details/stock-details.module.ts":
/*!****************************************************************************!*\
  !*** ./src/app/pages/stockmanagment/stock-details/stock-details.module.ts ***!
  \****************************************************************************/
/*! exports provided: StockDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsPageModule", function() { return StockDetailsPageModule; });
/* harmony import */ var _components_component_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _stock_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./stock-details.page */ "./src/app/pages/stockmanagment/stock-details/stock-details.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        component: _stock_details_page__WEBPACK_IMPORTED_MODULE_6__["StockDetailsPage"]
    }
];
var StockDetailsPageModule = /** @class */ (function () {
    function StockDetailsPageModule() {
    }
    StockDetailsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _components_component_module__WEBPACK_IMPORTED_MODULE_0__["ComponentModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_stock_details_page__WEBPACK_IMPORTED_MODULE_6__["StockDetailsPage"]]
        })
    ], StockDetailsPageModule);
    return StockDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/pages/stockmanagment/stock-details/stock-details.page.html":
/*!****************************************************************************!*\
  !*** ./src/app/pages/stockmanagment/stock-details/stock-details.page.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar>\r\n        <ion-title>Stock Details</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content padding>\r\n\r\n    <ion-card>\r\n        <ion-card-header color=\"primary\">\r\n            <ion-card-title>\r\n                {{stockDetailsDb.stockName}}  - Stock ID {{stockDetailsDb.id}}\r\n            </ion-card-title>\r\n        </ion-card-header>\r\n        <ion-card-content>\r\n\r\n            <ion-grid>\r\n\r\n                <ion-row>\r\n\r\n                    <ion-col align-self-stretch size=\"3\">\r\n                        <ion-segment [(ngModel)]=\"customercomp\" color=\"primary\">\r\n\r\n\r\n                            <ion-segment-button value=\"stockDetails\" float-left>\r\n                                 Details/Summary\r\n                            </ion-segment-button>\r\n                            <ion-segment-button float-left value=\"stockUpdates\">\r\n                                 Update                            </ion-segment-button>\r\n                            <!-- <ion-segment-button float-left value=\"stockUpdateHistory\">\r\n                                 Update History\r\n                            </ion-segment-button>\r\n                            <ion-segment-button float-left value=\"stockPurchaseHistory\">\r\n                                 Purchase History\r\n                            </ion-segment-button> -->\r\n                           \r\n                        </ion-segment>\r\n                    </ion-col>\r\n                    <ion-col [ngSwitch]=\"customercomp\">\r\n                      <app-stock-details  *ngSwitchCase=\"'stockDetails'\"></app-stock-details>\r\n                      <app-stock-update *ngSwitchCase=\"'stockUpdates'\"></app-stock-update>\r\n                      <app-stock-update-history *ngSwitchCase=\"'stockUpdateHistory'\"></app-stock-update-history>\r\n                      <app-stock-purchase-histroy *ngSwitchCase=\"'stockPurchaseHistory'\" ></app-stock-purchase-histroy>\r\n                      \r\n                    </ion-col>\r\n                </ion-row>\r\n\r\n            </ion-grid>\r\n\r\n        </ion-card-content>\r\n\r\n    </ion-card>\r\n\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/stockmanagment/stock-details/stock-details.page.scss":
/*!****************************************************************************!*\
  !*** ./src/app/pages/stockmanagment/stock-details/stock-details.page.scss ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-segment {\n  display: block;\n  white-space: normal;\n  font-size: 0;\n  overflow: auto;\n  word-wrap: break-word; }\n  ion-segment::-webkit-scrollbar {\n    width: 0;\n    height: 0;\n    display: none; }\n  ion-segment ion-segment-button.segment-button {\n    display: inline-block;\n    min-width: 100px;\n    width: auto; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc3RvY2ttYW5hZ21lbnQvc3RvY2stZGV0YWlscy9DOlxcQmFzaWNzXFxDXFxwb2ludGVyc1xcc2Fhb2xoZWFydFVJL3NyY1xcYXBwXFxwYWdlc1xcc3RvY2ttYW5hZ21lbnRcXHN0b2NrLWRldGFpbHNcXHN0b2NrLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBYztFQUNkLG9CQUFtQjtFQUNuQixhQUFZO0VBQ1osZUFBYztFQUNkLHNCQUFxQixFQVd4QjtFQWhCRDtJQU9RLFNBQVE7SUFDUixVQUFTO0lBQ1QsY0FBYSxFQUNoQjtFQVZMO0lBWVEsc0JBQXFCO0lBQ3JCLGlCQUFnQjtJQUNoQixZQUFXLEVBQ2QiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9zdG9ja21hbmFnbWVudC9zdG9jay1kZXRhaWxzL3N0b2NrLWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXNlZ21lbnQge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB3aGl0ZS1zcGFjZTogbm9ybWFsO1xyXG4gICAgZm9udC1zaXplOiAwO1xyXG4gICAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgICB3b3JkLXdyYXA6IGJyZWFrLXdvcmQ7XHJcbiAgICAmOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgICAgICAgd2lkdGg6IDA7XHJcbiAgICAgICAgaGVpZ2h0OiAwO1xyXG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICB9XHJcbiAgICBpb24tc2VnbWVudC1idXR0b24uc2VnbWVudC1idXR0b24ge1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICBtaW4td2lkdGg6IDEwMHB4O1xyXG4gICAgICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgfVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/stockmanagment/stock-details/stock-details.page.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/stockmanagment/stock-details/stock-details.page.ts ***!
  \**************************************************************************/
/*! exports provided: StockDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsPage", function() { return StockDetailsPage; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var StockDetailsPage = /** @class */ (function () {
    function StockDetailsPage(activate) {
        this.activate = activate;
        this.customercomp = '';
        this.customercomp = 'stockDetails';
        this.stockDetailsDb = this.activate.snapshot.data['data'];
    }
    StockDetailsPage.prototype.ngOnInit = function () {
    };
    StockDetailsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stock-details-main',
            template: __webpack_require__(/*! ./stock-details.page.html */ "./src/app/pages/stockmanagment/stock-details/stock-details.page.html"),
            styles: [__webpack_require__(/*! ./stock-details.page.scss */ "./src/app/pages/stockmanagment/stock-details/stock-details.page.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_0__["ActivatedRoute"]])
    ], StockDetailsPage);
    return StockDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=stock-details-stock-details-module.js.map