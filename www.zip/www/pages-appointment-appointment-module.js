(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-appointment-appointment-module"],{

/***/ "./src/app/pages/appointment/appointment.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/appointment/appointment.module.ts ***!
  \*********************************************************/
/*! exports provided: AppointmentPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppointmentPageModule", function() { return AppointmentPageModule; });
/* harmony import */ var ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ng-pick-datetime/dialog */ "./node_modules/ng-pick-datetime/dialog/index.js");
/* harmony import */ var ng_pick_datetime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ng-pick-datetime */ "./node_modules/ng-pick-datetime/picker.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_component_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _appointment_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./appointment.page */ "./src/app/pages/appointment/appointment.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var routes = [
    {
        path: '',
        component: _appointment_page__WEBPACK_IMPORTED_MODULE_9__["AppointmentPage"]
    }
];
var AppointmentPageModule = /** @class */ (function () {
    function AppointmentPageModule() {
    }
    AppointmentPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_5__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicModule"],
                _components_component_module__WEBPACK_IMPORTED_MODULE_3__["ComponentModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_2__["NgxDatatableModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_1__["OwlDateTimeModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_1__["OwlNativeDateTimeModule"],
                ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_0__["OwlDialogModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouterModule"].forChild(routes)
            ],
            providers: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["DatePipe"]],
            declarations: [_appointment_page__WEBPACK_IMPORTED_MODULE_9__["AppointmentPage"]]
        })
    ], AppointmentPageModule);
    return AppointmentPageModule;
}());



/***/ }),

/***/ "./src/app/pages/appointment/appointment.page.html":
/*!*********************************************************!*\
  !*** ./src/app/pages/appointment/appointment.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\r\n<ion-content>\r\n<ion-card>\r\n  <ion-card-header>\r\n    <ion-card-title>\r\n      Doctor Appointment\r\n    </ion-card-title>\r\n    <ion-card-subtitle>\r\n      Today's Appointment\r\n    </ion-card-subtitle>\r\n    <input class=\"ion-input\"  [(ngModel)]=\"dateTime\" [owlDateTimeFilter]=\"myFilter\" [owlDateTime]=\"dt1\" id=\"consulatationDate\"   [owlDateTimeTrigger]=\"dt1\" placeholder=\"Date Time\"/>\r\n    <owl-date-time #dt1 hour12Timer=\"true\" stepHour=\"1\" pickerType=\"calendar\" stepMinute=\"30\"> </owl-date-time>\r\n<ion-button (click)=\"getListByDate(dateTime)\"> Search</ion-button>\r\n  </ion-card-header> \r\n  <ion-card-content>\r\n      <ion-list> \r\n          <ion-list-header>\r\n              <ion-label>Today's Customer List</ion-label>\r\n          </ion-list-header>\r\n          <!-- <ion-virtual-scroll> -->\r\n            <div *ngFor=\"let patient of patientList\">\r\n          <ion-item class=\"ion-activatable\" ion-activatable >\r\n           \r\n              <ion-ripple-effect (click)=\"markAppointmentAlert(patient)\"></ion-ripple-effect>\r\n              <ion-label>\r\n                  <h4>{{patient.customerName}}</h4> \r\n                  <p>Expected Time {{patient.expectedTime | date:'medium' }}</p>\r\n                  <p>\r\n                    Visit Status  {{patient.isVisitDone}}\r\n                 </p>\r\n                  <p>Visit No<ion-badge slot=\"end\">  {{patient.visitNumber != null ? patient.visitNumber : \"Yet To visit\" }}</ion-badge></p>\r\n              </ion-label>           \r\n          </ion-item>\r\n        </div>\r\n          <!-- </ion-virtual-scroll> -->\r\n      </ion-list>\r\n  </ion-card-content>\r\n  <ion-row class=\"cardfooter\">\r\n      <ion-col>\r\n          <p>Total Patient Pending {{patientList?.length}}</p>\r\n      </ion-col>\r\n  </ion-row>\r\n</ion-card>\r\n\r\n<ion-item-divider></ion-item-divider>\r\n\r\n<ion-card>\r\n  <ion-card-header>\r\n    <ion-card-title>\r\n      Doctor's Appointment Table\r\n    </ion-card-title>\r\n  </ion-card-header>\r\n  <ion-card-content>\r\n    \r\n    <!-- <ion-searchbar (ionInput)=\"getCustomerListBySearch($event)\" animated showCancelButton cancelButtonText=\"Custom Cancel\"></ion-searchbar> -->\r\n    <ngx-datatable #myTable class='material' [columnMode]=\"'standard'\" [headerHeight]=\"50\" \r\n    [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"50\" [scrollbarV]=\"'true'\" [scrollbarH]=\"'true'\" [rows]='rows'>\r\n        <!-- Row Detail Template -->\r\n        <!-- <ngx-datatable-row-detail [rowHeight]=\"getHeight()\" #myDetailRow>\r\n            <ng-template let-row=\"row\" let-rowIndex=\"rowIndex\" ngx-datatable-row-detail-template>\r\n                <div><strong>Address</strong></div>\r\n                <div class=\"row-wrap\">{{row.address}}</div>\r\n            </ng-template>\r\n        </ngx-datatable-row-detail> -->\r\n        <!-- Column Templates -->\r\n        <!-- <ngx-datatable-column [width]=\"50\">\r\n            <ng-template let-row=\"row\" let-expanded=\"expanded\" ngx-datatable-cell-template>\r\n                <a href=\"javascript:void(0)\" [class.datatable-icon-right]=\"!expanded\" [class.datatable-icon-down]=\"expanded\" title=\"Expand/Collapse Row\" (click)=\"toggleExpandRow(row,expanded)\">\r\n                </a>\r\n            </ng-template>\r\n        </ngx-datatable-column> -->\r\n        <ngx-datatable-column name=\"Sr No\" width=\"80\">\r\n            <ng-template let-rowIndex=\"rowIndex\" let-row=\"row\" ngx-datatable-cell-template>\r\n                <strong>{{rowIndex+1}}</strong>\r\n            </ng-template>\r\n        </ngx-datatable-column>\r\n        <ngx-datatable-column name=\"Customer Id\" width=\"180\">\r\n            <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n                <a [routerDirection]=\"'forward'\" [routerLink]=\"['/customer/details/',row.customerId]\">\r\n                    <b><i> {{row.customerId}}  </i></b>\r\n                </a> \r\n            </ng-template>\r\n        </ngx-datatable-column>\r\n        <ngx-datatable-column name=\"Name\" width=\"150\">\r\n          <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n              <strong>{{row.customerName}}</strong>\r\n          </ng-template>\r\n      </ngx-datatable-column>\r\n        <ngx-datatable-column name=\"Appointment (Date and Time) \" width=\"300\">\r\n          <ng-template let-row=\"row\" ngx-datatable-cell-template>\r\n              <strong>{{row.expectedTime | date : 'MMM d, y, h:mm:ss a' }} </strong>\r\n          </ng-template>\r\n      </ngx-datatable-column>\r\n      \r\n        <ngx-datatable-column name=\"Visiting For\" width=\"50\">\r\n            <ng-template let-row=\"row\" let-value=\"value\" ngx-datatable-cell-template>\r\n                <strong>{{row.visitingForDescription}}</strong>\r\n            </ng-template>\r\n        </ngx-datatable-column>\r\n       \r\n    </ngx-datatable>\r\n  </ion-card-content>\r\n</ion-card>\r\n</ion-content>"

/***/ }),

/***/ "./src/app/pages/appointment/appointment.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/appointment/appointment.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FwcG9pbnRtZW50L2FwcG9pbnRtZW50LnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/appointment/appointment.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/appointment/appointment.page.ts ***!
  \*******************************************************/
/*! exports provided: AppointmentPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppointmentPage", function() { return AppointmentPage; });
/* harmony import */ var src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var src_app_services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dashboard/dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};





var AppointmentPage = /** @class */ (function () {
    function AppointmentPage(dashboardService, alertController, flashService, datePipe) {
        this.dashboardService = dashboardService;
        this.alertController = alertController;
        this.flashService = flashService;
        this.datePipe = datePipe;
        this.dateTime = new Date();
        this.rows = [];
        this.columns = [];
        this.patientList = [];
        this.myFilter = function (d) {
            var day = d.getDay();
            return day !== 0;
        };
        this.getAllAppointmentList();
        this.getListByDate(new Date());
    }
    AppointmentPage.prototype.ngOnInit = function () {
    };
    AppointmentPage.prototype.getAllAppointmentList = function () {
        var _this = this;
        this.dashboardService.getAllAppointment().subscribe(function (res) {
            console.log(res);
            _this.rows = res.document;
            if (_this.rows !== null && _this.rows.length > 0) {
                _this.rows = _this.rows.slice();
            }
        }, function (err) {
            console.log(err);
        });
    };
    AppointmentPage.prototype.getListByDate = function (res) {
        var _this = this;
        this.dashboardService.getAppointmentForDate(Object(_angular_common__WEBPACK_IMPORTED_MODULE_4__["formatDate"])(res, 'dd-MM-yyyy', 'en-US', '+0530')).subscribe(function (response) {
            _this.patientList = response.document;
            console.log(response);
        }, function (err) {
            console.log(err);
        });
    };
    ;
    AppointmentPage.prototype.markAppointmentAlert = function (appoint) {
        return __awaiter(this, void 0, void 0, function () {
            var alert_1, err, err;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(appoint.isVisitDone !== 'Completed')) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.alertController.create({
                                header: 'Is Visit Done?',
                                inputs: [
                                    {
                                        name: 'radio1',
                                        type: 'radio',
                                        label: 'Yes',
                                        value: 'Completed'
                                    },
                                    {
                                        name: 'radio2',
                                        type: 'radio',
                                        label: 'No',
                                        value: 'Cancelled'
                                    }
                                ],
                                buttons: [
                                    {
                                        text: 'Cancel',
                                        role: 'cancel',
                                        cssClass: 'secondary',
                                        handler: function (res) {
                                        }
                                    }, {
                                        text: 'Ok',
                                        handler: function (res) {
                                            console.log(res);
                                            console.log(appoint);
                                            _this.markAppointmentStat = appoint;
                                            _this.markAppointmentStat.isVisitDone = res;
                                            _this.markAppointmentStatus(_this.markAppointmentStat);
                                        }
                                    }
                                ]
                            })];
                    case 1:
                        alert_1 = _a.sent();
                        return [4 /*yield*/, alert_1.present()];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        if (appoint.isVisitDone === 'Cancelled') {
                            err = [];
                            err.push('Customer DR. Appointment Cancelled');
                            this.flashService.showGreen(err, 6000);
                        }
                        else {
                            err = [];
                            err.push('Pateint Appointment Already Completed');
                            this.flashService.showRed(err, 5000);
                        }
                        _a.label = 4;
                    case 4: return [2 /*return*/];
                }
            });
        });
    };
    AppointmentPage.prototype.markAppointmentStatus = function (res) {
        var _this = this;
        this.dashboardService.markPatientAppointment(res).subscribe(function (res) {
            var err = [];
            err.push('Pateint Appointment Marked as Completed');
            _this.flashService.showGreen(err, 5000);
        }, function (err) {
            console.log(err);
        });
    };
    AppointmentPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-appointment',
            template: __webpack_require__(/*! ./appointment.page.html */ "./src/app/pages/appointment/appointment.page.html"),
            styles: [__webpack_require__(/*! ./appointment.page.scss */ "./src/app/pages/appointment/appointment.page.scss")]
        }),
        __metadata("design:paramtypes", [src_app_services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_2__["DashboardService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"],
            src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__["FlashMessageService"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["DatePipe"]])
    ], AppointmentPage);
    return AppointmentPage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-appointment-appointment-module.js.map