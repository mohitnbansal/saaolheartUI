(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./1e1lwhxn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1e1lwhxn.entry.js",
		"common",
		7
	],
	"./1e1lwhxn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1e1lwhxn.sc.entry.js",
		"common",
		8
	],
	"./2tjkwyhl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2tjkwyhl.entry.js",
		"common",
		9
	],
	"./2tjkwyhl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2tjkwyhl.sc.entry.js",
		"common",
		10
	],
	"./3pxgehyl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pxgehyl.entry.js",
		"common",
		11
	],
	"./3pxgehyl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pxgehyl.sc.entry.js",
		"common",
		12
	],
	"./49o9o5h3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/49o9o5h3.entry.js",
		"common",
		13
	],
	"./49o9o5h3.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/49o9o5h3.sc.entry.js",
		"common",
		14
	],
	"./5y5zcspa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5y5zcspa.entry.js",
		"common",
		15
	],
	"./5y5zcspa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5y5zcspa.sc.entry.js",
		"common",
		16
	],
	"./6bbt6vsj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6bbt6vsj.entry.js",
		"common",
		17
	],
	"./6bbt6vsj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6bbt6vsj.sc.entry.js",
		"common",
		18
	],
	"./6k2gc4xu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6k2gc4xu.entry.js",
		"common",
		19
	],
	"./6k2gc4xu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6k2gc4xu.sc.entry.js",
		"common",
		20
	],
	"./8a8xsnyx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8a8xsnyx.entry.js",
		"common",
		21
	],
	"./8a8xsnyx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8a8xsnyx.sc.entry.js",
		"common",
		22
	],
	"./9krzzaho.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9krzzaho.entry.js",
		"common",
		23
	],
	"./9krzzaho.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9krzzaho.sc.entry.js",
		"common",
		24
	],
	"./9x0euats.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9x0euats.entry.js",
		"common",
		25
	],
	"./9x0euats.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9x0euats.sc.entry.js",
		"common",
		26
	],
	"./9zk2zdku.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9zk2zdku.entry.js",
		"common",
		27
	],
	"./9zk2zdku.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9zk2zdku.sc.entry.js",
		"common",
		28
	],
	"./aarlbodj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aarlbodj.entry.js",
		"common",
		29
	],
	"./aarlbodj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aarlbodj.sc.entry.js",
		"common",
		30
	],
	"./agg6vkjj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/agg6vkjj.entry.js",
		"common",
		107
	],
	"./agg6vkjj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/agg6vkjj.sc.entry.js",
		"common",
		108
	],
	"./aghoxox8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aghoxox8.entry.js",
		0,
		"common",
		125
	],
	"./aghoxox8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/aghoxox8.sc.entry.js",
		0,
		"common",
		126
	],
	"./antkeoru.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/antkeoru.entry.js",
		"common",
		109
	],
	"./antkeoru.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/antkeoru.sc.entry.js",
		"common",
		110
	],
	"./bjuqyqjq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bjuqyqjq.entry.js",
		"common",
		31
	],
	"./bjuqyqjq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bjuqyqjq.sc.entry.js",
		"common",
		32
	],
	"./bkd8if1l.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bkd8if1l.entry.js",
		"common",
		33
	],
	"./bkd8if1l.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bkd8if1l.sc.entry.js",
		"common",
		34
	],
	"./brl2soq6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/brl2soq6.entry.js",
		"common",
		127
	],
	"./brl2soq6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/brl2soq6.sc.entry.js",
		"common",
		128
	],
	"./c2cxmmuy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2cxmmuy.entry.js",
		"common",
		35
	],
	"./c2cxmmuy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2cxmmuy.sc.entry.js",
		"common",
		36
	],
	"./c4yw1e0r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c4yw1e0r.entry.js",
		0,
		"common",
		129
	],
	"./c4yw1e0r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c4yw1e0r.sc.entry.js",
		0,
		"common",
		130
	],
	"./cbfv9gge.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cbfv9gge.entry.js",
		0,
		"common",
		131
	],
	"./cbfv9gge.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cbfv9gge.sc.entry.js",
		0,
		"common",
		132
	],
	"./chjxzrpb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/chjxzrpb.entry.js",
		"common",
		37
	],
	"./chjxzrpb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/chjxzrpb.sc.entry.js",
		"common",
		38
	],
	"./czngpjkk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/czngpjkk.entry.js",
		"common",
		39
	],
	"./czngpjkk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/czngpjkk.sc.entry.js",
		"common",
		40
	],
	"./dnz3py7p.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dnz3py7p.entry.js",
		"common",
		41
	],
	"./dnz3py7p.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dnz3py7p.sc.entry.js",
		"common",
		42
	],
	"./dpzwg5qg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dpzwg5qg.entry.js",
		"common",
		43
	],
	"./dpzwg5qg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dpzwg5qg.sc.entry.js",
		"common",
		44
	],
	"./e8nc6yw9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/e8nc6yw9.entry.js",
		"common",
		45
	],
	"./e8nc6yw9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/e8nc6yw9.sc.entry.js",
		"common",
		46
	],
	"./ffukzwt6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.entry.js",
		"common",
		111
	],
	"./ffukzwt6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.sc.entry.js",
		"common",
		112
	],
	"./fiqi6app.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.entry.js",
		133
	],
	"./fiqi6app.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.sc.entry.js",
		134
	],
	"./gtepchdk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gtepchdk.entry.js",
		"common",
		47
	],
	"./gtepchdk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gtepchdk.sc.entry.js",
		"common",
		48
	],
	"./hhzifqsd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hhzifqsd.entry.js",
		"common",
		49
	],
	"./hhzifqsd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hhzifqsd.sc.entry.js",
		"common",
		50
	],
	"./hmdxtd3s.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hmdxtd3s.entry.js",
		"common",
		51
	],
	"./hmdxtd3s.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hmdxtd3s.sc.entry.js",
		"common",
		52
	],
	"./iuedsi0t.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iuedsi0t.entry.js",
		0,
		"common",
		136
	],
	"./iuedsi0t.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iuedsi0t.sc.entry.js",
		0,
		"common",
		137
	],
	"./j0pt8hcq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j0pt8hcq.entry.js",
		"common",
		53
	],
	"./j0pt8hcq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j0pt8hcq.sc.entry.js",
		"common",
		54
	],
	"./jpicf8nq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpicf8nq.entry.js",
		0,
		"common",
		138
	],
	"./jpicf8nq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpicf8nq.sc.entry.js",
		0,
		"common",
		139
	],
	"./jy3flzug.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jy3flzug.entry.js",
		"common",
		55
	],
	"./jy3flzug.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jy3flzug.sc.entry.js",
		"common",
		56
	],
	"./kck6ua3e.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kck6ua3e.entry.js",
		"common",
		57
	],
	"./kck6ua3e.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kck6ua3e.sc.entry.js",
		"common",
		58
	],
	"./kiczugb2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kiczugb2.entry.js",
		"common",
		59
	],
	"./kiczugb2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kiczugb2.sc.entry.js",
		"common",
		60
	],
	"./ksoxq4it.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ksoxq4it.entry.js",
		"common",
		61
	],
	"./ksoxq4it.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ksoxq4it.sc.entry.js",
		"common",
		62
	],
	"./ljphalmn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ljphalmn.entry.js",
		"common",
		140
	],
	"./ljphalmn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ljphalmn.sc.entry.js",
		"common",
		141
	],
	"./ltv1fuwh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ltv1fuwh.entry.js",
		"common",
		63
	],
	"./ltv1fuwh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ltv1fuwh.sc.entry.js",
		"common",
		64
	],
	"./lzs97kyo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lzs97kyo.entry.js",
		0,
		"common",
		142
	],
	"./lzs97kyo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lzs97kyo.sc.entry.js",
		0,
		"common",
		143
	],
	"./niqocyfi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/niqocyfi.entry.js",
		"common",
		113
	],
	"./niqocyfi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/niqocyfi.sc.entry.js",
		"common",
		114
	],
	"./noi12jvo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/noi12jvo.entry.js",
		"common",
		65
	],
	"./noi12jvo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/noi12jvo.sc.entry.js",
		"common",
		66
	],
	"./nvqajvxi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nvqajvxi.entry.js",
		"common",
		115
	],
	"./nvqajvxi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nvqajvxi.sc.entry.js",
		"common",
		116
	],
	"./oi5m6und.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oi5m6und.entry.js",
		0,
		"common",
		145
	],
	"./oi5m6und.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oi5m6und.sc.entry.js",
		0,
		"common",
		146
	],
	"./oiasnoqb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiasnoqb.entry.js",
		"common",
		67
	],
	"./oiasnoqb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiasnoqb.sc.entry.js",
		"common",
		68
	],
	"./ol4uvmo9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ol4uvmo9.entry.js",
		"common",
		117
	],
	"./ol4uvmo9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ol4uvmo9.sc.entry.js",
		"common",
		118
	],
	"./otghaj78.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/otghaj78.entry.js",
		"common",
		69
	],
	"./otghaj78.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/otghaj78.sc.entry.js",
		"common",
		70
	],
	"./ozwp9pzo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ozwp9pzo.entry.js",
		"common",
		119
	],
	"./ozwp9pzo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ozwp9pzo.sc.entry.js",
		"common",
		120
	],
	"./pdegz0x5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pdegz0x5.entry.js",
		"common",
		71
	],
	"./pdegz0x5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pdegz0x5.sc.entry.js",
		"common",
		72
	],
	"./pmwcfesb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pmwcfesb.entry.js",
		"common",
		73
	],
	"./pmwcfesb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pmwcfesb.sc.entry.js",
		"common",
		74
	],
	"./q4ausyqh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/q4ausyqh.entry.js",
		"common",
		75
	],
	"./q4ausyqh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/q4ausyqh.sc.entry.js",
		"common",
		76
	],
	"./r407uyvp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r407uyvp.entry.js",
		0,
		"common",
		147
	],
	"./r407uyvp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r407uyvp.sc.entry.js",
		0,
		"common",
		148
	],
	"./rxnokk5b.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rxnokk5b.entry.js",
		"common",
		77
	],
	"./rxnokk5b.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rxnokk5b.sc.entry.js",
		"common",
		78
	],
	"./rzkohwjn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rzkohwjn.entry.js",
		"common",
		79
	],
	"./rzkohwjn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rzkohwjn.sc.entry.js",
		"common",
		80
	],
	"./s3ybubs3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s3ybubs3.entry.js",
		"common",
		81
	],
	"./s3ybubs3.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s3ybubs3.sc.entry.js",
		"common",
		82
	],
	"./s71xhyn8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s71xhyn8.entry.js",
		"common",
		83
	],
	"./s71xhyn8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s71xhyn8.sc.entry.js",
		"common",
		84
	],
	"./sffxespu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sffxespu.entry.js",
		0,
		"common",
		149
	],
	"./sffxespu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sffxespu.sc.entry.js",
		0,
		"common",
		150
	],
	"./sgttcxng.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sgttcxng.entry.js",
		"common",
		85
	],
	"./sgttcxng.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sgttcxng.sc.entry.js",
		"common",
		86
	],
	"./su9tg5yc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/su9tg5yc.entry.js",
		"common",
		87
	],
	"./su9tg5yc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/su9tg5yc.sc.entry.js",
		"common",
		88
	],
	"./tkxyzg9w.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tkxyzg9w.entry.js",
		0,
		"common",
		151
	],
	"./tkxyzg9w.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tkxyzg9w.sc.entry.js",
		0,
		"common",
		152
	],
	"./tlmwejgj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlmwejgj.entry.js",
		"common",
		121
	],
	"./tlmwejgj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlmwejgj.sc.entry.js",
		"common",
		122
	],
	"./u3uimr12.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/u3uimr12.entry.js",
		"common",
		89
	],
	"./u3uimr12.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/u3uimr12.sc.entry.js",
		"common",
		90
	],
	"./ulxnddae.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ulxnddae.entry.js",
		"common",
		123
	],
	"./ulxnddae.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ulxnddae.sc.entry.js",
		"common",
		124
	],
	"./unlmppwg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/unlmppwg.entry.js",
		0,
		"common",
		153
	],
	"./unlmppwg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/unlmppwg.sc.entry.js",
		0,
		"common",
		154
	],
	"./uowuginz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uowuginz.entry.js",
		"common",
		91
	],
	"./uowuginz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uowuginz.sc.entry.js",
		"common",
		92
	],
	"./upd0xxvz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/upd0xxvz.entry.js",
		0,
		"common",
		155
	],
	"./upd0xxvz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/upd0xxvz.sc.entry.js",
		0,
		"common",
		156
	],
	"./uyimihqy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uyimihqy.entry.js",
		"common",
		93
	],
	"./uyimihqy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uyimihqy.sc.entry.js",
		"common",
		94
	],
	"./vpiidhji.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vpiidhji.entry.js",
		"common",
		95
	],
	"./vpiidhji.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vpiidhji.sc.entry.js",
		"common",
		96
	],
	"./vsuqahpm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vsuqahpm.entry.js",
		"common",
		97
	],
	"./vsuqahpm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vsuqahpm.sc.entry.js",
		"common",
		98
	],
	"./vyy0257p.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vyy0257p.entry.js",
		0,
		"common",
		157
	],
	"./vyy0257p.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vyy0257p.sc.entry.js",
		0,
		"common",
		158
	],
	"./xlrit5rt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xlrit5rt.entry.js",
		159
	],
	"./xlrit5rt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xlrit5rt.sc.entry.js",
		160
	],
	"./xmfsfrk8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xmfsfrk8.entry.js",
		"common",
		99
	],
	"./xmfsfrk8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xmfsfrk8.sc.entry.js",
		"common",
		100
	],
	"./xnnvglkc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xnnvglkc.entry.js",
		161
	],
	"./xnnvglkc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xnnvglkc.sc.entry.js",
		162
	],
	"./yfdmk4jb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yfdmk4jb.entry.js",
		"common",
		101
	],
	"./yfdmk4jb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/yfdmk4jb.sc.entry.js",
		"common",
		102
	],
	"./z5b8ejko.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z5b8ejko.entry.js",
		"common",
		103
	],
	"./z5b8ejko.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z5b8ejko.sc.entry.js",
		"common",
		104
	],
	"./z98bzz0p.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z98bzz0p.entry.js",
		"common",
		105
	],
	"./z98bzz0p.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z98bzz0p.sc.entry.js",
		"common",
		106
	],
	"./zfi0kivq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zfi0kivq.entry.js",
		0,
		"common",
		163
	],
	"./zfi0kivq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zfi0kivq.sc.entry.js",
		0,
		"common",
		164
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./components/customer-appointment/customer-appointment.module": [
		"./src/app/components/customer-appointment/customer-appointment.module.ts"
	],
	"./components/mark-appointment/mark-appointment.module": [
		"./src/app/components/mark-appointment/mark-appointment.module.ts"
	],
	"./components/stock-quantity/stock-quantity.module": [
		"./src/app/components/stock-quantity/stock-quantity.module.ts"
	],
	"./customer-details/customer-details.module": [
		"./src/app/pages/customer/customer-details/customer-details.module.ts",
		"customer-details-customer-details-module"
	],
	"./customer-registration/customer-registration.module": [
		"./src/app/pages/customer/customer-registration/customer-registration.module.ts",
		"customer-registration-customer-registration-module"
	],
	"./customer-search/customer-search.module": [
		"./src/app/pages/customer/customer-search/customer-search.module.ts",
		"customer-search-customer-search-module"
	],
	"./new-sales/new-sales.module": [
		"./src/app/pages/sales/new-sales/new-sales.module.ts",
		"new-sales-new-sales-module"
	],
	"./new-stock/new-stock.module": [
		"./src/app/pages/stockmanagment/new-stock/new-stock.module.ts",
		"new-stock-new-stock-module"
	],
	"./pages/appointment/appointment.module": [
		"./src/app/pages/appointment/appointment.module.ts",
		"pages-appointment-appointment-module"
	],
	"./pages/customer/customer.module": [
		"./src/app/pages/customer/customer.module.ts",
		"common",
		"pages-customer-customer-module"
	],
	"./pages/dashboard-home/dashboard-home.module": [
		"./src/app/pages/dashboard-home/dashboard-home.module.ts",
		"pages-dashboard-home-dashboard-home-module"
	],
	"./pages/login/login.module": [
		"./src/app/pages/login/login.module.ts",
		"common",
		"pages-login-login-module"
	],
	"./pages/reports/reports.module": [
		"./src/app/pages/reports/reports.module.ts",
		"pages-reports-reports-module"
	],
	"./pages/sales/sales.module": [
		"./src/app/pages/sales/sales.module.ts",
		"pages-sales-sales-module"
	],
	"./pages/stockmanagment/store.module": [
		"./src/app/pages/stockmanagment/store.module.ts",
		"pages-stockmanagment-store-module"
	],
	"./sales-details/sales-details.module": [
		"./src/app/pages/sales/sales-details/sales-details.module.ts",
		"sales-details-sales-details-module"
	],
	"./search-sales/search-sales.module": [
		"./src/app/pages/sales/search-sales/search-sales.module.ts",
		"search-sales-search-sales-module"
	],
	"./stock-details/stock-details.module": [
		"./src/app/pages/stockmanagment/stock-details/stock-details.module.ts",
		"stock-details-stock-details-module"
	],
	"./update-stock-items/update-stock-items.module": [
		"./src/app/pages/stockmanagment/update-stock-items/update-stock-items.module.ts",
		"update-stock-items-update-stock-items-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _services_dashboard_dashboard_low_stock_resolve_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services/dashboard/dashboard-low-stock-resolve.service */ "./src/app/services/dashboard/dashboard-low-stock-resolve.service.ts");
/* harmony import */ var _services_dashboard_dashboard_pending_payment_resolve_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/dashboard/dashboard-pending-payment-resolve.service */ "./src/app/services/dashboard/dashboard-pending-payment-resolve.service.ts");
/* harmony import */ var _services_dashboard_dasboard_resolve_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/dashboard/dasboard-resolve.service */ "./src/app/services/dashboard/dasboard-resolve.service.ts");
/* harmony import */ var _services_guard_auth_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/guard/auth.guard */ "./src/app/services/guard/auth.guard.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_dashboard_dashboard_bcadata_resolve_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services/dashboard/dashboard-bcadata-resolve.service */ "./src/app/services/dashboard/dashboard-bcadata-resolve.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    { path: 'login', loadChildren: './pages/login/login.module#LoginPageModule' },
    { path: 'home',
        loadChildren: './pages/dashboard-home/dashboard-home.module#DashboardHomePageModule',
        canActivate: [_services_guard_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]],
        resolve: {
            data: _services_dashboard_dasboard_resolve_service__WEBPACK_IMPORTED_MODULE_2__["DasboardResolveService"],
            patientQue: _services_dashboard_dashboard_bcadata_resolve_service__WEBPACK_IMPORTED_MODULE_6__["DashboardBCADataResolveService"],
            patientPendingList: _services_dashboard_dashboard_pending_payment_resolve_service__WEBPACK_IMPORTED_MODULE_1__["DashboardPendingPaymentResolveService"],
            lowStock: _services_dashboard_dashboard_low_stock_resolve_service__WEBPACK_IMPORTED_MODULE_0__["DashboardLowStockResolveService"]
        }
    },
    { path: 'customer', loadChildren: './pages/customer/customer.module#CustomerPageModule',
    },
    { path: 'appointment', loadChildren: './pages/appointment/appointment.module#AppointmentPageModule',
    },
    { path: 'sales', loadChildren: './pages/sales/sales.module#SalesPageModule',
    },
    { path: 'stock', loadChildren: './pages/stockmanagment/store.module#StorePageModule',
        canActivate: [_services_guard_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
    },
    { path: 'reports', loadChildren: './pages/reports/reports.module#ReportsPageModule' },
    { path: 'stock-quantity', loadChildren: './components/stock-quantity/stock-quantity.module#StockQuantityPageModule' },
    { path: 'customer-appointment', loadChildren: './components/customer-appointment/customer-appointment.module#CustomerAppointmentPageModule' },
    { path: 'mark-appointment', loadChildren: './components/mark-appointment/mark-appointment.module#MarkAppointmentPageModule' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\r\n    <ion-split-pane>\r\n\r\n        <ion-menu menuId=\"main\">\r\n\r\n            <ion-header>\r\n\r\n                <ion-toolbar color=\"secondary\">\r\n                   \r\n                    <ion-title>Menu</ion-title>\r\n                </ion-toolbar>\r\n\r\n            </ion-header>\r\n            <ion-content>\r\n                <ion-list>\r\n                    <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\r\n                        <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\">\r\n                            {{p.title}}\r\n\r\n                            <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\r\n                        </ion-item>\r\n                    </ion-menu-toggle>\r\n                </ion-list>\r\n            </ion-content>\r\n        </ion-menu>\r\n\r\n        <ion-router-outlet main></ion-router-outlet>\r\n\r\n    </ion-split-pane>\r\n    <app-flash-message></app-flash-message>\r\n    <app-loader></app-loader>\r\n</ion-app>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services/dashboard/dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, menu, dashboardService) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.menu = menu;
        this.dashboardService = dashboardService;
        this.appPages = [
            {
                title: 'Home',
                url: '/home',
                icon: 'home'
            },
            {
                title: 'Customer Managment',
                url: '/customer',
                icon: 'people'
            },
            {
                title: 'Appointment',
                url: '/appointment',
                icon: 'time'
            }, {
                title: 'Sales/Invoices',
                url: '/sales',
                icon: 'cart'
            }, {
                title: 'Stock Managment',
                url: '/stock',
                icon: 'calculator'
            }, {
                title: 'Reports',
                url: '/reports',
                icon: 'paper'
            }
        ];
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"],
            _services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_0__["DashboardService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: tokenGetter, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tokenGetter", function() { return tokenGetter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _components_loader_loader_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/loader/loader.component */ "./src/app/components/loader/loader.component.ts");
/* harmony import */ var _services_loader_loader_interceptor_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/loader/loader-interceptor.service */ "./src/app/services/loader/loader-interceptor.service.ts");
/* harmony import */ var _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pipes/pipes.module */ "./src/app/pipes/pipes.module.ts");
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/header/header.component */ "./src/app/components/header/header.component.ts");
/* harmony import */ var _components_mark_appointment_mark_appointment_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/mark-appointment/mark-appointment.module */ "./src/app/components/mark-appointment/mark-appointment.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _components_component_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/component.module */ "./src/app/components/component.module.ts");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @auth0/angular-jwt */ "./node_modules/@auth0/angular-jwt/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ionic-selectable */ "./node_modules/ionic-selectable/esm5/ionic-selectable.min.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var angular_calendar_date_adapters_date_fns__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! angular-calendar/date-adapters/date-fns */ "./node_modules/angular-calendar/date-adapters/date-fns/index.js");
/* harmony import */ var angular_calendar_date_adapters_date_fns__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(angular_calendar_date_adapters_date_fns__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _components_stock_quantity_stock_quantity_module__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./components/stock-quantity/stock-quantity.module */ "./src/app/components/stock-quantity/stock-quantity.module.ts");
/* harmony import */ var angular_calendar__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! angular-calendar */ "./node_modules/angular-calendar/fesm5/angular-calendar.js");
/* harmony import */ var _components_customer_appointment_customer_appointment_module__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./components/customer-appointment/customer-appointment.module */ "./src/app/components/customer-appointment/customer-appointment.module.ts");
/* harmony import */ var ng_pick_datetime__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ng-pick-datetime */ "./node_modules/ng-pick-datetime/picker.js");
/* harmony import */ var ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ng-pick-datetime/dialog */ "./node_modules/ng-pick-datetime/dialog/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



























function tokenGetter() {
    return localStorage.getItem('access_token');
}
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_11__["AppComponent"]],
            entryComponents: [_components_header_header_component__WEBPACK_IMPORTED_MODULE_3__["HeaderComponent"], _components_loader_loader_component__WEBPACK_IMPORTED_MODULE_0__["LoaderComponent"]],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["BrowserModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_19__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ReactiveFormsModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_12__["AppRoutingModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_14__["NgxDatatableModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_16__["HttpClientModule"],
                ionic_selectable__WEBPACK_IMPORTED_MODULE_18__["IonicSelectableModule"],
                angular_calendar__WEBPACK_IMPORTED_MODULE_23__["CalendarModule"],
                _components_mark_appointment_mark_appointment_module__WEBPACK_IMPORTED_MODULE_4__["MarkAppointmentPageModule"],
                _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_15__["JwtModule"].forRoot({
                    config: {
                        tokenGetter: tokenGetter,
                        whitelistedDomains: ['http://localhost:8082', 'localhost:8082', 'localhost'],
                    }
                }),
                _ionic_storage__WEBPACK_IMPORTED_MODULE_17__["IonicStorageModule"].forRoot(),
                _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicModule"].forRoot(),
                angular_calendar__WEBPACK_IMPORTED_MODULE_23__["CalendarModule"].forRoot({
                    provide: angular_calendar__WEBPACK_IMPORTED_MODULE_23__["DateAdapter"],
                    useFactory: angular_calendar_date_adapters_date_fns__WEBPACK_IMPORTED_MODULE_21__["adapterFactory"]
                }),
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__["BrowserAnimationsModule"],
                _components_component_module__WEBPACK_IMPORTED_MODULE_13__["ComponentModule"],
                _components_stock_quantity_stock_quantity_module__WEBPACK_IMPORTED_MODULE_22__["StockQuantityPageModule"],
                _components_customer_appointment_customer_appointment_module__WEBPACK_IMPORTED_MODULE_24__["CustomerAppointmentPageModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_25__["OwlDateTimeModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_25__["OwlNativeDateTimeModule"],
                ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_26__["OwlDialogModule"],
                _pipes_pipes_module__WEBPACK_IMPORTED_MODULE_2__["PipesModule"]
            ],
            exports: [],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_10__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_9__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_7__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicRouteStrategy"] },
                { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_16__["HTTP_INTERCEPTORS"], useClass: _services_loader_loader_interceptor_service__WEBPACK_IMPORTED_MODULE_1__["LoaderInterceptorService"], multi: true }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_11__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/components/component.module.ts":
/*!************************************************!*\
  !*** ./src/app/components/component.module.ts ***!
  \************************************************/
/*! exports provided: ComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentModule", function() { return ComponentModule; });
/* harmony import */ var _loader_loader_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./loader/loader.component */ "./src/app/components/loader/loader.component.ts");
/* harmony import */ var ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ng-pick-datetime/dialog */ "./node_modules/ng-pick-datetime/dialog/index.js");
/* harmony import */ var ng_pick_datetime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng-pick-datetime */ "./node_modules/ng-pick-datetime/picker.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./header/header.component */ "./src/app/components/header/header.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _customer_detail_customer_detail_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./customer-detail/customer-detail.component */ "./src/app/components/customer-detail/customer-detail.component.ts");
/* harmony import */ var _doctor_details_doctor_details_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./doctor-details/doctor-details.component */ "./src/app/components/doctor-details/doctor-details.component.ts");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @swimlane/ngx-datatable */ "./node_modules/@swimlane/ngx-datatable/release/index.js");
/* harmony import */ var _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _ct_angiography_details_ct_angiography_details_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ct-angiography-details/ct-angiography-details.component */ "./src/app/components/ct-angiography-details/ct-angiography-details.component.ts");
/* harmony import */ var _treatment_plan_detail_treatment_plan_detail_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./treatment-plan-detail/treatment-plan-detail.component */ "./src/app/components/treatment-plan-detail/treatment-plan-detail.component.ts");
/* harmony import */ var _flash_message_flash_message_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./flash-message/flash-message.component */ "./src/app/components/flash-message/flash-message.component.ts");
/* harmony import */ var _treatment_invoice_details_treatment_invoice_details_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./treatment-invoice-details/treatment-invoice-details.component */ "./src/app/components/treatment-invoice-details/treatment-invoice-details.component.ts");
/* harmony import */ var _invoice_details_invoice_details_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./invoice-details/invoice-details.component */ "./src/app/components/invoice-details/invoice-details.component.ts");
/* harmony import */ var angular_calendar__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! angular-calendar */ "./node_modules/angular-calendar/fesm5/angular-calendar.js");
/* harmony import */ var _day_view_scheduler_day_view_scheduler_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./day-view-scheduler/day-view-scheduler.component */ "./src/app/components/day-view-scheduler/day-view-scheduler.component.ts");
/* harmony import */ var _search_update_schedule_search_update_schedule_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./search-update-schedule/search-update-schedule.component */ "./src/app/components/search-update-schedule/search-update-schedule.component.ts");
/* harmony import */ var _stock_details_stock_details_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./stock-details/stock-details.component */ "./src/app/components/stock-details/stock-details.component.ts");
/* harmony import */ var _stock_update_stock_update_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./stock-update/stock-update.component */ "./src/app/components/stock-update/stock-update.component.ts");
/* harmony import */ var _stock_update_history_stock_update_history_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./stock-update-history/stock-update-history.component */ "./src/app/components/stock-update-history/stock-update-history.component.ts");
/* harmony import */ var _stock_purchase_histroy_stock_purchase_histroy_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./stock-purchase-histroy/stock-purchase-histroy.component */ "./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.ts");
/* harmony import */ var _sales_invoice_info_sales_invoice_info_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./sales-invoice-info/sales-invoice-info.component */ "./src/app/components/sales-invoice-info/sales-invoice-info.component.ts");
/* harmony import */ var _sales_invoice_update_sales_invoice_update_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./sales-invoice-update/sales-invoice-update.component */ "./src/app/components/sales-invoice-update/sales-invoice-update.component.ts");
/* harmony import */ var _sales_invoice_history_sales_invoice_history_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./sales-invoice-history/sales-invoice-history.component */ "./src/app/components/sales-invoice-history/sales-invoice-history.component.ts");
/* harmony import */ var _toolpop_toolpop_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./toolpop/toolpop.component */ "./src/app/components/toolpop/toolpop.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


























var ComponentModule = /** @class */ (function () {
    function ComponentModule() {
    }
    ComponentModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["NgModule"])({
            declarations: [_header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"],
                _customer_detail_customer_detail_component__WEBPACK_IMPORTED_MODULE_7__["CustomerDetailComponent"],
                _doctor_details_doctor_details_component__WEBPACK_IMPORTED_MODULE_8__["DoctorDetailsComponent"],
                _ct_angiography_details_ct_angiography_details_component__WEBPACK_IMPORTED_MODULE_10__["CtAngiographyDetailsComponent"],
                _treatment_plan_detail_treatment_plan_detail_component__WEBPACK_IMPORTED_MODULE_11__["TreatmentPlanDetailComponent"],
                _flash_message_flash_message_component__WEBPACK_IMPORTED_MODULE_12__["FlashMessageComponent"],
                _treatment_invoice_details_treatment_invoice_details_component__WEBPACK_IMPORTED_MODULE_13__["TreatmentInvoiceDetailsComponent"],
                _invoice_details_invoice_details_component__WEBPACK_IMPORTED_MODULE_14__["InvoiceDetailsComponent"],
                _day_view_scheduler_day_view_scheduler_component__WEBPACK_IMPORTED_MODULE_16__["DayViewSchedulerComponent"],
                _search_update_schedule_search_update_schedule_component__WEBPACK_IMPORTED_MODULE_17__["SearchUpdateScheduleComponent"],
                _stock_details_stock_details_component__WEBPACK_IMPORTED_MODULE_18__["StockDetailsComponent"],
                _stock_update_stock_update_component__WEBPACK_IMPORTED_MODULE_19__["StockUpdateComponent"],
                _stock_update_history_stock_update_history_component__WEBPACK_IMPORTED_MODULE_20__["StockUpdateHistoryComponent"],
                _stock_purchase_histroy_stock_purchase_histroy_component__WEBPACK_IMPORTED_MODULE_21__["StockPurchaseHistroyComponent"],
                _sales_invoice_info_sales_invoice_info_component__WEBPACK_IMPORTED_MODULE_22__["SalesInvoiceInfoComponent"],
                _sales_invoice_update_sales_invoice_update_component__WEBPACK_IMPORTED_MODULE_23__["SalesInvoiceUpdateComponent"],
                _sales_invoice_history_sales_invoice_history_component__WEBPACK_IMPORTED_MODULE_24__["SalesInvoiceHistoryComponent"],
                _toolpop_toolpop_component__WEBPACK_IMPORTED_MODULE_25__["ToolpopComponent"], _loader_loader_component__WEBPACK_IMPORTED_MODULE_0__["LoaderComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"],
                _swimlane_ngx_datatable__WEBPACK_IMPORTED_MODULE_9__["NgxDatatableModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                angular_calendar__WEBPACK_IMPORTED_MODULE_15__["CalendarModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_2__["OwlDateTimeModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_2__["OwlNativeDateTimeModule"],
                ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_1__["OwlDialogModule"]
            ],
            entryComponents: [_toolpop_toolpop_component__WEBPACK_IMPORTED_MODULE_25__["ToolpopComponent"], _loader_loader_component__WEBPACK_IMPORTED_MODULE_0__["LoaderComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["CUSTOM_ELEMENTS_SCHEMA"]],
            exports: [_header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"],
                _customer_detail_customer_detail_component__WEBPACK_IMPORTED_MODULE_7__["CustomerDetailComponent"],
                _doctor_details_doctor_details_component__WEBPACK_IMPORTED_MODULE_8__["DoctorDetailsComponent"],
                _ct_angiography_details_ct_angiography_details_component__WEBPACK_IMPORTED_MODULE_10__["CtAngiographyDetailsComponent"],
                _treatment_plan_detail_treatment_plan_detail_component__WEBPACK_IMPORTED_MODULE_11__["TreatmentPlanDetailComponent"],
                _flash_message_flash_message_component__WEBPACK_IMPORTED_MODULE_12__["FlashMessageComponent"],
                _treatment_invoice_details_treatment_invoice_details_component__WEBPACK_IMPORTED_MODULE_13__["TreatmentInvoiceDetailsComponent"],
                _invoice_details_invoice_details_component__WEBPACK_IMPORTED_MODULE_14__["InvoiceDetailsComponent"],
                _day_view_scheduler_day_view_scheduler_component__WEBPACK_IMPORTED_MODULE_16__["DayViewSchedulerComponent"],
                _search_update_schedule_search_update_schedule_component__WEBPACK_IMPORTED_MODULE_17__["SearchUpdateScheduleComponent"],
                _stock_details_stock_details_component__WEBPACK_IMPORTED_MODULE_18__["StockDetailsComponent"],
                _stock_update_stock_update_component__WEBPACK_IMPORTED_MODULE_19__["StockUpdateComponent"],
                _stock_update_history_stock_update_history_component__WEBPACK_IMPORTED_MODULE_20__["StockUpdateHistoryComponent"],
                _stock_purchase_histroy_stock_purchase_histroy_component__WEBPACK_IMPORTED_MODULE_21__["StockPurchaseHistroyComponent"],
                _sales_invoice_info_sales_invoice_info_component__WEBPACK_IMPORTED_MODULE_22__["SalesInvoiceInfoComponent"],
                _sales_invoice_update_sales_invoice_update_component__WEBPACK_IMPORTED_MODULE_23__["SalesInvoiceUpdateComponent"],
                _sales_invoice_history_sales_invoice_history_component__WEBPACK_IMPORTED_MODULE_24__["SalesInvoiceHistoryComponent"],
                _toolpop_toolpop_component__WEBPACK_IMPORTED_MODULE_25__["ToolpopComponent"], _loader_loader_component__WEBPACK_IMPORTED_MODULE_0__["LoaderComponent"]
            ],
            providers: [],
        })
    ], ComponentModule);
    return ComponentModule;
}());



/***/ }),

/***/ "./src/app/components/ct-angiography-details/ct-angiography-details.component.html":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/ct-angiography-details/ct-angiography-details.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"ctAngioForm\">\r\n    <ion-grid>\r\n        <ion-row>\r\n            <ion-col size=\"8\">\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Center Name</ion-label>\r\n                    <ion-input type=\"text\" ngDefaultControl formControlName=\"centerName\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n\r\n                <ion-item>\r\n                    <ion-label  position=\"stacked\">Date</ion-label>\r\n                    <!-- <ion-datetime id=\"consulatationDate\" ngDefaultControl formControlName=\"refDate\" value=\"213\" displayFormat=\"\" pickerFormat=\"\"></ion-datetime> -->\r\n                \r\n                    <input ion-input [owlDateTimeFilter]=\"myFilter\"  [owlDateTime]=\"dt1\" id=\"refDate\"  (ionChange)=\"updateDataValue($event,'consulationDate')\"  ngDefaultControl formControlName=\"refDate\"   [owlDateTimeTrigger]=\"dt1\" placeholder=\"Date Time\"/>\r\n                    <owl-date-time #dt1 hour12Timer=\"true\" stepHour=\"1\" pickerType=\"calendar\" stepMinute=\"30\"> </owl-date-time>\r\n            \r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col size=\"8\">\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Address Line 1</ion-label>\r\n                    <ion-input type=\"text\" ngDefaultControl formControlName=\"addLine1\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">City</ion-label>\r\n                    <ion-input type=\"text\" ngDefaultControl formControlName=\"city\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col size=\"8\">\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Address Line 2</ion-label>\r\n                    <ion-input type=\"text\" ngDefaultControl formControlName=\"addLine2\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Pincode</ion-label>\r\n                    <ion-input type=\"number\" ngDefaultControl formControlName=\"pincode\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col size=\"8\">\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Contact Detail</ion-label>\r\n                    <ion-input type=\"text\" ngDefaultControl formControlName=\"contactNo\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Landmark</ion-label>\r\n                    <ion-input type=\"number\" ngDefaultControl formControlName=\"landmark\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col size=\"8\">\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Scan Test Name</ion-label>\r\n                    <ion-input type=\"text\" ngDefaultControl formControlName=\"scanTestName\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col size=\"8\">\r\n\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Invoice Amount</ion-label>\r\n                    <ion-input type=\"number\"  (ionChange)=\"updateDataValue($event,'invoiceTotalamt')\"  ngDefaultControl formControlName=\"invoiceTotalamt\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-button float-right type=\"submit\">Submit</ion-button>\r\n    <ion-button float-right type=\"reset\">Reset</ion-button>\r\n</form>\r\n\r\n<ion-item-divider class=\"divider\">\r\n</ion-item-divider>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>CT Angiography Details</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable no-padding class=\"material fullscreenManual\" [headerHeight]=\"50\" [scrollbarH]='true' [limit]=\"5\" \r\n            [columnMode]=\"'flexi'\" [footerHeight]=\"50\" [rowHeight]=\"'auto'\" [rows]=\"rowsCtAngio\">\r\n                <ngx-datatable-column name=\"Ref Date\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\">\r\n                        {{value | date : 'MMM d, y' }}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Center Name\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        {{value}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Scan Test Name\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{value}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Ref No\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.invoiceDomain.id}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column  width=\"200\" name=\"Action\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\" >\r\n\r\n                        <ion-button  size=\"small\" shape=\"round\" (click)=\"printMou(row.id)\" color=\"primary\">Generate Reciept  </ion-button>\r\n\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>Invoice Details</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable  [rowClass]=\"getRowClass\" #myTable class='material fullscreenManual' \r\n            [columnMode]=\"'flexi'\" [headerHeight]=\"50\" [sortType]=\"'multi'\" \r\n            [limit]=\"8\"\r\n            [footerHeight]=\"50\" [rowHeight]=\"'auto'\" \r\n             [scrollbarH]=\"'true'\" [rows]='rowsInvoice' >\r\n                <ngx-datatable-column name=\"Invoice No\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.id}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Type\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.invoiceType.typeName}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Generated By\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.generatedBy.username}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n                <ngx-datatable-column name=\"Payment Mode\">\r\n                    <ng-template  ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-select *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" value=\"\" name=\"paymentMode\" (ionChange)=\"updateValueInvoice($event, 'paymentMode', rowIndex)\">\r\n                            <ion-select-option value=\"cheque\">Cheque</ion-select-option>\r\n                            <ion-select-option value=\"online\">Online</ion-select-option>\r\n                            <ion-select-option value=\"cash\">Cash</ion-select-option>\r\n                        </ion-select>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Bank Name\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" name=\"bankName\" autofocus (blur)=\"updateValueInvoice($event, 'bankName', rowIndex)\" type=\"text\">\r\n\r\n                        </ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Reference Number\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" autofocus (blur)=\"updateValueInvoice($event, 'referenceNumber', rowIndex)\" type=\"text\"></ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Amount\">\r\n                    <ng-template  ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input  *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" autofocus (blur)=\"updateValueInvoice($event, 'paymentAmount', rowIndex)\" type=\"number\" ></ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Total Invoice Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.totalInvoiceAmt}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Balance Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.balanceAmt}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Status\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n\r\n                        <ion-select   value=\"{{row.invoiceStatus}}\" name=\"invoiceStatus\" (ionChange)=\"updateValueInvoice($event, 'cancelInvoice', rowIndex)\">\r\n                            <ion-select-option value=\"Total Payment Pending\">Pending</ion-select-option>\r\n                            <ion-select-option value=\"Partially Pending\">Partial</ion-select-option>\r\n                            <ion-select-option value=\"Payement Conpleted\">Completed</ion-select-option>\r\n                            <ion-select-option value=\"Invoice Cancelled\">Cancel</ion-select-option>\r\n\r\n                        </ion-select>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column width=\"200\" name=\"Payment Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-button *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\"  size=\"small\" shape=\"round\" (click)=\"generateReciept($event, 'name', rowIndex, row)\" color=\"primary\">Generate Reciept</ion-button>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>Payement Receipts</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable #myTable class='material fullscreenManual' [columnMode]=\"'flexi'\" \r\n            [headerHeight]=\"50\" [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"'auto'\"\r\n             [scrollbarH]=\"'true'\" [rows]='rowsPayment' >\r\n                <ngx-datatable-column name=\"Invoice No\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.invoiceId}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Recived By\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.recievedBy}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Date\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.paymentDate | date : 'MMM d, y, h:mm:ss a' }}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Reference Number\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.paymentReferenceNo}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Mode\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-text> {{row.paymentMode}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        <ion-text> {{row.paymentAmount}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n                <ngx-datatable-column width=\"200\" name=\"Print\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-button size=\"small\" shape=\"round\" (click)=\"printReciept($event, 'name', rowIndex, row)\" color=\"primary\">Print Reciept</ion-button>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>"

/***/ }),

/***/ "./src/app/components/ct-angiography-details/ct-angiography-details.component.scss":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/ct-angiography-details/ct-angiography-details.component.scss ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".divider {\n  border-bottom: 2px solid black !important; }\n\n.noLines {\n  border-bottom: 0px !important; }\n\n/* Structure */\n\nion-grid {\n  border: 1px solid black !important; }\n\n.fullscreenManual {\n  height: auto !important;\n  width: 95%; }\n\n:host /deep/ .datatable-row-group {\n  will-change: transform; }\n\n:host /deep/ .ngx-datatable.material .datatable-header .datatable-row-right {\n  margin-left: -8px; }\n\n:host /deep/ .row-color {\n  background-color: lightgreen; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9jdC1hbmdpb2dyYXBoeS1kZXRhaWxzL0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXGNvbXBvbmVudHNcXGN0LWFuZ2lvZ3JhcGh5LWRldGFpbHNcXGN0LWFuZ2lvZ3JhcGh5LWRldGFpbHMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQ0FBeUMsRUFDNUM7O0FBRUQ7RUFDSSw4QkFBNkIsRUFDaEM7O0FBR0QsZUFBZTs7QUFFZjtFQUNJLG1DQUFrQyxFQUNyQzs7QUFFRDtFQUNJLHdCQUF1QjtFQUN2QixXQUFVLEVBQ2I7O0FBRUQ7RUFDSSx1QkFBc0IsRUFDekI7O0FBRUE7RUFDRyxrQkFBaUIsRUFDcEI7O0FBRUQ7RUFDSSw2QkFBNEIsRUFDL0IiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2N0LWFuZ2lvZ3JhcGh5LWRldGFpbHMvY3QtYW5naW9ncmFwaHktZGV0YWlscy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kaXZpZGVyIHtcclxuICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCBibGFjayAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubm9MaW5lcyB7XHJcbiAgICBib3JkZXItYm90dG9tOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuXHJcbi8qIFN0cnVjdHVyZSAqL1xyXG5cclxuaW9uLWdyaWQge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2sgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmZ1bGxzY3JlZW5NYW51YWwge1xyXG4gICAgaGVpZ2h0OiBhdXRvICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogOTUlO1xyXG59XHJcblxyXG46aG9zdCAvZGVlcC8gLmRhdGF0YWJsZS1yb3ctZ3JvdXAge1xyXG4gICAgd2lsbC1jaGFuZ2U6IHRyYW5zZm9ybTtcclxufVxyXG5cclxuIDpob3N0IC9kZWVwLyAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLXJvdy1yaWdodCB7XHJcbiAgICBtYXJnaW4tbGVmdDogLThweDtcclxufVxyXG5cclxuOmhvc3QgL2RlZXAvIC5yb3ctY29sb3Ige1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmVlbjtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/ct-angiography-details/ct-angiography-details.component.ts":
/*!***************************************************************************************!*\
  !*** ./src/app/components/ct-angiography-details/ct-angiography-details.component.ts ***!
  \***************************************************************************************/
/*! exports provided: CtAngiographyDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CtAngiographyDetailsComponent", function() { return CtAngiographyDetailsComponent; });
/* harmony import */ var src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var src_app_services_common_common_util_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/common/common-util.service */ "./src/app/services/common/common-util.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};







var CtAngiographyDetailsComponent = /** @class */ (function () {
    function CtAngiographyDetailsComponent(activate, fb, customerService, flashProvider, alertController, commonService) {
        var _this = this;
        this.activate = activate;
        this.fb = fb;
        this.customerService = customerService;
        this.flashProvider = flashProvider;
        this.alertController = alertController;
        this.commonService = commonService;
        /**
         * Ct Angio Row Details
         */
        this.editingCtAngio = {};
        this.rowsCtAngio = [];
        this.columnsCtAngio = [];
        /**
        * Invoice Consultation Row Details
        */
        this.editingInvoice = {};
        this.rowsInvoice = [];
        this.rowInvoiceFromDb = [];
        this.columnsInvoice = [];
        /**
        * Payment Consultation Row Details
        */
        this.editingPayment = {};
        this.rowsPayment = [];
        this.columnsPayment = [];
        this.getRowClass = function (row) {
            if (!(row.invoiceStatus == 'Total Payment Pending' || row.invoiceStatus == 'Partially Pending')) {
                return {
                    'row-color': true
                };
            }
            else {
                return {
                    'row-color': false
                };
            }
        };
        this.myFilter = function (d) {
            var day = d.getDay();
            // Prevent Saturday and Sunday from being selected.
            return day !== 0;
        };
        this.ctAngioFromDb = this.activate.snapshot.data['data'];
        this.invoiceMasterType = this.activate.snapshot.data['invoiceType'];
        console.log(this.invoiceMasterType);
        this.invoiceMasterType.forEach(function (element) {
            if (element.typeName === 'CT ANGIOGRAPHY') {
                _this.invoiceTypeId = element.id;
            }
        });
        this.rowsCtAngio = this.ctAngioFromDb.ctAngioDetailList;
        if (this.ctAngioFromDb.ctAngioDetailList.length > 0) {
            this.columnsCtAngio = Object.keys(this.ctAngioFromDb.ctAngioDetailList[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        this.updateInvoiceAndPaymentDomain(this.ctAngioFromDb.ctAngioDetailList);
    }
    CtAngiographyDetailsComponent.prototype.updatePartialCtDetailAndInvoiceAndPaymentDomain = function (list) {
        var _this = this;
        /**
         * Below will update Invoice Payment
         */
        list.invoiceDomain.invoiceReciptList.filter(function (val) {
            _this.rowsPayment.push(val);
        });
        this.rowsPayment = this.rowsPayment.slice();
        /**
         * This will update Invoice datatable
         */
        this.rowsInvoice.push(list.invoiceDomain);
        this.rowInvoiceFromDb.push(list.invoiceDomain);
        this.rowsInvoice = this.rowsInvoice.slice();
        /**
         * Below will update CT Angio
         */
        var ind;
        this.rowsCtAngio.forEach(function (ele, index) {
            if (ele.id === list.id) {
                ind = index;
            }
        });
        if (ind != null) {
            this.rowsCtAngio[ind] = list;
            this.rowsCtAngio = this.rowsCtAngio.slice();
        }
        var err = new Array();
        err.push('Invoice Cancelled Succesfully and New Created');
        this.flashProvider.showGreen(err, 5000);
    };
    CtAngiographyDetailsComponent.prototype.updateInvoiceAndPaymentDomain = function (obj) {
        var _this = this;
        obj.filter(function (ele) {
            _this.rowsInvoice.push(ele.invoiceDomain);
            _this.rowInvoiceFromDb.push(ele.invoiceDomain);
            ele.invoiceDomain.invoiceReciptList.filter(function (val) {
                _this.rowsPayment.push(val);
            });
            return ele.invoiceDomain;
        });
        if (this.rowsInvoice.length > 0) {
            this.columnsInvoice = Object.keys(this.rowsInvoice[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        if (this.rowsPayment.length > 0) {
            this.columnsInvoice = Object.keys(this.rowsPayment[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        this.rowsInvoice = this.rowsInvoice.slice();
    };
    CtAngiographyDetailsComponent.prototype.updateSingleInvoiceDomainAndAllPaymentList = function (list) {
        var _this = this;
        list.invoiceReciptList.filter(function (val) {
            _this.rowsPayment.push(val);
        });
        this.rowsPayment = this.rowsPayment.slice();
        var ind;
        this.rowsInvoice.forEach(function (ele, index) {
            if (ele.id === list.id) {
                ind = index;
            }
        });
        if (ind != null) {
            this.rowsInvoice[ind] = list;
            this.rowsInvoice = this.rowsInvoice.slice();
        }
    };
    CtAngiographyDetailsComponent.prototype.ngOnInit = function () {
        this.ctAngioForm = this.createForm({
            id: [],
            centerName: ['Chitra Scan Center'],
            refDate: [],
            scanTestName: ['CT Coronory Scan'],
            addLine1: ['Sanjeevanee (Karnataka Hospital)'],
            addLine2: ['172/A, Naigaum, Behind Dadar Fire Brigade Statation'],
            pincode: ['4000020'],
            city: ['Dadar(east), Mumbai'],
            contactNo: ['24129860'],
            landmark: ['Near Sharda Cineam JyotiPhule Road'],
            invoice: [],
            invoiceMasterTypeId: [this.invoiceTypeId],
            customerId: [this.ctAngioFromDb.id],
            invoiceTotalamt: [7500]
        });
    };
    CtAngiographyDetailsComponent.prototype.createForm = function (model) {
        return this.fb.group(model);
    };
    CtAngiographyDetailsComponent.prototype.onSubmit = function () {
        var _this = this;
        console.log(this.ctAngioForm.value);
        this.customerService.saveCtAngioDetails(this.ctAngioForm.value).subscribe(function (res) {
            var val = [];
            val.push(res.document);
            _this.updateInvoiceAndPaymentDomain(val);
            _this.rowsCtAngio.push(res.document);
            _this.rowsCtAngio = _this.rowsCtAngio.slice();
            _this.flashProvider.showGreen(res.error, 4000);
        }, function (err) {
            _this.flashProvider.showRed(err.error, 4000);
        });
    };
    CtAngiographyDetailsComponent.prototype.updateValueCtAngio = function (event, cell, rowIndex) {
        this.editingCtAngio[rowIndex + '-' + cell] = false;
        this.rowsCtAngio[rowIndex][cell] = event.target.value;
    };
    CtAngiographyDetailsComponent.prototype.updateDataValue = function (eve, tar) {
        var val;
        val = eve.target.value;
        this.ctAngioForm.get(tar).setValue(val);
    };
    CtAngiographyDetailsComponent.prototype.updateValueInvoice = function (event, cell, rowIndex) {
        /**
         * Bug needs to be solved the Balance amount not getting reset to original DB amount when entered zero
         */
        if (cell === 'paymentAmount') {
            var balAmt = this.rowInvoiceFromDb[rowIndex]['balanceAmt'];
            var newBalAmt = Number(balAmt) - Number(event.target.value);
            if (isNaN(newBalAmt)) {
            }
            else if (newBalAmt < 0) {
                var err = new Array();
                err.push('Kindly Enter Amount Less than the balance amount');
                this.flashProvider.showRed(err, 5000);
                event.target.value = '';
                return;
            }
            else {
                this.rowsInvoice[rowIndex]['balanceAmt'] = newBalAmt;
                this.rowsInvoice = this.rowsInvoice.slice();
            }
        }
        else if (cell == 'cancelInvoice' && event.target.value == 'Invoice Cancelled') {
            this.presentAlertRadio(this.rowsInvoice[rowIndex]);
        }
        this.editingInvoice[rowIndex + '-' + cell] = false;
        this.rowsInvoice[rowIndex][cell] = event.target.value;
    };
    CtAngiographyDetailsComponent.prototype.presentAlertRadio = function (ele) {
        return __awaiter(this, void 0, void 0, function () {
            var alert;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.alertController.create({
                            header: 'New Invoice Creation',
                            inputs: [
                                {
                                    name: 'newInvoiceAmt',
                                    type: 'number',
                                    id: 'newInvoiceAmt',
                                    value: 4500,
                                    placeholder: 'New Invoice Amount'
                                },
                            ],
                            buttons: [
                                {
                                    text: 'Cancel',
                                    role: 'cancel',
                                    cssClass: 'secondary',
                                    handler: function () {
                                        console.log('Confirm Cancel');
                                    }
                                }, {
                                    text: 'Ok',
                                    handler: function (res) {
                                        console.log(res);
                                        if (res) {
                                            ele['newInvoiceAmountInCaseofCancel'] = res.newInvoiceAmt;
                                            _this.ctAngioForm.value['invoiceDomain'] = ele;
                                            _this.customerService.cancelAndCreateNewInvoice(_this.ctAngioForm.value).subscribe(function (res) {
                                                _this.updatePartialCtDetailAndInvoiceAndPaymentDomain(res.document);
                                            }, function (err) {
                                                console.log(err);
                                            });
                                        }
                                        console.log('Confirm Ok');
                                    }
                                }
                            ]
                        })];
                    case 1:
                        alert = _a.sent();
                        return [4 /*yield*/, alert.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    CtAngiographyDetailsComponent.prototype.updateValuePayment = function (event, cell, rowIndex) {
        this.editingPayment[rowIndex + '-' + cell] = false;
        this.rowsPayment[rowIndex][cell] = event.target.value;
    };
    CtAngiographyDetailsComponent.prototype.printReciept = function (event, cell, rowIndex, row) {
        this.customerService.printRecipt(row).subscribe(function (res) {
            console.log(res);
            // const blob = new Blob([data], { type: 'text/csv' });
            var url = window.URL.createObjectURL(res);
            // window.open(url); if Image needs to open in new tab
            var a = document.createElement('a');
            a.href = url;
            a.download = 'File.pdf';
            a.click();
        }, function (errr) {
            console.log(errr);
        });
    };
    CtAngiographyDetailsComponent.prototype.generateReciept = function (event, cell, rowIndex, row) {
        var _this = this;
        console.log(row);
        this.customerService.generateReciept(row).subscribe(function (res) {
            _this.updateSingleInvoiceDomainAndAllPaymentList(res.document);
            console.log(res);
            _this.flashProvider.showGreen(res.error, 5000);
        }, function (err) {
            console.log(err);
            _this.flashProvider.showRed(err.error, 5000);
        });
    };
    CtAngiographyDetailsComponent.prototype.printMou = function (id) {
        var _this = this;
        this.customerService.printMou(id).subscribe(function (res) {
            _this.commonService.saveFile(res);
        }, function (err) {
            var er = [];
            er.push('Unable to Print Mou Please Contact IT Support');
            _this.flashProvider.showRed(er, 8000);
        });
    };
    CtAngiographyDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-ct-angiography-details',
            template: __webpack_require__(/*! ./ct-angiography-details.component.html */ "./src/app/components/ct-angiography-details/ct-angiography-details.component.html"),
            styles: [__webpack_require__(/*! ./ct-angiography-details.component.scss */ "./src/app/components/ct-angiography-details/ct-angiography-details.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_1__["CustomerService"],
            src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__["FlashMessageService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"],
            src_app_services_common_common_util_service__WEBPACK_IMPORTED_MODULE_6__["CommonUtilService"]])
    ], CtAngiographyDetailsComponent);
    return CtAngiographyDetailsComponent;
}());



/***/ }),

/***/ "./src/app/components/customer-appointment/customer-appointment.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/components/customer-appointment/customer-appointment.module.ts ***!
  \********************************************************************************/
/*! exports provided: CustomerAppointmentPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerAppointmentPageModule", function() { return CustomerAppointmentPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _customer_appointment_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./customer-appointment.page */ "./src/app/components/customer-appointment/customer-appointment.page.ts");
/* harmony import */ var ng_pick_datetime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng-pick-datetime */ "./node_modules/ng-pick-datetime/picker.js");
/* harmony import */ var ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ng-pick-datetime/dialog */ "./node_modules/ng-pick-datetime/dialog/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var routes = [
    {
        path: '',
        component: _customer_appointment_page__WEBPACK_IMPORTED_MODULE_5__["CustomerAppointmentPage"]
    }
];
var CustomerAppointmentPageModule = /** @class */ (function () {
    function CustomerAppointmentPageModule() {
    }
    CustomerAppointmentPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_6__["OwlDateTimeModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_6__["OwlNativeDateTimeModule"],
                ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_7__["OwlDialogModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_customer_appointment_page__WEBPACK_IMPORTED_MODULE_5__["CustomerAppointmentPage"]]
        })
    ], CustomerAppointmentPageModule);
    return CustomerAppointmentPageModule;
}());



/***/ }),

/***/ "./src/app/components/customer-appointment/customer-appointment.page.html":
/*!********************************************************************************!*\
  !*** ./src/app/components/customer-appointment/customer-appointment.page.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-list>\r\n    <ion-list-header>\r\n    </ion-list-header>\r\n    <ion-item>\r\n        <ion-label>Type of Appointment</ion-label>\r\n        <ion-select  interface=\"popover\"  [(ngModel)]=\"appointmentType\" placeholder=\"select appointment\">\r\n            <ion-select-option value=\"In House\">In House Appointment</ion-select-option>\r\n            <ion-select-option value=\"Dr Appointment\">Dr. Bimal Chhajer</ion-select-option>\r\n            <ion-select-option value=\"Treatment ECP\">Treatment ECP</ion-select-option>\r\n            <ion-select-option value=\"Treatment BCA\">Treatment BCA</ion-select-option>\r\n        </ion-select>\r\n    </ion-item>\r\n\r\n    <ion-item *ngIf=\"appointmentType=='Treatment ECP'\">\r\n        <ion-label>Machine No</ion-label>\r\n        <ion-select interface=\"popover\" [(ngModel)]=\"machineNo\" placeholder=\"select Machine\">\r\n            <ion-select-option value=\"1\">Machine 1</ion-select-option>\r\n            <ion-select-option value=\"2\">Machine 2</ion-select-option>\r\n            <ion-select-option value=\"3\">Machine 3</ion-select-option>\r\n            <ion-select-option value=\"4\">Machine 4</ion-select-option>\r\n            <ion-select-option value=\"5\">Machine 5</ion-select-option>\r\n\r\n        </ion-select>\r\n    </ion-item>\r\n    \r\n    <ion-item>\r\n        <ion-label> Date of Appointment </ion-label>\r\n        <!-- <ion-datetime type=\"date\" mode=\"ios\" [(ngModel)]=\"appointmentDate\" id=\"appointmentDate\" hourValues=\"08,09,10,11,12,13,14,15,16,17,18\" display-format=\"MMM DD, YYYY HH:mm \"></ion-datetime> -->\r\n        <input  [owlDateTime]=\"dt1\" [(ngModel)]=\"appointmentDate\"  [owlDateTimeTrigger]=\"dt1\" placeholder=\"Date Time\">\r\n        <owl-date-time #dt1 hour12Timer=\"true\" stepHour=\"1\" stepMinute=\"30\"> </owl-date-time>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n        <ion-label>Appointment Description</ion-label>\r\n        <ion-textarea rows=\"6\" cols=\"20\" [(ngModel)]=\"description\" placeholder=\"Enter any notes here...\"></ion-textarea>\r\n\r\n    </ion-item>\r\n    <ion-item>\r\n        <ion-button shape=\"round\" size=\"default\" slot=\"end\" (click)=\"closeModel()\">Schedule</ion-button>\r\n    </ion-item>\r\n</ion-list>"

/***/ }),

/***/ "./src/app/components/customer-appointment/customer-appointment.page.scss":
/*!********************************************************************************!*\
  !*** ./src/app/components/customer-appointment/customer-appointment.page.scss ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host /deep/ .my-custom-modal-css {\n  height: 60%; }\n\n:host /deep/ .modal-wrapper {\n  height: 60%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9jdXN0b21lci1hcHBvaW50bWVudC9DOlxcQmFzaWNzXFxDXFxwb2ludGVyc1xcc2Fhb2xoZWFydFVJL3NyY1xcYXBwXFxjb21wb25lbnRzXFxjdXN0b21lci1hcHBvaW50bWVudFxcY3VzdG9tZXItYXBwb2ludG1lbnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBVyxFQUNkOztBQUVEO0VBQ0ksWUFBVyxFQUNkIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9jdXN0b21lci1hcHBvaW50bWVudC9jdXN0b21lci1hcHBvaW50bWVudC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCAvZGVlcC8gLm15LWN1c3RvbS1tb2RhbC1jc3Mge1xyXG4gICAgaGVpZ2h0OiA2MCU7XHJcbn1cclxuXHJcbjpob3N0IC9kZWVwLyAubW9kYWwtd3JhcHBlciB7XHJcbiAgICBoZWlnaHQ6IDYwJTtcclxufVxyXG5cclxuIl19 */"

/***/ }),

/***/ "./src/app/components/customer-appointment/customer-appointment.page.ts":
/*!******************************************************************************!*\
  !*** ./src/app/components/customer-appointment/customer-appointment.page.ts ***!
  \******************************************************************************/
/*! exports provided: CustomerAppointmentPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerAppointmentPage", function() { return CustomerAppointmentPage; });
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var CustomerAppointmentPage = /** @class */ (function () {
    function CustomerAppointmentPage(navParams, modalCtrl, flasService) {
        this.modalCtrl = modalCtrl;
        this.flasService = flasService;
        this.dt = new Date();
        this.appointmentDate = new Date(this.dt.getFullYear(), this.dt.getMonth(), this.dt.getDate(), 9, 30);
    }
    CustomerAppointmentPage.prototype.ngOnInit = function () {
    };
    CustomerAppointmentPage.prototype.openDate = function () {
        /*
          this.datePicker.show({
            date: new Date(),
            mode: 'date',
            androidTheme: this.datePicker.ANDROID_THEMES.THEME_HOLO_DARK
          }).then(
            date => console.log('Got date: ', date),
            err => console.log('Error occurred while getting date: ', err)
            https://www.logisticinfotech.com/blog/ionic4-datepicker-component/
          );*/
    };
    CustomerAppointmentPage.prototype.closeModel = function () {
        if (this.appointmentType != null && this.appointmentDate != null && this.description != null) {
            var dat = { appointmentType: this.appointmentType,
                appointmentDate: this.appointmentDate, description: this.description, machineNo: this.machineNo };
            this.modalCtrl.dismiss(dat);
        }
        else {
            this.flasService.showRed('Please enter all data related to Appointment', 4000);
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", String)
    ], CustomerAppointmentPage.prototype, "appointmentType", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", Object)
    ], CustomerAppointmentPage.prototype, "appointmentDate", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", Object)
    ], CustomerAppointmentPage.prototype, "description", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", Object)
    ], CustomerAppointmentPage.prototype, "expectedTime", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", Number)
    ], CustomerAppointmentPage.prototype, "machineNo", void 0);
    CustomerAppointmentPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-customer-appointment',
            template: __webpack_require__(/*! ./customer-appointment.page.html */ "./src/app/components/customer-appointment/customer-appointment.page.html"),
            styles: [__webpack_require__(/*! ./customer-appointment.page.scss */ "./src/app/components/customer-appointment/customer-appointment.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__["FlashMessageService"]])
    ], CustomerAppointmentPage);
    return CustomerAppointmentPage;
}());



/***/ }),

/***/ "./src/app/components/customer-detail/customer-detail.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/components/customer-detail/customer-detail.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-grid>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b>Consultation Number:- </b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n            {{customerDetails.id}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b>   SAAOL Code: -</b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n            {{customerDetails.saaolCode}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b> Pateint Name</b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n            {{customerDetails.firstName}} {{customerDetails.lastName}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b>     Date of Birth</b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n            {{customerDetails.dob | date:'MMM d, y'}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b> Age</b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n            {{customerDetails.age}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b>    Gender</b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n            {{customerDetails.gender}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b> Address</b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\" wrap-text>\r\n            {{customerDetails.address}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b>   Email Id</b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n            {{customerDetails.emailId}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col size=\"3\">\r\n            <ion-label>\r\n                <ion-text color=\"dark\"><b> Aadhar Number</b></ion-text>\r\n            </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"3\">\r\n            {{customerDetails.aadharNumber}}\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ion-grid>\r\n                <ion-row>\r\n                    <ion-col>\r\n                        <ion-label>\r\n                            <ion-text color=\"dark\"><b> Mobile (Primary)</b></ion-text>\r\n                        </ion-label>\r\n                    </ion-col>\r\n                    <ion-col>\r\n                        {{customerDetails.mobileNo}}\r\n                    </ion-col>\r\n                </ion-row>\r\n                <ion-row>\r\n                    <ion-col>\r\n                        <ion-label>\r\n                            <ion-text color=\"dark\"><b> Pateint Added On</b></ion-text>\r\n                        </ion-label>\r\n                    </ion-col>\r\n                    <ion-col>\r\n                        {{customerDetails.dateOfCreation | date:'MMM d, y'}}\r\n                    </ion-col>\r\n                </ion-row>\r\n            </ion-grid>\r\n        </ion-col>\r\n        <ion-col no-padding>\r\n            <ion-grid>\r\n                <ion-row>\r\n                    <ion-col>\r\n                        <ion-label>\r\n                            <ion-text color=\"dark\"><b>  Pateint Added by</b></ion-text>\r\n                        </ion-label>\r\n                    </ion-col>\r\n                    <ion-col>\r\n                        {{customerDetails.generetedBy}}\r\n                    </ion-col>\r\n                </ion-row>\r\n                <ion-row>\r\n                        <ion-col>\r\n                            <ion-label>\r\n                                <ion-text color=\"dark\"><b>  Pateint Type</b></ion-text>\r\n                            </ion-label>\r\n                        </ion-col>\r\n                        <ion-col>\r\n                            {{customerDetails.vistingFor | uppercase}} \r\n                        </ion-col>\r\n                    </ion-row>\r\n                    <ion-row><ion-col>\r\n                                <ion-button  (click)=\"navigateToRegistration(customerDetails.id)\"   class=\"ion-float-right\">Edit/Update Details</ion-button>\r\n                     \r\n                        </ion-col>\r\n                        </ion-row>\r\n            </ion-grid>\r\n        </ion-col>\r\n    </ion-row>\r\n   \r\n</ion-grid>"

/***/ }),

/***/ "./src/app/components/customer-detail/customer-detail.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/components/customer-detail/customer-detail.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvY3VzdG9tZXItZGV0YWlsL2N1c3RvbWVyLWRldGFpbC5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/customer-detail/customer-detail.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/customer-detail/customer-detail.component.ts ***!
  \*************************************************************************/
/*! exports provided: CustomerDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerDetailComponent", function() { return CustomerDetailComponent; });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var CustomerDetailComponent = /** @class */ (function () {
    function CustomerDetailComponent(activate, fb, modalController) {
        this.activate = activate;
        this.fb = fb;
        this.modalController = modalController;
        this.navigateTo = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.customerDetails = this.activate.snapshot.data['data'];
        console.log(this.activate.snapshot.data);
        this.custStatusForm = this.fb.group({
            id: [''],
            statusOfTreatment: ['']
        });
    }
    CustomerDetailComponent.prototype.ngOnInit = function () {
    };
    CustomerDetailComponent.prototype.updateForm = function (model) {
        this.custStatusForm.patchValue(model);
    };
    CustomerDetailComponent.prototype.navigateToRegistration = function (res) {
        this.navigateTo.emit(res);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"])
    ], CustomerDetailComponent.prototype, "navigateTo", void 0);
    CustomerDetailComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-customer-detail',
            template: __webpack_require__(/*! ./customer-detail.component.html */ "./src/app/components/customer-detail/customer-detail.component.html"),
            styles: [__webpack_require__(/*! ./customer-detail.component.scss */ "./src/app/components/customer-detail/customer-detail.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_0__["ModalController"]])
    ], CustomerDetailComponent);
    return CustomerDetailComponent;
}());



/***/ }),

/***/ "./src/app/components/day-view-scheduler/day-view-scheduler.component.html":
/*!*********************************************************************************!*\
  !*** ./src/app/components/day-view-scheduler/day-view-scheduler.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"cal-day-view\" #dayViewContainer>\r\n    <div class=\"day-view-column-headers\">\r\n        <div class=\"day-view-column-header\" *ngFor=\"let user of view.users\">\r\n            {{ user.name }} \r\n        </div>\r\n    </div>\r\n    <div class=\"cal-hour-rows\" mwlDroppable (dragEnter)=\"eventDragEnter = eventDragEnter + 1\" (dragLeave)=\"eventDragEnter = eventDragEnter - 1\">\r\n\r\n        <div class=\"cal-events\">\r\n            <div #event *ngFor=\"let dayEvent of view?.events; trackBy: trackByDayEvent; index as i\" \r\n            class=\"cal-event-container\" \r\n            [class.cal-starts-within-day]=\"!dayEvent.startsBeforeDay\" \r\n            [class.cal-ends-within-day]=\"!dayEvent.endsAfterDay\"\r\n             [ngClass]=\"dayEvent.event.cssClass\"\r\n                mwlDraggable id=\"drill-{{i}}\" [dragAxis]=\"{\r\n          x: true,\r\n          y: dayEvent.event.draggable && currentResizes.size === 0\r\n        }\" [dragSnapGrid]=\"{\r\n          y: eventSnapSize || hourSegmentHeight,\r\n          x: eventWidth\r\n        }\" [validateDrag]=\"validateDrag\" (dragStart)=\"dragStarted(event, dayViewContainer)\" (dragging)=\"dragMove()\" \r\n        (dragEnd)=\"eventDragged(dayEvent, $event.x, $event.y)\" \r\n        [style.marginTop.px]=\"dayEvent.top\" [style.height.px]=\"dayEvent.height\" [style.marginLeft.px]=\"dayEvent.left + 70\"\r\n                [style.width.px]=\"dayEvent.width - 1\">\r\n                <mwl-calendar-day-view-event (click)=\"getEvent(dayEvent)\" \r\n                [dayEvent]=\"dayEvent\" \r\n                [tooltipPlacement]=\"tooltipPlacement\"\r\n                 [tooltipTemplate]=\"tooltipTemplate\" \r\n                 [tooltipAppendToBody]=\"tooltipAppendToBody\"\r\n                  [customTemplate]=\"dataTemplate\" [eventTitleTemplate]=\"eventTitleTemplate\"\r\n                    [eventActionsTemplate]=\"eventActionsTemplate\" (eventClicked)=\"eventClicked.emit({ event: dayEvent.event })\">\r\n                </mwl-calendar-day-view-event>\r\n<ng-template #dataTemplate >\r\n{{dayEvent.event.title}}\r\n<br>\r\n <label>Visit Duration: -</label> \r\n   {{dayEvent.event.meta.appointmentDetail.treatmentDetailDomain.duration !=null ? (dayEvent.event.meta.appointmentDetail.treatmentDetailDomain.duration | slice:2) : \"NA\"}}\r\n   <br>\r\n   <label>Duration Till: -</label> \r\n     {{dayEvent.event.meta.appointmentDetail.treatmentDetailDomain.durationUpTillNow !=null ? (dayEvent.event.meta.appointmentDetail.treatmentDetailDomain.durationUpTillNow | slice:2 ): \"NA\"}}\r\n</ng-template>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"cal-hour\" *ngFor=\"let hour of hours; trackBy: trackByHour\" [style.minWidth.px]=\"view?.width + 70\">\r\n            <mwl-calendar-day-view-hour-segment *ngFor=\"let segment of hour.segments; trackBy: trackByHourSegment\" [style.height.px]=\"hourSegmentHeight\" [segment]=\"segment\" [segmentHeight]=\"hourSegmentHeight\" [locale]=\"locale\" [customTemplate]=\"hourSegmentTemplate\"\r\n                (mwlClick)=\"hourSegmentClicked.emit({ date: segment.date })\" mwlDroppable dragOverClass=\"cal-drag-over\" dragActiveClass=\"cal-drag-active\" (drop)=\"eventDropped($event, segment.date, false)\">\r\n            </mwl-calendar-day-view-hour-segment>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/components/day-view-scheduler/day-view-scheduler.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/components/day-view-scheduler/day-view-scheduler.component.ts ***!
  \*******************************************************************************/
/*! exports provided: DayViewSchedulerCalendarUtils, DayViewSchedulerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DayViewSchedulerCalendarUtils", function() { return DayViewSchedulerCalendarUtils; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DayViewSchedulerComponent", function() { return DayViewSchedulerComponent; });
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/dashboard/dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var angular_calendar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-calendar */ "./node_modules/angular-calendar/fesm5/angular-calendar.js");
/* harmony import */ var src_app_utils_color__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/utils/color */ "./src/app/utils/color.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};







var EVENT_WIDTH = 150;
var DayViewSchedulerCalendarUtils = /** @class */ (function (_super) {
    __extends(DayViewSchedulerCalendarUtils, _super);
    function DayViewSchedulerCalendarUtils() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.users = [
            {
                id: 1,
                name: 'Machine 1',
                color: src_app_utils_color__WEBPACK_IMPORTED_MODULE_6__["colors"].red
            },
            {
                id: 2,
                name: 'Machine 2',
                color: src_app_utils_color__WEBPACK_IMPORTED_MODULE_6__["colors"].blue
            },
            {
                id: 3,
                name: 'Machine 3',
                color: src_app_utils_color__WEBPACK_IMPORTED_MODULE_6__["colors"].yellow
            },
            {
                id: 4,
                name: 'Machine 4',
                color: src_app_utils_color__WEBPACK_IMPORTED_MODULE_6__["colors"].red
            },
            {
                id: 5,
                name: 'Machine 5',
                color: src_app_utils_color__WEBPACK_IMPORTED_MODULE_6__["colors"].blue
            }
        ];
        return _this;
    }
    DayViewSchedulerCalendarUtils.prototype.getDayView = function (args) {
        var _this = this;
        var view = __assign({}, _super.prototype.getDayView.call(this, args), { users: [] });
        //  view.events.forEach(({ event }) => {
        //   // assumes user objects are the same references,
        //   // if 2 users have the same structure but different object references this will fail
        //   if (!view.users.includes(event.meta.user)) {
        //     view.users.push(event.meta.user);
        //   }
        // });
        this.users.forEach(function (user) {
            if (!view.users.includes(user)) {
                view.users.push(user);
            }
        });
        // sort the users by their names
        // view.users.sort((user1, user2) => user1.name.localeCompare(user2.name));
        view.events = view.events.map(function (dayViewEvent) {
            var index;
            _this.users.forEach(function (user, ind) {
                if (user.id === dayViewEvent.event.meta.user.id) {
                    index = ind;
                }
            });
            // const index = view.users.indexOf(dayViewEvent.event.meta.user);
            dayViewEvent.left = index * EVENT_WIDTH; // change the column of the event
            return dayViewEvent;
        });
        view.width = view.users.length * EVENT_WIDTH;
        return view;
    };
    DayViewSchedulerCalendarUtils = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Injectable"])()
    ], DayViewSchedulerCalendarUtils);
    return DayViewSchedulerCalendarUtils;
}(angular_calendar__WEBPACK_IMPORTED_MODULE_5__["CalendarUtils"]));

var DayViewSchedulerComponent = /** @class */ (function (_super) {
    __extends(DayViewSchedulerComponent, _super);
    function DayViewSchedulerComponent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.userChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        _this.newChange = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        return _this;
    }
    DayViewSchedulerComponent.prototype.ngOnInit = function () {
        console.log(this.eventTemplate);
        this.alertController = new _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]();
        this.httpClient = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"](this.httpHandler);
        this.dashboardService = new _services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_2__["DashboardService"](this.httpClient);
        this.flashService = new _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__["FlashMessageService"]();
    };
    DayViewSchedulerComponent.prototype.getEvent = function (eventDay) {
        this.newChange.emit(eventDay);
    };
    DayViewSchedulerComponent.prototype.eventDragged = function (dayEvent, xPixels, yPixels) {
        if (yPixels !== 0) {
            _super.prototype.dragEnded.call(this, dayEvent, { y: yPixels, x: 0 }); // original behaviour
        }
        if (xPixels !== 0) {
            var columnsMoved = xPixels / EVENT_WIDTH;
            var currentColumnIndex_1;
            // const currentColumnIndex = this.view.users.findIndex(
            //   user => user.id === dayEvent.event.meta.user.id
            // );
            this.view.users.forEach(function (user, ind) {
                if (user.id === dayEvent.event.meta.user.id) {
                    currentColumnIndex_1 = ind;
                }
            });
            var newIndex = currentColumnIndex_1 + columnsMoved === -1 ? 0 : currentColumnIndex_1 + columnsMoved;
            var newUser = this.view.users[newIndex];
            /*
            *Check if any event already exist
            */
            console.log(dayEvent);
            if (newUser) {
                this.userChanged.emit({ event: dayEvent.event, newUser: newUser });
            }
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"])(),
        __metadata("design:type", Object)
    ], DayViewSchedulerComponent.prototype, "userChanged", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"])(),
        __metadata("design:type", Object)
    ], DayViewSchedulerComponent.prototype, "newChange", void 0);
    DayViewSchedulerComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            // tslint:disable-line max-classes-per-file
            selector: 'mwl-day-view-scheduler',
            providers: [
                {
                    provide: angular_calendar__WEBPACK_IMPORTED_MODULE_5__["CalendarUtils"],
                    useClass: DayViewSchedulerCalendarUtils
                }, _services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_2__["DashboardService"]
            ],
            template: __webpack_require__(/*! ./day-view-scheduler.component.html */ "./src/app/components/day-view-scheduler/day-view-scheduler.component.html"),
            styles: ["\n      .day-view-column-headers {\n        display: flex;\n        margin-left: 70px;\n      }\n      .day-view-column-header {\n        width: 150px;\n        border: solid 1px black;\n        text-align: center;\n      }\n      .strike {\n        background: repeating-linear-gradient(\n            45deg !important,\n            #606dbc !important,\n            #606dbc 10px !important,\n            #465298 10px !important,\n            #465298 20px !important\n          );\n    }\n    "]
        })
    ], DayViewSchedulerComponent);
    return DayViewSchedulerComponent;
}(angular_calendar__WEBPACK_IMPORTED_MODULE_5__["CalendarDayViewComponent"]));



/***/ }),

/***/ "./src/app/components/doctor-details/doctor-details.component.html":
/*!*************************************************************************!*\
  !*** ./src/app/components/doctor-details/doctor-details.component.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"doctorDetailsForm\">\r\n    <ion-grid>\r\n        <ion-row>\r\n            <ion-col>\r\n\r\n                <ion-item lines=\"none\">\r\n                    <ion-label position=\"stacked\">Consulation Date</ion-label>\r\n                    <!-- <ion-datetime id=\"consulatationDate\" (ionChange)=\"updateDataValue($event,'consulationDate')\" ngDefaultControl formControlName=\"consulationDate\" display-format=\"MMM DD, YYYY\" pickerFormat=\"MMM DD, YYYY\"></ion-datetime> -->\r\n                \r\n                    <input ion-input [owlDateTimeFilter]=\"myFilter\" [owlDateTime]=\"dt1\" id=\"consulatationDate\" (ionChange)=\"updateDataValue($event,'consulationDate')\" ngDefaultControl formControlName=\"consulationDate\"   [owlDateTimeTrigger]=\"dt1\" placeholder=\"Date Time\"/>\r\n                    <owl-date-time #dt1 hour12Timer=\"true\" stepHour=\"1\" pickerType=\"calendar\" stepMinute=\"30\"> </owl-date-time>\r\n            \r\n                </ion-item>\r\n                \r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Consulation By</ion-label>\r\n                    <ion-input id=\"consultationBy\" ngDefaultControl formControlName=\"consultationBy\" type=\"text\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Treatment Suggested</ion-label>\r\n                    <ion-select interface=\"popover\" id=\"typeOfTreatement\"  (ionChange)=\"updateDataValue($event,'typeOfTreatement')\" >\r\n                        <ion-select-option value=\"1\"> Natural Bypass Therapy(ECP)</ion-select-option>\r\n                        <ion-select-option value=\"2\"> Bio Angioplasty (BCA)</ion-select-option>\r\n                        <ion-select-option value=\"3\"> Both ECP and BCA</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Additional Information</ion-label>\r\n\r\n                    <ion-textarea id=\"daignosisSummary\" ngDefaultControl formControlName=\"daignosisSummary\" rows=\"5\" type=\"text\">\r\n                    </ion-textarea>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n            <ion-col size=\"5\">\r\n                <ion-item lines=\"none\">\r\n\r\n                    Invoice Amount\r\n\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-input id=\"invoiceTotalamt\" ngDefaultControl formControlName=\"invoiceTotalamt\" type=\"text\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-button float-right type=\"submit\"  [disabled]=\"!doctorDetailsForm.valid\">Submit</ion-button>\r\n        <ion-button float-right type=\"reset\">Reset</ion-button>\r\n\r\n    </ion-grid>\r\n</form>\r\n\r\n<ion-item-divider class=\"divider\">\r\n</ion-item-divider>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>Consultation Details</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable no-padding class=\"material fullscreenManual\" [headerHeight]=\"50\" [scrollbarH]='true' [limit]=\"5\" [columnMode]=\"'flexi'\" [footerHeight]=\"50\" [rowHeight]=\"'auto'\" [rows]=\"rowsDoctor\">\r\n                <ngx-datatable-column name=\"Consulation Date\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\">\r\n                        {{value | date : 'MMM d, y ' }}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Consultation By\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        {{value}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Treatment Type\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.typeOfTreatementDomain.treatmentName}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Ref No\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.invoiceDomain.id}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n               \r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>Invoice Details</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable   [rowClass]=\"getRowClass\" #myTable class='material fullscreenManual' \r\n            [limit]=\"5\" [columnMode]=\"'flexi'\" [headerHeight]=\"50\" [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"'auto'\" \r\n         \r\n            [scrollbarH]=\"'true'\" [rows]='rowsInvoice' >\r\n                <ngx-datatable-column name=\"Invoice No\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.id}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Type\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.invoiceType.typeName}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Generated By\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.generatedBy.username}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n                <ngx-datatable-column name=\"Payment Mode\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-select *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" value=\"\" name=\"paymentMode\" (ionChange)=\"updateValueInvoice($event, 'paymentMode', rowIndex)\">\r\n                            <ion-select-option value=\"cheque\">Cheque</ion-select-option>\r\n                            <ion-select-option value=\"online\">Online</ion-select-option>\r\n                            <ion-select-option value=\"cash\">Cash</ion-select-option>\r\n                        </ion-select>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Bank Name\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" name=\"bankName\" autofocus (blur)=\"updateValueInvoice($event, 'bankName', rowIndex)\" type=\"text\">\r\n\r\n                        </ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Reference Number\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" autofocus (blur)=\"updateValueInvoice($event, 'referenceNumber', rowIndex)\" type=\"text\"></ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" autofocus (blur)=\"updateValueInvoice($event, 'paymentAmount', rowIndex)\" type=\"number\"></ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Total Invoice Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.totalInvoiceAmt}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Balance Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.balanceAmt}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Status\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n\r\n                        <ion-select value=\"{{row.invoiceStatus}}\" [disabled]=\"row.invoiceStatus=='Payement Completed'\" name=\"invoiceStatus\" (ionChange)=\"updateValueInvoice($event, 'cancelInvoice', rowIndex)\">\r\n                            <ion-select-option value=\"Total Payment Pending\">Pending</ion-select-option>\r\n                            <ion-select-option value=\"Partially Pending\">Partial</ion-select-option>\r\n                            <ion-select-option value=\"Payement Completed\">Completed</ion-select-option>\r\n                            <ion-select-option value=\"Invoice Cancelled\">Cancel</ion-select-option>\r\n\r\n                        </ion-select>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column  width=\"200\" name=\"Action\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\" >\r\n\r\n                        <ion-button *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" size=\"small\" shape=\"round\" (click)=\"generateReciept($event, 'name', rowIndex, row)\" color=\"primary\">Generate Reciept  </ion-button>\r\n\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>Payement Receipts</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable #myTable class='material fullscreenManual' [columnMode]=\"'flexi'\" [headerHeight]=\"50\" \r\n            [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"'auto'\" [scrollbarH]=\"'true'\" [limit]=\"5\" [rows]='rowsPayment'>\r\n                <ngx-datatable-column name=\"Invoice No\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.invoiceId}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Recived By\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.recievedBy}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Date\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.paymentDate | date : 'MMM d, y '}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Reference Number\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.paymentReferenceNo}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Mode\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-text> {{row.paymentMode}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        <ion-text> {{row.paymentAmount}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n                <ngx-datatable-column width=\"200\" name=\"Print\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-button size=\"small\" shape=\"round\" (click)=\"printReciept($event, 'name', rowIndex, row)\" color=\"primary\">Print Reciept</ion-button>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>"

/***/ }),

/***/ "./src/app/components/doctor-details/doctor-details.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/components/doctor-details/doctor-details.component.scss ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".divider {\n  border-bottom: 2px solid black !important; }\n\n.noLines {\n  border-bottom: 0px !important; }\n\n/* Structure */\n\nion-grid {\n  border: 1px solid black !important; }\n\n.fullscreenManual {\n  height: auto !important;\n  width: 95%; }\n\n:host /deep/ .datatable-row-group {\n  will-change: transform; }\n\n:host /deep/ .ngx-datatable.material .datatable-header .datatable-row-right {\n  margin-left: -8px; }\n\n:host /deep/ .row-color {\n  background-color: lightgreen; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9kb2N0b3ItZGV0YWlscy9DOlxcQmFzaWNzXFxDXFxwb2ludGVyc1xcc2Fhb2xoZWFydFVJL3NyY1xcYXBwXFxjb21wb25lbnRzXFxkb2N0b3ItZGV0YWlsc1xcZG9jdG9yLWRldGFpbHMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQ0FBeUMsRUFDNUM7O0FBRUQ7RUFDSSw4QkFBNkIsRUFDaEM7O0FBR0QsZUFBZTs7QUFFZjtFQUNJLG1DQUFrQyxFQUNyQzs7QUFFRDtFQUNJLHdCQUF1QjtFQUN2QixXQUFVLEVBQ2I7O0FBRUQ7RUFDSSx1QkFBc0IsRUFDekI7O0FBRUE7RUFDRyxrQkFBaUIsRUFDcEI7O0FBRUQ7RUFDSSw2QkFBNEIsRUFDL0IiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL2RvY3Rvci1kZXRhaWxzL2RvY3Rvci1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmRpdmlkZXIge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkIGJsYWNrICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ub0xpbmVzIHtcclxuICAgIGJvcmRlci1ib3R0b206IDBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxuLyogU3RydWN0dXJlICovXHJcblxyXG5pb24tZ3JpZCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCBibGFjayAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZnVsbHNjcmVlbk1hbnVhbCB7XHJcbiAgICBoZWlnaHQ6IGF1dG8gIWltcG9ydGFudDtcclxuICAgIHdpZHRoOiA5NSU7XHJcbn1cclxuXHJcbjpob3N0IC9kZWVwLyAuZGF0YXRhYmxlLXJvdy1ncm91cCB7XHJcbiAgICB3aWxsLWNoYW5nZTogdHJhbnNmb3JtO1xyXG59XHJcblxyXG4gOmhvc3QgL2RlZXAvIC5uZ3gtZGF0YXRhYmxlLm1hdGVyaWFsIC5kYXRhdGFibGUtaGVhZGVyIC5kYXRhdGFibGUtcm93LXJpZ2h0IHtcclxuICAgIG1hcmdpbi1sZWZ0OiAtOHB4O1xyXG59XHJcblxyXG46aG9zdCAvZGVlcC8gLnJvdy1jb2xvciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyZWVuO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/components/doctor-details/doctor-details.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/components/doctor-details/doctor-details.component.ts ***!
  \***********************************************************************/
/*! exports provided: DoctorDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DoctorDetailsComponent", function() { return DoctorDetailsComponent; });
/* harmony import */ var _services_common_common_util_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/common/common-util.service */ "./src/app/services/common/common-util.service.ts");
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var DoctorDetailsComponent = /** @class */ (function () {
    function DoctorDetailsComponent(activate, fb, customerService, flashProvider, commonService) {
        var _this = this;
        this.activate = activate;
        this.fb = fb;
        this.customerService = customerService;
        this.flashProvider = flashProvider;
        this.commonService = commonService;
        this.doctorDetailsForm = {};
        /**
         * Doctor Consultation Row Details
         */
        this.editingDoctor = {};
        this.rowsDoctor = [];
        this.columnsDoctor = [];
        /**
        * Invoice Consultation Row Details
        */
        this.editingInvoice = {};
        this.rowsInvoice = [];
        this.rowInvoiceFromDb = [];
        this.columnsInvoice = [];
        /**
        * Payment Consultation Row Details
        */
        this.editingPayment = {};
        this.rowsPayment = [];
        this.columnsPayment = [];
        this.getRowClass = function (row) {
            if (!(row.invoiceStatus == 'Total Payment Pending' || row.invoiceStatus == 'Partially Pending')) {
                return {
                    'row-color': true
                };
            }
            else {
                return {
                    'row-color': false
                };
            }
        };
        this.myFilter = function (d) {
            var day = d.getDay();
            // Prevent Saturday and Sunday from being selected.
            return day !== 0;
        };
        this.doctorDetailfromDb = this.activate.snapshot.data['data'];
        this.invoiceMasterType = this.activate.snapshot.data['invoiceType'];
        this.invoiceMasterType.forEach(function (element) {
            if (element.typeName === 'DOCTOR CONSULTATION') {
                _this.invoiceTypeId = element.id;
            }
        });
        this.doctorDetailsForm = this.createForm({
            id: [],
            consulationDate: [],
            consultationBy: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            daignosisSummary: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            testSuggested: [''],
            typeOfTreatement: [, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])],
            invoice: [],
            customerId: [this.doctorDetailfromDb.id],
            invoiceTotalamt: [, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
            invoiceMasterTypeId: [this.invoiceTypeId]
        });
        this.rowsDoctor = this.doctorDetailfromDb.doctorConsultationList;
        if (this.doctorDetailfromDb.doctorConsultationList.length > 0) {
            this.columnsDoctor = Object.keys(this.doctorDetailfromDb.doctorConsultationList[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        this.updateInvoiceAndPaymentDomain(this.doctorDetailfromDb.doctorConsultationList);
    }
    DoctorDetailsComponent.prototype.updateSingleInvoiceDomainAndAllPaymentList = function (list) {
        var _this = this;
        list.invoiceReciptList.filter(function (val) {
            _this.rowsPayment.push(val);
        });
        this.rowsPayment = this.rowsPayment.slice();
        var ind;
        this.rowsInvoice.forEach(function (ele, index) {
            if (ele.id === list.id) {
                ind = index;
            }
        });
        if (ind != null) {
            this.rowsInvoice[ind] = list;
            this.rowsInvoice = this.rowsInvoice.slice();
        }
    };
    DoctorDetailsComponent.prototype.updateInvoiceAndPaymentDomain = function (obj) {
        var _this = this;
        obj.filter(function (ele) {
            console.log(ele);
            _this.rowsInvoice.push(ele.invoiceDomain);
            _this.rowInvoiceFromDb.push(ele.invoiceDomain);
            ele.invoiceDomain.invoiceReciptList.filter(function (val) {
                _this.rowsPayment.push(val);
            });
            return ele.invoiceDomain;
        });
        if (this.rowsInvoice.length > 0) {
            this.columnsInvoice = Object.keys(this.rowsInvoice[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        if (this.rowsPayment.length > 0) {
            this.columnsInvoice = Object.keys(this.rowsPayment[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        this.rowsInvoice = this.rowsInvoice.slice();
    };
    DoctorDetailsComponent.prototype.ngOnInit = function () {
    };
    DoctorDetailsComponent.prototype.updateForm = function (model) {
        this.doctorDetailsForm.patchValue(model);
    };
    DoctorDetailsComponent.prototype.createForm = function (model) {
        return this.fb.group(model);
    };
    DoctorDetailsComponent.prototype.updateValueDoctor = function (event, cell, rowIndex) {
        this.editingDoctor[rowIndex + '-' + cell] = false;
        this.rowsDoctor[rowIndex][cell] = event.target.value;
    };
    DoctorDetailsComponent.prototype.onSubmit = function () {
        var _this = this;
        console.log(this.doctorDetailsForm.value);
        this.customerService.saveDoctorDetails(this.doctorDetailsForm.value).subscribe(function (res) {
            console.log(res);
            _this.rowsDoctor.push(res.document);
            _this.rowsDoctor = _this.rowsDoctor.slice();
            var val = [];
            val.push(res.document);
            _this.updateInvoiceAndPaymentDomain(val);
            _this.flashProvider.showGreen(res.error, 4000);
        }, function (err) {
            console.log(err);
            _this.flashProvider.showRed(err.error, 4000);
        });
    };
    DoctorDetailsComponent.prototype.updateValueInvoice = function (event, cell, rowIndex) {
        /**
         * Bug needs to be solved the Balance amount not getting reset to original DB amount when entered zero
         */
        if (cell === 'paymentAmount') {
            var balAmt = this.rowInvoiceFromDb[rowIndex]['balanceAmt'];
            console.log(balAmt);
            var newBalAmt = Number(balAmt) - Number(event.target.value);
            if (isNaN(newBalAmt)) {
            }
            else if (newBalAmt < 0) {
                var err = new Array();
                err.push('Kindly Enter Amount Less than the balance amount');
                this.flashProvider.showRed(err, 5000);
                event.target.value = '';
                return;
            }
            else {
                this.rowsInvoice[rowIndex]['balanceAmt'] = newBalAmt;
                this.rowsInvoice = this.rowsInvoice.slice();
                console.log(this.rowsInvoice);
            }
        }
        this.editingInvoice[rowIndex + '-' + cell] = false;
        this.rowsInvoice[rowIndex][cell] = event.target.value;
    };
    DoctorDetailsComponent.prototype.updateValuePayment = function (event, cell, rowIndex) {
        this.editingPayment[rowIndex + '-' + cell] = false;
        this.rowsPayment[rowIndex][cell] = event.target.value;
    };
    DoctorDetailsComponent.prototype.printReciept = function (event, cell, rowIndex, row) {
        this.customerService.printRecipt(row).subscribe(function (res) {
            console.log(res);
            // const blob = new Blob([data], { type: 'text/csv' });
            var url = window.URL.createObjectURL(res);
            // window.open(url); if Image needs to open in new tab
            var a = document.createElement('a');
            a.href = url;
            a.download = 'File.pdf';
            a.click();
        }, function (errr) {
            console.log(errr);
        });
    };
    DoctorDetailsComponent.prototype.generateReciept = function (event, cell, rowIndex, row) {
        var _this = this;
        this.customerService.generateReciept(row).subscribe(function (res) {
            _this.updateSingleInvoiceDomainAndAllPaymentList(res.document);
            console.log(res);
            _this.flashProvider.showGreen(res.error, 5000);
        }, function (err) {
            console.log(err);
            _this.flashProvider.showRed(err.error, 5000);
        });
    };
    DoctorDetailsComponent.prototype.updateDataValue = function (eve, tar) {
        var val;
        if (tar === 'typeOfTreatement') {
            val = parseInt(eve.target.value, 10);
        }
        else {
            val = eve.target.value;
        }
        this.doctorDetailsForm.get(tar).setValue(val);
    };
    DoctorDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
            selector: 'app-doctor-details',
            template: __webpack_require__(/*! ./doctor-details.component.html */ "./src/app/components/doctor-details/doctor-details.component.html"),
            styles: [__webpack_require__(/*! ./doctor-details.component.scss */ "./src/app/components/doctor-details/doctor-details.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_2__["CustomerService"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_1__["FlashMessageService"],
            _services_common_common_util_service__WEBPACK_IMPORTED_MODULE_0__["CommonUtilService"]])
    ], DoctorDetailsComponent);
    return DoctorDetailsComponent;
}());



/***/ }),

/***/ "./src/app/components/flash-message/flash-message.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/components/flash-message/flash-message.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div (click)=\"hide()\" @messageState *ngIf=\"activeRed\" class=\"flash-container-red\">\r\n\r\n    <!-- <div class=\"message\">\r\n        {{message}}\r\n    </div> -->\r\n\r\n    <div *ngFor=\"let mess of message\" class=\"message\">  \r\n        <ol>\r\n            <li>{{mess}}</li>\r\n        </ol>\r\n    </div>\r\n\r\n</div>\r\n<div (click)=\"hide()\" @messageState *ngIf=\"activeGreen\" class=\"flash-container-green\">\r\n\r\n    <!-- <div class=\"message\">\r\n        {{message}}\r\n    </div> -->\r\n\r\n    <div *ngFor=\"let mess of message\" class=\"message\">\r\n        <ol>\r\n            <li>{{mess}}</li>\r\n        </ol>\r\n    </div>\r\n\r\n</div>"

/***/ }),

/***/ "./src/app/components/flash-message/flash-message.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/components/flash-message/flash-message.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".flash-container-red {\n  position: absolute;\n  top: 10;\n  width: 100%;\n  height: 56px;\n  color: #fff;\n  background-color: #ff7675;\n  border: 1px solid #d63031;\n  z-index: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center; }\n\n.flash-container-green {\n  position: absolute;\n  top: 10;\n  width: 100%;\n  height: 56px;\n  color: #fff;\n  background-color: lightgreen;\n  border: 1px solid green;\n  z-index: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9mbGFzaC1tZXNzYWdlL0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXGNvbXBvbmVudHNcXGZsYXNoLW1lc3NhZ2VcXGZsYXNoLW1lc3NhZ2UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBa0I7RUFDbEIsUUFBTztFQUNQLFlBQVc7RUFDWCxhQUFZO0VBQ1osWUFBVztFQUNYLDBCQUF5QjtFQUN6QiwwQkFBeUI7RUFDekIsV0FBVTtFQUNWLGNBQWE7RUFDYixvQkFBbUI7RUFDbkIsd0JBQXVCLEVBQzFCOztBQUNEO0VBQ0ksbUJBQWtCO0VBQ2xCLFFBQU87RUFDUCxZQUFXO0VBQ1gsYUFBWTtFQUNaLFlBQVc7RUFDWCw2QkFBNEI7RUFDNUIsd0JBQXVCO0VBQ3ZCLFdBQVU7RUFDVixjQUFhO0VBQ2Isb0JBQW1CO0VBQ25CLHdCQUF1QixFQUMxQiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvZmxhc2gtbWVzc2FnZS9mbGFzaC1tZXNzYWdlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZsYXNoLWNvbnRhaW5lci1yZWQge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA1NnB4O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmY3Njc1O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2Q2MzAzMTtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcbi5mbGFzaC1jb250YWluZXItZ3JlZW4ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA1NnB4O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyZWVuO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgZ3JlZW47XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/flash-message/flash-message.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/flash-message/flash-message.component.ts ***!
  \*********************************************************************/
/*! exports provided: FlashMessageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FlashMessageComponent", function() { return FlashMessageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/fesm5/animations.js");
/* harmony import */ var src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var FlashMessageComponent = /** @class */ (function () {
    function FlashMessageComponent(flashProvider) {
        this.flashProvider = flashProvider;
        this.activeGreen = false;
        this.activeRed = false;
        this.message = [];
    }
    FlashMessageComponent.prototype.ngOnInit = function () {
        this.flashProvider.showRed = this.showRed.bind(this);
        this.flashProvider.showGreen = this.showGreen.bind(this);
        this.flashProvider.hide = this.hide.bind(this);
    };
    FlashMessageComponent.prototype.showGreen = function (message, duration) {
        var _this = this;
        this.message = message;
        this.activeGreen = true;
        setTimeout(function () {
            _this.activeGreen = false;
        }, duration);
    };
    FlashMessageComponent.prototype.showRed = function (message, duration) {
        var _this = this;
        this.message = message;
        this.activeRed = true;
        setTimeout(function () {
            _this.activeRed = false;
        }, duration);
    };
    FlashMessageComponent.prototype.hide = function () {
        this.activeRed = false;
        this.activeGreen = false;
    };
    FlashMessageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-flash-message',
            template: __webpack_require__(/*! ./flash-message.component.html */ "./src/app/components/flash-message/flash-message.component.html"),
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["trigger"])('messageState', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ transform: 'translateY(-100%)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('200ms ease-out')
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["animate"])('200ms ease-in', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_1__["style"])({ opacity: '0' }))
                    ])
                ])
            ],
            styles: [__webpack_require__(/*! ./flash-message.component.scss */ "./src/app/components/flash-message/flash-message.component.scss")]
        }),
        __metadata("design:paramtypes", [src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_2__["FlashMessageService"]])
    ], FlashMessageComponent);
    return FlashMessageComponent;
}());



/***/ }),

/***/ "./src/app/components/header/header.component.html":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n\r\n    <ion-toolbar color=\"secondary\">\r\n\r\n        <ion-buttons slot=\"secondary\">\r\n            <ion-button>\r\n                <ion-icon slot=\"icon-only\" name=\"contact\"></ion-icon>\r\n            </ion-button>\r\n            <ion-button>\r\n                <ion-icon slot=\"icon-only\" name=\"search\"></ion-icon>\r\n            </ion-button>\r\n        </ion-buttons>\r\n        <ion-buttons slot=\"primary\">\r\n            <ion-button (click)=\"presentPopover($event)\" color=\"primary\">\r\n                <ion-icon slot=\"icon-only\" name=\"more\"></ion-icon>\r\n            </ion-button>\r\n        </ion-buttons>\r\n\r\n        <ion-title>\r\n                \r\n            <ion-grid>\r\n                <ion-row nowrap>\r\n                    <ion-col size=\"1\" class=\"col-logo-size\" no-padding>\r\n                        <ion-button  color=\"secondary\" (click)=\"toggleMenu()\">\r\n                            <ion-icon slot=\"icon-only\" name=\"menu\"></ion-icon>\r\n                        </ion-button>  \r\n\r\n                    </ion-col>\r\n                    <ion-col size=\"1\" class=\"col-logo-size\" no-padding>\r\n\r\n                        <ion-icon class=\"\" size=\"large\" name=\"logo-skype\"></ion-icon>\r\n                    </ion-col>\r\n                    <ion-col>\r\n                        <ion-label class=\"toolbar-label\"> Saaol Heart Center Juhu </ion-label>\r\n                    </ion-col>\r\n                </ion-row>\r\n\r\n            </ion-grid>\r\n        </ion-title>\r\n    </ion-toolbar>\r\n</ion-header>"

/***/ }),

/***/ "./src/app/components/header/header.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var _toolpop_toolpop_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../toolpop/toolpop.component */ "./src/app/components/toolpop/toolpop.component.ts");
/* harmony import */ var src_app_services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/dashboard/dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(menu, dashboardService, popoverController) {
        this.menu = menu;
        this.dashboardService = dashboardService;
        this.popoverController = popoverController;
        console.log("iasd");
    }
    HeaderComponent.prototype.ngOnInit = function () {
        console.log("iasd");
    };
    HeaderComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        console.log("iasd");
        this.articleSub = this.dashboardService.navItem$.subscribe(function (res) {
            console.log("iasd");
            _this.menuBool = res;
        });
        //this.dashboardService.getMessage().subscribe();
    };
    HeaderComponent.prototype.toggleMenu = function () {
        var _this = this;
        var bool;
        this.menu.isEnabled('main').then(function (res) {
            console.log(res);
            bool = !res;
            _this.menu.enable(bool, 'main');
        });
    };
    HeaderComponent.prototype.presentPopover = function (ev) {
        return __awaiter(this, void 0, void 0, function () {
            var popover;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.popoverController.create({
                            component: _toolpop_toolpop_component__WEBPACK_IMPORTED_MODULE_0__["ToolpopComponent"],
                            event: ev,
                            translucent: true,
                        })];
                    case 1:
                        popover = _a.sent();
                        return [4 /*yield*/, popover.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    HeaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/components/header/header.component.html"),
            providers: [],
            styles: [__webpack_require__(/*! ./header.component.scss */ "./src/app/components/header/header.component.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"],
            src_app_services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_1__["DashboardService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/components/invoice-details/invoice-details.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/components/invoice-details/invoice-details.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\r\n  invoice-details works!\r\n</p>\r\n"

/***/ }),

/***/ "./src/app/components/invoice-details/invoice-details.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/components/invoice-details/invoice-details.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvaW52b2ljZS1kZXRhaWxzL2ludm9pY2UtZGV0YWlscy5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/invoice-details/invoice-details.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/invoice-details/invoice-details.component.ts ***!
  \*************************************************************************/
/*! exports provided: InvoiceDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoiceDetailsComponent", function() { return InvoiceDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var InvoiceDetailsComponent = /** @class */ (function () {
    function InvoiceDetailsComponent() {
    }
    InvoiceDetailsComponent.prototype.ngOnInit = function () {
    };
    InvoiceDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-invoice-details',
            template: __webpack_require__(/*! ./invoice-details.component.html */ "./src/app/components/invoice-details/invoice-details.component.html"),
            styles: [__webpack_require__(/*! ./invoice-details.component.scss */ "./src/app/components/invoice-details/invoice-details.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], InvoiceDetailsComponent);
    return InvoiceDetailsComponent;
}());



/***/ }),

/***/ "./src/app/components/loader/loader.component.html":
/*!*********************************************************!*\
  !*** ./src/app/components/loader/loader.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [class.hidden]=\"!show\">\r\n    <div class=\"loader-overlay\">\r\n      <div *ngIf=\"show\" class=\"loader\"></div>\r\n      <div class=\"flash-container-red\"><h2>Please Wait while the page is loaded !!!</h2>   </div>\r\n    </div>\r\n  </div>"

/***/ }),

/***/ "./src/app/components/loader/loader.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/loader/loader.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".hidden {\n  visibility: hidden; }\n\n.loader-overlay {\n  position: absolute;\n  width: 100%;\n  top: 0;\n  position: fixed;\n  height: 100%;\n  background: rgba(0, 0, 0, 0.7);\n  z-index: 20;\n  top: 0;\n  left: 0; }\n\n.loader {\n  height: 4px;\n  width: 100%;\n  position: relative;\n  overflow: hidden;\n  background-color: #FFF; }\n\n.loader:before {\n  display: block;\n  position: absolute;\n  content: \"\";\n  left: -200px;\n  width: 200px;\n  height: 4px;\n  background-color: red;\n  -webkit-animation: loading 2s linear infinite;\n          animation: loading 2s linear infinite; }\n\n.flash-container-red {\n  position: absolute;\n  top: 10;\n  width: 100%;\n  height: 56px;\n  color: #fff;\n  background-color: #ff7675;\n  border: 1px solid #d63031;\n  z-index: 1;\n  display: flex;\n  align-items: center;\n  justify-content: center; }\n\n@-webkit-keyframes loading {\n  from {\n    left: -200px;\n    width: 30%; }\n  50% {\n    width: 30%; }\n  70% {\n    width: 70%; }\n  80% {\n    left: 50%; }\n  95% {\n    left: 120%; }\n  to {\n    left: 100%; } }\n\n@keyframes loading {\n  from {\n    left: -200px;\n    width: 30%; }\n  50% {\n    width: 30%; }\n  70% {\n    width: 70%; }\n  80% {\n    left: 50%; }\n  95% {\n    left: 120%; }\n  to {\n    left: 100%; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9sb2FkZXIvQzpcXEJhc2ljc1xcQ1xccG9pbnRlcnNcXHNhYW9saGVhcnRVSS9zcmNcXGFwcFxcY29tcG9uZW50c1xcbG9hZGVyXFxsb2FkZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBa0IsRUFDbkI7O0FBQ0Q7RUFDRSxtQkFBa0I7RUFDbEIsWUFBVztFQUNYLE9BQU07RUFDTixnQkFBZTtFQUNqQixhQUFZO0VBQ1osK0JBQTJCO0VBQzNCLFlBQVc7RUFDWCxPQUFNO0VBQ04sUUFBTyxFQUNOOztBQUNEO0VBQ0UsWUFBVztFQUNYLFlBQVc7RUFDWCxtQkFBa0I7RUFDbEIsaUJBQWdCO0VBQ2hCLHVCQUFzQixFQUN2Qjs7QUFDRDtFQUNFLGVBQWM7RUFDZCxtQkFBa0I7RUFDbEIsWUFBVztFQUNYLGFBQVk7RUFDWixhQUFZO0VBQ1osWUFBVztFQUNYLHNCQUFxQjtFQUNyQiw4Q0FBcUM7VUFBckMsc0NBQXFDLEVBQ3RDOztBQUVEO0VBQ0UsbUJBQWtCO0VBQ2xCLFFBQU87RUFDUCxZQUFXO0VBQ1gsYUFBWTtFQUNaLFlBQVc7RUFDWCwwQkFBeUI7RUFDekIsMEJBQXlCO0VBQ3pCLFdBQVU7RUFDVixjQUFhO0VBQ2Isb0JBQW1CO0VBQ25CLHdCQUF1QixFQUMxQjs7QUFDQztFQUNFO0lBQU0sYUFBWTtJQUFFLFdBQVUsRUFBQTtFQUM5QjtJQUFLLFdBQVUsRUFBQTtFQUNmO0lBQUssV0FBVSxFQUFBO0VBQ2Y7SUFBSyxVQUFTLEVBQUE7RUFDZDtJQUFLLFdBQVUsRUFBQTtFQUNmO0lBQUksV0FBVSxFQUFBLEVBQUE7O0FBTmhCO0VBQ0U7SUFBTSxhQUFZO0lBQUUsV0FBVSxFQUFBO0VBQzlCO0lBQUssV0FBVSxFQUFBO0VBQ2Y7SUFBSyxXQUFVLEVBQUE7RUFDZjtJQUFLLFVBQVMsRUFBQTtFQUNkO0lBQUssV0FBVSxFQUFBO0VBQ2Y7SUFBSSxXQUFVLEVBQUEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvbG9hZGVyL2xvYWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oaWRkZW4ge1xyXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gIH1cclxuICAubG9hZGVyLW92ZXJsYXkge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC43KTtcclxuICB6LWluZGV4OiAyMDtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICB9XHJcbiAgLmxvYWRlciB7XHJcbiAgICBoZWlnaHQ6IDRweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkY7XHJcbiAgfVxyXG4gIC5sb2FkZXI6YmVmb3JlIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIGxlZnQ6IC0yMDBweDtcclxuICAgIHdpZHRoOiAyMDBweDtcclxuICAgIGhlaWdodDogNHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmVkO1xyXG4gICAgYW5pbWF0aW9uOiBsb2FkaW5nIDJzIGxpbmVhciBpbmZpbml0ZTtcclxuICB9XHJcblxyXG4gIC5mbGFzaC1jb250YWluZXItcmVkIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMTA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogNTZweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmNzY3NTtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkNjMwMzE7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG4gIEBrZXlmcmFtZXMgbG9hZGluZyB7XHJcbiAgICBmcm9tIHtsZWZ0OiAtMjAwcHg7IHdpZHRoOiAzMCU7fVxyXG4gICAgNTAlIHt3aWR0aDogMzAlO31cclxuICAgIDcwJSB7d2lkdGg6IDcwJTt9XHJcbiAgICA4MCUge2xlZnQ6IDUwJTt9XHJcbiAgICA5NSUge2xlZnQ6IDEyMCU7fVxyXG4gICAgdG8ge2xlZnQ6IDEwMCU7fVxyXG4gIH0iXX0= */"

/***/ }),

/***/ "./src/app/components/loader/loader.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/loader/loader.component.ts ***!
  \*******************************************************/
/*! exports provided: LoaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoaderComponent", function() { return LoaderComponent; });
/* harmony import */ var _services_loader_loader_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/loader/loader.service */ "./src/app/services/loader/loader.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var LoaderComponent = /** @class */ (function () {
    function LoaderComponent(loaderService, loadingCtrl) {
        this.loaderService = loaderService;
        this.loadingCtrl = loadingCtrl;
        this.show = false;
    }
    LoaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.subscription = this.loaderService.loaderState
            .subscribe(function (state) {
            _this.show = state.show;
        });
    };
    LoaderComponent.prototype.ngOnDestroy = function () {
        this.subscription.unsubscribe();
    };
    LoaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-loader',
            template: __webpack_require__(/*! ./loader.component.html */ "./src/app/components/loader/loader.component.html"),
            styles: [__webpack_require__(/*! ./loader.component.scss */ "./src/app/components/loader/loader.component.scss")]
        }),
        __metadata("design:paramtypes", [_services_loader_loader_service__WEBPACK_IMPORTED_MODULE_0__["LoaderService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
    ], LoaderComponent);
    return LoaderComponent;
}());



/***/ }),

/***/ "./src/app/components/mark-appointment/mark-appointment.module.ts":
/*!************************************************************************!*\
  !*** ./src/app/components/mark-appointment/mark-appointment.module.ts ***!
  \************************************************************************/
/*! exports provided: MarkAppointmentPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MarkAppointmentPageModule", function() { return MarkAppointmentPageModule; });
/* harmony import */ var ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ng-pick-datetime/dialog */ "./node_modules/ng-pick-datetime/dialog/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _mark_appointment_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mark-appointment.page */ "./src/app/components/mark-appointment/mark-appointment.page.ts");
/* harmony import */ var ng_pick_datetime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ng-pick-datetime */ "./node_modules/ng-pick-datetime/picker.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};








var routes = [
    {
        path: '',
        component: _mark_appointment_page__WEBPACK_IMPORTED_MODULE_6__["MarkAppointmentPage"]
    }
];
var MarkAppointmentPageModule = /** @class */ (function () {
    function MarkAppointmentPageModule() {
    }
    MarkAppointmentPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_7__["OwlDateTimeModule"],
                ng_pick_datetime__WEBPACK_IMPORTED_MODULE_7__["OwlNativeDateTimeModule"],
                ng_pick_datetime_dialog__WEBPACK_IMPORTED_MODULE_0__["OwlDialogModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_mark_appointment_page__WEBPACK_IMPORTED_MODULE_6__["MarkAppointmentPage"]]
        })
    ], MarkAppointmentPageModule);
    return MarkAppointmentPageModule;
}());



/***/ }),

/***/ "./src/app/components/mark-appointment/mark-appointment.page.html":
/*!************************************************************************!*\
  !*** ./src/app/components/mark-appointment/mark-appointment.page.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-list>\r\n    <ion-list-header>\r\n        Update Plan\r\n    </ion-list-header>\r\n    <ion-item no-lines>\r\n        <ion-radio-group>\r\n            <ion-list-header>\r\n                Is Visit Completed\r\n            </ion-list-header>\r\n\r\n            <ion-item>\r\n                <ion-label>YES</ion-label>\r\n                <ion-radio slot=\"start\" value=\"Yes\" [(ngModel)]=\"isVisitDone\">Yes</ion-radio>\r\n            </ion-item>\r\n\r\n            <ion-item>\r\n                <ion-label>NO</ion-label>\r\n                <ion-radio slot=\"start\" value=\"No\" [(ngModel)]=\"isVisitDone\">No</ion-radio>\r\n            </ion-item>\r\n        </ion-radio-group>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n        <ion-label position=\"floating\">Duration of Treatment/Visit</ion-label>\r\n        <!-- <ion-input type=\"number\" min=\"0\" max=\"60\" name=\"duration\" [(ngModel)]=\"duration\"></ion-input> -->\r\n        <!-- <input  [owlDateTime]=\"dt1\" [(ngModel)]=\"duration\"  [owlDateTimeTrigger]=\"dt1\" placeholder=\"Date Time\">\r\n        <owl-date-time #dt1 hour12Timer=\"true\" [pickerType]=\"'timer'\" stepHour=\"1\" stepMinute=\"30\"> </owl-date-time> -->\r\n        <ion-select interface=\"popover\" [(ngModel)]=\"duration\" placeholder=\"select duration\">\r\n            <ion-select-option value=\"60\">1 hr</ion-select-option>\r\n            <ion-select-option value=\"30\">30 min</ion-select-option>\r\n            <ion-select-option value=\"0\">0 min</ion-select-option>\r\n                </ion-select>\r\n    </ion-item>\r\n    <ion-item>\r\n        <ion-label> Suggestions/Complaints </ion-label>\r\n        <ion-textarea rows=\"6\" cols=\"20\" [(ngModel)]=\"complaints\" placeholder=\"Enter any notes here...\"></ion-textarea>\r\n\r\n    </ion-item>\r\n    <ion-item>\r\n        <ion-button shape=\"round\" size=\"default\" slot=\"end\" (click)=\"closeModel()\">Update</ion-button>\r\n    </ion-item>\r\n</ion-list>"

/***/ }),

/***/ "./src/app/components/mark-appointment/mark-appointment.page.scss":
/*!************************************************************************!*\
  !*** ./src/app/components/mark-appointment/mark-appointment.page.scss ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host /deep/ .my-custom-modal-css {\n  height: 70%; }\n\n:host /deep/ .modal-wrapper {\n  height: 70%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9tYXJrLWFwcG9pbnRtZW50L0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXGNvbXBvbmVudHNcXG1hcmstYXBwb2ludG1lbnRcXG1hcmstYXBwb2ludG1lbnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBVyxFQUNkOztBQUVEO0VBQ0ksWUFBVyxFQUNkIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9tYXJrLWFwcG9pbnRtZW50L21hcmstYXBwb2ludG1lbnQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3QgL2RlZXAvIC5teS1jdXN0b20tbW9kYWwtY3NzIHtcclxuICAgIGhlaWdodDogNzAlO1xyXG59XHJcblxyXG46aG9zdCAvZGVlcC8gLm1vZGFsLXdyYXBwZXIge1xyXG4gICAgaGVpZ2h0OiA3MCU7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/mark-appointment/mark-appointment.page.ts":
/*!**********************************************************************!*\
  !*** ./src/app/components/mark-appointment/mark-appointment.page.ts ***!
  \**********************************************************************/
/*! exports provided: MarkAppointmentPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MarkAppointmentPage", function() { return MarkAppointmentPage; });
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var MarkAppointmentPage = /** @class */ (function () {
    function MarkAppointmentPage(modalCtrl, flasService) {
        this.modalCtrl = modalCtrl;
        this.flasService = flasService;
        this.modalController = this.modalCtrl;
    }
    MarkAppointmentPage.prototype.ngOnInit = function () {
    };
    MarkAppointmentPage.prototype.closeModel = function () {
        if (this.isVisitDone != null && this.duration != null && this.complaints != null) {
            var dat = { isVisitDone: this.isVisitDone,
                duration: this.duration, complaints: this.complaints };
            this.modalCtrl.dismiss(dat);
        }
        else {
            this.flasService.showRed('Please enter all data related to Update', 4000);
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", String)
    ], MarkAppointmentPage.prototype, "isVisitDone", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", Number)
    ], MarkAppointmentPage.prototype, "duration", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"])(),
        __metadata("design:type", String)
    ], MarkAppointmentPage.prototype, "complaints", void 0);
    MarkAppointmentPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-mark-appointment',
            template: __webpack_require__(/*! ./mark-appointment.page.html */ "./src/app/components/mark-appointment/mark-appointment.page.html"),
            styles: [__webpack_require__(/*! ./mark-appointment.page.scss */ "./src/app/components/mark-appointment/mark-appointment.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__["FlashMessageService"]])
    ], MarkAppointmentPage);
    return MarkAppointmentPage;
}());



/***/ }),

/***/ "./src/app/components/sales-invoice-history/sales-invoice-history.component.html":
/*!***************************************************************************************!*\
  !*** ./src/app/components/sales-invoice-history/sales-invoice-history.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  sales-invoice-history works!\n</p>\n"

/***/ }),

/***/ "./src/app/components/sales-invoice-history/sales-invoice-history.component.scss":
/*!***************************************************************************************!*\
  !*** ./src/app/components/sales-invoice-history/sales-invoice-history.component.scss ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc2FsZXMtaW52b2ljZS1oaXN0b3J5L3NhbGVzLWludm9pY2UtaGlzdG9yeS5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/sales-invoice-history/sales-invoice-history.component.ts":
/*!*************************************************************************************!*\
  !*** ./src/app/components/sales-invoice-history/sales-invoice-history.component.ts ***!
  \*************************************************************************************/
/*! exports provided: SalesInvoiceHistoryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesInvoiceHistoryComponent", function() { return SalesInvoiceHistoryComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var SalesInvoiceHistoryComponent = /** @class */ (function () {
    function SalesInvoiceHistoryComponent() {
    }
    SalesInvoiceHistoryComponent.prototype.ngOnInit = function () {
    };
    SalesInvoiceHistoryComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-sales-invoice-history',
            template: __webpack_require__(/*! ./sales-invoice-history.component.html */ "./src/app/components/sales-invoice-history/sales-invoice-history.component.html"),
            styles: [__webpack_require__(/*! ./sales-invoice-history.component.scss */ "./src/app/components/sales-invoice-history/sales-invoice-history.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], SalesInvoiceHistoryComponent);
    return SalesInvoiceHistoryComponent;
}());



/***/ }),

/***/ "./src/app/components/sales-invoice-info/sales-invoice-info.component.html":
/*!*********************************************************************************!*\
  !*** ./src/app/components/sales-invoice-info/sales-invoice-info.component.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-grid>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Invoice Number:- </b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{salesInfo.invoiceOfPurchase.id}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b> Date of Sale: -</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{salesInfo.invoiceOfPurchase.createdDate | date : 'MMM d, y, h:mm:ss a'}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b> Total Amount: -</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{salesInfo.invoiceOfPurchase.totalInvoiceAmt}} \n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>     Generated By</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{salesInfo.invoiceOfPurchase.generetedByName}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Customer ID</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{salesInfo.customerId}}\n        </ion-col>\n    </ion-row>\n</ion-grid>"

/***/ }),

/***/ "./src/app/components/sales-invoice-info/sales-invoice-info.component.scss":
/*!*********************************************************************************!*\
  !*** ./src/app/components/sales-invoice-info/sales-invoice-info.component.scss ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc2FsZXMtaW52b2ljZS1pbmZvL3NhbGVzLWludm9pY2UtaW5mby5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/sales-invoice-info/sales-invoice-info.component.ts":
/*!*******************************************************************************!*\
  !*** ./src/app/components/sales-invoice-info/sales-invoice-info.component.ts ***!
  \*******************************************************************************/
/*! exports provided: SalesInvoiceInfoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesInvoiceInfoComponent", function() { return SalesInvoiceInfoComponent; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var SalesInvoiceInfoComponent = /** @class */ (function () {
    function SalesInvoiceInfoComponent(activate) {
        this.activate = activate;
        this.salesInfo = this.activate.snapshot.data['dataDetails'].document;
        console.log(this.salesInfo);
    }
    SalesInvoiceInfoComponent.prototype.ngOnInit = function () {
    };
    SalesInvoiceInfoComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sales-invoice-info',
            template: __webpack_require__(/*! ./sales-invoice-info.component.html */ "./src/app/components/sales-invoice-info/sales-invoice-info.component.html"),
            styles: [__webpack_require__(/*! ./sales-invoice-info.component.scss */ "./src/app/components/sales-invoice-info/sales-invoice-info.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_0__["ActivatedRoute"]])
    ], SalesInvoiceInfoComponent);
    return SalesInvoiceInfoComponent;
}());



/***/ }),

/***/ "./src/app/components/sales-invoice-update/sales-invoice-update.component.html":
/*!*************************************************************************************!*\
  !*** ./src/app/components/sales-invoice-update/sales-invoice-update.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ngx-datatable\nstyle=\"width: 90%\"\nclass=\"material\"\n[rows]=\"rows\"\n[columnMode]=\"'force'\"\n[headerHeight]=\"50\"\n[footerHeight]=\"50\"\n[rowHeight]=\"'auto'\"\n[limit]=\"5\"\n[selectedRows]=\"selectedRows\"\n[selected]=\"selected\"\n[selectionType]=\"'checkbox'\"\n[selectAllRowsOnPage]=\"false\"\n[displayCheck]=\"displayCheck\"\n(activate)=\"onActivate($event)\"\n(select)='onSelect($event)'>\n<ngx-datatable-column\n\n  [width]=\"30\"\n  [sortable]=\"false\"\n  [canAutoResize]=\"false\"\n  [draggable]=\"false\"\n  [resizeable]=\"false\"\n  [headerCheckboxable]=\"true\"\n  [checkboxable]=\"true\">\n</ngx-datatable-column>\n\n<ngx-datatable-column name=\"Sr No\">\n    <ng-template let-rowIndex=\"rowIndex\" let-row=\"row\" ngx-datatable-cell-template>\n        <strong>{{rowIndex+1}}</strong>\n    </ng-template>\n</ngx-datatable-column>\n\n<ngx-datatable-column name=\"Stock Name\">\n    <ng-template let-row=\"row\" ngx-datatable-cell-template>\n        <strong>{{row.stockDomain.stockName}}</strong>\n    </ng-template>\n</ngx-datatable-column>\n<ngx-datatable-column name=\"Rate\">\n    <ng-template let-row=\"row\" ngx-datatable-cell-template>\n        <strong>{{row.stockDomain.currentRateOfStock}}</strong>\n    </ng-template>\n</ngx-datatable-column>\n<ngx-datatable-column name=\"Quantity\">\n    <ng-template let-row=\"row\" let-rowIndex=\"rowIndex\" let-value=\"value\"  ngx-datatable-cell-template>\n        <span\n        title=\"Double click to edit\"\n        *ngIf=\"!editingCtAngio[row.id + '-quantityPurchased']\">\n        {{row.quantityPurchased}}\n      </span>\n      <ion-input\n        autofocus\n        (blur)=\"updateValueQty($event, 'quantityPurchased', rowIndex)\"\n        *ngIf=\"editingCtAngio[row.id+ '-quantityPurchased']\"\n        type=\"number\"\n        [value]=\"row.quantityPurchased\"\n        name=\"quantityPurchased\"\n        [min]=\"0\"\n      ></ion-input>\n\n    </ng-template>\n</ngx-datatable-column>\n<ngx-datatable-column name=\"Price\">\n    <ng-template let-row=\"row\" ngx-datatable-cell-template>\n        <strong>{{row.price}}</strong>\n    </ng-template>\n</ngx-datatable-column>\n<ngx-datatable-footer>\n        <ng-template \n          ngx-datatable-footer-template \n          let-rowCount=\"rowCount\"\n          let-pageSize=\"pageSize\"\n          let-selectedCount=\"selectedCount\"\n          let-curPage=\"curPage\"\n          let-offset=\"offset\">\n          <div style=\"padding: 5px 10px\">\n            <div>\n         <strong>Total Invoice Amount:  </strong> <b> {{totalAmount}}</b>\n            </div>\n            <hr style=\"width:100%\" />\n            <div >\n              Selected : {{selected.length}}\n              Rows: {{rowCount}} |\n              Size: {{pageSize}} |\n              \n              \n            </div>\n          </div>\n        </ng-template>\n      </ngx-datatable-footer>\n</ngx-datatable>\n<ion-button  float-right (click)=\"update()\"> Update </ion-button>\n\n"

/***/ }),

/***/ "./src/app/components/sales-invoice-update/sales-invoice-update.component.scss":
/*!*************************************************************************************!*\
  !*** ./src/app/components/sales-invoice-update/sales-invoice-update.component.scss ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc2FsZXMtaW52b2ljZS11cGRhdGUvc2FsZXMtaW52b2ljZS11cGRhdGUuY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/components/sales-invoice-update/sales-invoice-update.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/components/sales-invoice-update/sales-invoice-update.component.ts ***!
  \***********************************************************************************/
/*! exports provided: SalesInvoiceUpdateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesInvoiceUpdateComponent", function() { return SalesInvoiceUpdateComponent; });
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_sales_sales_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/sales/sales.service */ "./src/app/services/sales/sales.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var SalesInvoiceUpdateComponent = /** @class */ (function () {
    function SalesInvoiceUpdateComponent(activate, flash, salesService) {
        this.activate = activate;
        this.flash = flash;
        this.salesService = salesService;
        this.rows = [];
        this.rowDb = [];
        this.selected = [];
        this.editingCtAngio = {};
        this.salesInfo = this.activate.snapshot.data['dataDetails'].document;
        this.totalAmount = this.salesInfo.invoiceOfPurchase.totalInvoiceAmt;
        this.rows = this.salesInfo.customerPurchasesList;
        var rowDblist = JSON.parse(JSON.stringify(this.salesInfo.customerPurchasesList));
        this.rowDb = rowDblist;
    }
    SalesInvoiceUpdateComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.rows.forEach(function (item) {
            _this.editingCtAngio[item.id + '-quantityPurchased'] = false;
        });
    };
    SalesInvoiceUpdateComponent.prototype.onUserEvent = function (e) {
    };
    SalesInvoiceUpdateComponent.prototype.onSelect = function (_a) {
        var selected = _a.selected;
        var _b;
        // console.log('Select Event', selected, this.selected);
        // console.log(this.editingCtAngio);
        console.log("qweqwekjqwkejhwqj");
        this.selected.splice(0, this.selected.length);
        (_b = this.selected).push.apply(_b, selected);
    };
    SalesInvoiceUpdateComponent.prototype.onActivate = function (event) {
        var _this = this;
        if (event.type === 'checkbox') {
            this.rows.forEach(function (item) {
                _this.editingCtAngio[item.id + '-quantityPurchased'] = false;
            });
            this.selected.forEach(function (element) {
                _this.editingCtAngio[element.id + '-quantityPurchased'] = true;
            });
        } // console.log('Activate Event', event);
    };
    SalesInvoiceUpdateComponent.prototype.add = function () {
        this.selected.push(this.rows[1], this.rows[3]);
    };
    SalesInvoiceUpdateComponent.prototype.update = function () {
        var _this = this;
        console.log(this.selected);
        console.log(this.rows);
        var isValid = true;
        var arr = [];
        this.rowDb.forEach(function (v, k) {
            console.log(_this.rows[k].quantityPurchased);
            console.log(v.quantityPurchased);
            if (_this.rows[k].quantityPurchased > v.quantityPurchased) {
                isValid = false;
                var rowth = k + 1;
                arr[k] = 'Kindly Enter Stock less than the ' + v.quantityPurchased + ' quantity for ' + rowth + ' row';
            }
            if (isValid === true) {
                _this.salesService.updateSales(_this.rows).subscribe(function (res) {
                    console.log(res);
                    _this.rows = res.document.customerPurchasesList;
                    _this.totalAmount = res.document.invoiceOfPurchase.totalInvoiceAmt;
                    _this.rows = _this.rows.slice();
                    _this.remove();
                }, function (err) {
                    console.log(err);
                });
            }
            else {
                _this.flash.showRed(arr, 4000);
            }
        });
        // this.selected = [ this.rows[1], this.rows[3] ];
    };
    SalesInvoiceUpdateComponent.prototype.remove = function () {
        this.selected = [];
    };
    SalesInvoiceUpdateComponent.prototype.displayCheck = function (row) {
        return row.name !== 'Ethel Price';
    };
    SalesInvoiceUpdateComponent.prototype.updateValueQty = function (event, cell, rowIndex) {
        this.rows[rowIndex][cell] = event.target.value;
    };
    SalesInvoiceUpdateComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
            selector: 'app-sales-invoice-update',
            template: __webpack_require__(/*! ./sales-invoice-update.component.html */ "./src/app/components/sales-invoice-update/sales-invoice-update.component.html"),
            styles: [__webpack_require__(/*! ./sales-invoice-update.component.scss */ "./src/app/components/sales-invoice-update/sales-invoice-update.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__["FlashMessageService"],
            src_app_services_sales_sales_service__WEBPACK_IMPORTED_MODULE_3__["SalesService"]])
    ], SalesInvoiceUpdateComponent);
    return SalesInvoiceUpdateComponent;
}());



/***/ }),

/***/ "./src/app/components/search-update-schedule/search-update-schedule.component.html":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/search-update-schedule/search-update-schedule.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n<ion-searchbar [(ngModel)]=\"customerString\" ngDefaultControl (ionInput)=\"getCustomerListBySearch($event)\" animated showCancelButton cancelButtonText=\"Custom Cancel\">\r\n</ion-searchbar>\r\n<br>\r\n<ion-list radio-group>\r\n    <ion-item *ngFor=\"let item of customerList\">\r\n        <ion-label>{{item.firstName}} {{item.lastName}}</ion-label>\r\n        <ion-radio color=\"dark\" (ionSelect)=\"getCustomerDetails($event)\" value=\"{{item.id}}\"></ion-radio>\r\n    </ion-item>\r\n</ion-list>"

/***/ }),

/***/ "./src/app/components/search-update-schedule/search-update-schedule.component.scss":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/search-update-schedule/search-update-schedule.component.scss ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc2VhcmNoLXVwZGF0ZS1zY2hlZHVsZS9zZWFyY2gtdXBkYXRlLXNjaGVkdWxlLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/components/search-update-schedule/search-update-schedule.component.ts":
/*!***************************************************************************************!*\
  !*** ./src/app/components/search-update-schedule/search-update-schedule.component.ts ***!
  \***************************************************************************************/
/*! exports provided: SearchUpdateScheduleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchUpdateScheduleComponent", function() { return SearchUpdateScheduleComponent; });
/* harmony import */ var _services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/dashboard/dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_sales_sales_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/sales/sales.service */ "./src/app/services/sales/sales.service.ts");
/* harmony import */ var _customer_appointment_customer_appointment_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../customer-appointment/customer-appointment.page */ "./src/app/components/customer-appointment/customer-appointment.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};







var SearchUpdateScheduleComponent = /** @class */ (function () {
    function SearchUpdateScheduleComponent(customerService, salesService, flashService, modalController, dashboardService) {
        this.customerService = customerService;
        this.salesService = salesService;
        this.flashService = flashService;
        this.modalController = modalController;
        this.dashboardService = dashboardService;
        this.customerDbObj = [];
        this.updateSchedule = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        this.appointment = {};
    }
    SearchUpdateScheduleComponent.prototype.ngOnInit = function () {
    };
    SearchUpdateScheduleComponent.prototype.getCustomerListBySearch = function (event) {
        var _this = this;
        console.log(event.target.value);
        if (event.target.value !== '') {
            this.customerService.getCustomerListByNameOrMobile(event.target.value).subscribe(function (res) {
                _this.customerList = res;
                console.log(res);
            }, function (err) {
                delete _this.customerList;
                console.log(err);
            });
        }
        else {
            delete this.customerList;
        }
    };
    SearchUpdateScheduleComponent.prototype.getCustomerDetails = function (ev) {
        var _this = this;
        console.log(ev.target.value);
        this.customerService.getCustomerById(ev.target.value).subscribe(function (res) {
            _this.customerDbObj = res;
            _this.appointment.customerId = res.id;
            console.log(res);
        }, function (err) {
            console.log(err);
        });
        this.customerString = '';
        delete this.customerList;
        this.presentModal();
    };
    SearchUpdateScheduleComponent.prototype.presentModal = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal, data;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _customer_appointment_customer_appointment_page__WEBPACK_IMPORTED_MODULE_6__["CustomerAppointmentPage"],
                            cssClass: 'my-custom-modal-css',
                            componentProps: {
                                customerName: this.customerDbObj, lastName: this.customerDbObj
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, modal.onDidDismiss()];
                    case 3:
                        data = (_a.sent()).data;
                        console.log(data);
                        /**
                         * Save the detail to server and update the Customer Appointment and referesh
                         */
                        this.appointment.expectedTime = data.appointmentDate;
                        this.appointment.typeOfAppointmentString = data.appointmentType;
                        this.appointment.visitingForDescription = data.description;
                        this.appointment.machineNo = Number(data.machineNo);
                        console.log(this.appointment);
                        this.dashboardService.addAppointment(this.appointment).subscribe(function (res) {
                            console.log(res);
                            _this.getEvent();
                            // this.dashboardService.change.emit(res);
                            //Flash serveice Message
                            _this.flashService.showGreen(res.error, 5000);
                        }, function (err) {
                            console.log(err);
                            _this.flashService.showRed(err.error.error, 8000);
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    SearchUpdateScheduleComponent.prototype.getEvent = function () {
        this.updateSchedule.emit();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"])(),
        __metadata("design:type", String)
    ], SearchUpdateScheduleComponent.prototype, "customerString", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"])
    ], SearchUpdateScheduleComponent.prototype, "updateSchedule", void 0);
    SearchUpdateScheduleComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-search-update-schedule',
            template: __webpack_require__(/*! ./search-update-schedule.component.html */ "./src/app/components/search-update-schedule/search-update-schedule.component.html"),
            styles: [__webpack_require__(/*! ./search-update-schedule.component.scss */ "./src/app/components/search-update-schedule/search-update-schedule.component.scss")]
        }),
        __metadata("design:paramtypes", [_services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__["CustomerService"],
            src_app_services_sales_sales_service__WEBPACK_IMPORTED_MODULE_5__["SalesService"],
            src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_2__["FlashMessageService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_0__["DashboardService"]])
    ], SearchUpdateScheduleComponent);
    return SearchUpdateScheduleComponent;
}());



/***/ }),

/***/ "./src/app/components/stock-details/stock-details.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/components/stock-details/stock-details.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-grid>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Stock ID</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.id}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Stock Name</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.stockName}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Stock Category</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.stockCategoryDomain.categoryName}} \n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>    Quantity of Stock Available</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.qtyOfStockAvailable}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b> Current Stock Rate</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.currentRateOfStock}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Current Stock Value</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.curentStockValue}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Added By</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\" wrap-text>\n            {{stockDetailsDb.lastUpdatedBy}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Stock Descitption</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.stockDescription}}\n        </ion-col>\n    </ion-row>\n</ion-grid>"

/***/ }),

/***/ "./src/app/components/stock-details/stock-details.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/components/stock-details/stock-details.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc3RvY2stZGV0YWlscy9zdG9jay1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/components/stock-details/stock-details.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/stock-details/stock-details.component.ts ***!
  \*********************************************************************/
/*! exports provided: StockDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsComponent", function() { return StockDetailsComponent; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var StockDetailsComponent = /** @class */ (function () {
    function StockDetailsComponent(activate) {
        this.activate = activate;
        this.stockDetailsDb = this.activate.snapshot.data['data'];
        this.purchaseForStock = this.activate.snapshot.data['stockSales'];
        console.log(this.stockDetailsDb);
        console.log(this.purchaseForStock);
    }
    StockDetailsComponent.prototype.ngOnInit = function () {
    };
    StockDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stock-details',
            template: __webpack_require__(/*! ./stock-details.component.html */ "./src/app/components/stock-details/stock-details.component.html"),
            styles: [__webpack_require__(/*! ./stock-details.component.scss */ "./src/app/components/stock-details/stock-details.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_0__["ActivatedRoute"]])
    ], StockDetailsComponent);
    return StockDetailsComponent;
}());



/***/ }),

/***/ "./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.html":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.html ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  stock-purchase-histroy works!\n</p>\n"

/***/ }),

/***/ "./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.scss":
/*!*****************************************************************************************!*\
  !*** ./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.scss ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc3RvY2stcHVyY2hhc2UtaGlzdHJveS9zdG9jay1wdXJjaGFzZS1oaXN0cm95LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.ts":
/*!***************************************************************************************!*\
  !*** ./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.ts ***!
  \***************************************************************************************/
/*! exports provided: StockPurchaseHistroyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockPurchaseHistroyComponent", function() { return StockPurchaseHistroyComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var StockPurchaseHistroyComponent = /** @class */ (function () {
    function StockPurchaseHistroyComponent() {
    }
    StockPurchaseHistroyComponent.prototype.ngOnInit = function () {
    };
    StockPurchaseHistroyComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-stock-purchase-histroy',
            template: __webpack_require__(/*! ./stock-purchase-histroy.component.html */ "./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.html"),
            styles: [__webpack_require__(/*! ./stock-purchase-histroy.component.scss */ "./src/app/components/stock-purchase-histroy/stock-purchase-histroy.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], StockPurchaseHistroyComponent);
    return StockPurchaseHistroyComponent;
}());



/***/ }),

/***/ "./src/app/components/stock-quantity/stock-quantity.module.ts":
/*!********************************************************************!*\
  !*** ./src/app/components/stock-quantity/stock-quantity.module.ts ***!
  \********************************************************************/
/*! exports provided: StockQuantityPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockQuantityPageModule", function() { return StockQuantityPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var _stock_quantity_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./stock-quantity.page */ "./src/app/components/stock-quantity/stock-quantity.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _stock_quantity_page__WEBPACK_IMPORTED_MODULE_5__["StockQuantityPage"]
    }
];
var StockQuantityPageModule = /** @class */ (function () {
    function StockQuantityPageModule() {
    }
    StockQuantityPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_stock_quantity_page__WEBPACK_IMPORTED_MODULE_5__["StockQuantityPage"]]
        })
    ], StockQuantityPageModule);
    return StockQuantityPageModule;
}());



/***/ }),

/***/ "./src/app/components/stock-quantity/stock-quantity.page.html":
/*!********************************************************************!*\
  !*** ./src/app/components/stock-quantity/stock-quantity.page.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-card>\r\n    <ion-card-header>\r\n        Add Quantity\r\n    </ion-card-header>\r\n    <ion-card-content>\r\n        <ion-grid>\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-item>\r\n                        <ion-label>Stock Name</ion-label>\r\n                        <ion-input type=\"text\" [(ngModel)]=\"stockName\" readonly value={{stockName}}>{{stockName}}</ion-input>\r\n                    </ion-item>\r\n                </ion-col>\r\n\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-item>\r\n                        <ion-label>Stock Quantity</ion-label>\r\n                        <ion-input type=\"number\" [(ngModel)]=\"stockQty\" value={{stockQty}}>{{stockQty}}</ion-input>\r\n\r\n                    </ion-item>\r\n                    <br>\r\n                    <div *ngIf=\"countExceed\">\r\n                        <ion-text color=\"danger\">\r\n                            <h1>\r\n                                Cannot add more than {{totalStck}} in cart</h1>\r\n                        </ion-text>\r\n\r\n                    </div>\r\n                </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-item>\r\n                        <ion-button shape=\"round\" size=\"default\" slot=\"end\" (click)=\"closeModel()\">Add</ion-button>\r\n                    </ion-item>\r\n                </ion-col>\r\n\r\n            </ion-row>\r\n        </ion-grid>\r\n    </ion-card-content>\r\n</ion-card>"

/***/ }),

/***/ "./src/app/components/stock-quantity/stock-quantity.page.scss":
/*!********************************************************************!*\
  !*** ./src/app/components/stock-quantity/stock-quantity.page.scss ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".my-custom-modal-css .modal-wrapper {\n  height: 20%;\n  top: 80%;\n  position: absolute;\n  display: block; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9zdG9jay1xdWFudGl0eS9DOlxcQmFzaWNzXFxDXFxwb2ludGVyc1xcc2Fhb2xoZWFydFVJL3NyY1xcYXBwXFxjb21wb25lbnRzXFxzdG9jay1xdWFudGl0eVxcc3RvY2stcXVhbnRpdHkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBVztFQUNYLFNBQVE7RUFDUixtQkFBa0I7RUFDbEIsZUFBYyxFQUNqQiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc3RvY2stcXVhbnRpdHkvc3RvY2stcXVhbnRpdHkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm15LWN1c3RvbS1tb2RhbC1jc3MgLm1vZGFsLXdyYXBwZXIge1xyXG4gICAgaGVpZ2h0OiAyMCU7XHJcbiAgICB0b3A6IDgwJTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/components/stock-quantity/stock-quantity.page.ts":
/*!******************************************************************!*\
  !*** ./src/app/components/stock-quantity/stock-quantity.page.ts ***!
  \******************************************************************/
/*! exports provided: StockQuantityPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockQuantityPage", function() { return StockQuantityPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var StockQuantityPage = /** @class */ (function () {
    function StockQuantityPage(navParams, modalCtrl) {
        this.modalCtrl = modalCtrl;
        this.countExceed = false;
    }
    StockQuantityPage.prototype.ngOnInit = function () {
    };
    StockQuantityPage.prototype.closeModel = function () {
        if (this.stockQty <= this.totalStck) {
            var dat = { stockName: this.stockName, stockQty: this.stockQty };
            this.modalCtrl.dismiss(dat);
        }
        else {
            this.countExceed = true;
        }
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], StockQuantityPage.prototype, "stockName", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Number)
    ], StockQuantityPage.prototype, "stockQty", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Number)
    ], StockQuantityPage.prototype, "totalStck", void 0);
    StockQuantityPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-stock-quantity',
            template: __webpack_require__(/*! ./stock-quantity.page.html */ "./src/app/components/stock-quantity/stock-quantity.page.html"),
            styles: [__webpack_require__(/*! ./stock-quantity.page.scss */ "./src/app/components/stock-quantity/stock-quantity.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavParams"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"]])
    ], StockQuantityPage);
    return StockQuantityPage;
}());



/***/ }),

/***/ "./src/app/components/stock-update-history/stock-update-history.component.html":
/*!*************************************************************************************!*\
  !*** ./src/app/components/stock-update-history/stock-update-history.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  stock-update-history works!\n</p>\n"

/***/ }),

/***/ "./src/app/components/stock-update-history/stock-update-history.component.scss":
/*!*************************************************************************************!*\
  !*** ./src/app/components/stock-update-history/stock-update-history.component.scss ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc3RvY2stdXBkYXRlLWhpc3Rvcnkvc3RvY2stdXBkYXRlLWhpc3RvcnkuY29tcG9uZW50LnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/components/stock-update-history/stock-update-history.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/components/stock-update-history/stock-update-history.component.ts ***!
  \***********************************************************************************/
/*! exports provided: StockUpdateHistoryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockUpdateHistoryComponent", function() { return StockUpdateHistoryComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var StockUpdateHistoryComponent = /** @class */ (function () {
    function StockUpdateHistoryComponent() {
    }
    StockUpdateHistoryComponent.prototype.ngOnInit = function () {
    };
    StockUpdateHistoryComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-stock-update-history',
            template: __webpack_require__(/*! ./stock-update-history.component.html */ "./src/app/components/stock-update-history/stock-update-history.component.html"),
            styles: [__webpack_require__(/*! ./stock-update-history.component.scss */ "./src/app/components/stock-update-history/stock-update-history.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], StockUpdateHistoryComponent);
    return StockUpdateHistoryComponent;
}());



/***/ }),

/***/ "./src/app/components/stock-update/stock-update.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/components/stock-update/stock-update.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-grid>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Stock ID</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.id}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Stock Name</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.stockName}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Stock Category</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.stockCategoryDomain.categoryName}} \n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>    Quantity of Stock Available</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.qtyOfStockAvailable}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b> Current Stock Rate</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.currentRateOfStock}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"3\">\n            <ion-label>\n                <ion-text color=\"dark\"><b>Current Stock Value</b></ion-text>\n            </ion-label>\n        </ion-col>\n        <ion-col size=\"3\">\n            {{stockDetailsDb.curentStockValue}}\n        </ion-col>\n    </ion-row>\n    <ion-row>\n             \n             <ion-col>\n               <ion-item>\n                 <ion-label position=\"floating\">Rate</ion-label>\n                 <ion-input name=\"currentRateOfStock\"  [value]=\"stockDetailsDb.currentRateOfStock\"\n                  (input)=\"setQuantity('currentRateOfStock',$event.target.value)\"></ion-input>\n               </ion-item>\n              \n             </ion-col>\n             <ion-col>\n               <ion-item>\n               <ion-label position=\"floating\">Quantity to be Updated</ion-label>\n               <ion-input  type=\"number\"  (input)=\"setQuantity('qtyOfStockToUpdate',$event.target.value)\"></ion-input>\n              </ion-item>\n             </ion-col>\n             <ion-col>\n                <ion-item>\n                <ion-label position=\"floating\">Reason For Update</ion-label>\n                <ion-textarea  type=\"text\"  (input)=\"setQuantity('reasonForUpdate',$event.target.value)\" ></ion-textarea>\n               </ion-item>\n              </ion-col>\n    </ion-row>\n    <ion-row>\n             <ion-col class=\"ion-float-right\">\n               <ion-button (click)=\"updateStock()\">Update</ion-button>\n             </ion-col>\n          \n    </ion-row>\n    </ion-grid>"

/***/ }),

/***/ "./src/app/components/stock-update/stock-update.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/stock-update/stock-update.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvc3RvY2stdXBkYXRlL3N0b2NrLXVwZGF0ZS5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/stock-update/stock-update.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/stock-update/stock-update.component.ts ***!
  \*******************************************************************/
/*! exports provided: StockUpdateComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockUpdateComponent", function() { return StockUpdateComponent; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_stock_stock_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/stock/stock.service */ "./src/app/services/stock/stock.service.ts");
/* harmony import */ var src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var StockUpdateComponent = /** @class */ (function () {
    function StockUpdateComponent(activate, stockService, flashservice) {
        this.activate = activate;
        this.stockService = stockService;
        this.flashservice = flashservice;
        this.stockView = {};
        this.stockDetailsDb = this.activate.snapshot.data['data'];
        this.purchaseForStock = this.activate.snapshot.data['stockSales'];
        console.log(this.stockDetailsDb);
        console.log(this.purchaseForStock);
        this.stockView.currentRateOfStock = this.stockDetailsDb.currentRateOfStock;
    }
    StockUpdateComponent.prototype.ngOnInit = function () {
    };
    StockUpdateComponent.prototype.setQuantity = function (prop, value) {
        this.stockView[prop] = value;
    };
    StockUpdateComponent.prototype.updateStock = function () {
        var _this = this;
        this.stockView.id = this.stockDetailsDb.id;
        console.log(this.stockView);
        this.stockService.updateStock(this.stockView).subscribe(function (res) {
            _this.stockDetailsDb = res.document;
            _this.activate.snapshot.data['data'] = res.document;
            _this.flashservice.showGreen(res.error, 5000);
        }, function (err) {
            _this.flashservice.showRed(err.error.error, 5000);
        });
    };
    StockUpdateComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stock-update',
            template: __webpack_require__(/*! ./stock-update.component.html */ "./src/app/components/stock-update/stock-update.component.html"),
            styles: [__webpack_require__(/*! ./stock-update.component.scss */ "./src/app/components/stock-update/stock-update.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_0__["ActivatedRoute"],
            src_app_services_stock_stock_service__WEBPACK_IMPORTED_MODULE_2__["StockService"],
            src_app_services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_3__["FlashMessageService"]])
    ], StockUpdateComponent);
    return StockUpdateComponent;
}());



/***/ }),

/***/ "./src/app/components/toolpop/toolpop.component.html":
/*!***********************************************************!*\
  !*** ./src/app/components/toolpop/toolpop.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-list>\n  <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\n    <ion-item (click)=\"closeModel(p.url)\">\n      <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\n      <ion-label>\n        {{p.title}}\n      </ion-label>\n    </ion-item>\n  </ion-menu-toggle>\n</ion-list>"

/***/ }),

/***/ "./src/app/components/toolpop/toolpop.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/components/toolpop/toolpop.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvdG9vbHBvcC90b29scG9wLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/components/toolpop/toolpop.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/components/toolpop/toolpop.component.ts ***!
  \*********************************************************/
/*! exports provided: ToolpopComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToolpopComponent", function() { return ToolpopComponent; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/index.js");
/* harmony import */ var src_app_services_userservice_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/userservice/user.service */ "./src/app/services/userservice/user.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ToolpopComponent = /** @class */ (function () {
    function ToolpopComponent(popoverController, route, userService) {
        this.popoverController = popoverController;
        this.route = route;
        this.userService = userService;
        this.appPages = [
            {
                title: 'Settings',
                url: '#',
                icon: 'settings'
            },
            {
                title: 'Logout',
                url: '/login',
                icon: 'log-out'
            }
        ];
    }
    ToolpopComponent.prototype.ngOnInit = function () { };
    ToolpopComponent.prototype.closeModel = function (str) {
        console.log(str);
        this.route.navigateByUrl(str);
        this.popoverController.dismiss();
    };
    ToolpopComponent.prototype.ngOnChanges = function () {
        alert(2);
    };
    ToolpopComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-toolpop',
            template: __webpack_require__(/*! ./toolpop.component.html */ "./src/app/components/toolpop/toolpop.component.html"),
            styles: [__webpack_require__(/*! ./toolpop.component.scss */ "./src/app/components/toolpop/toolpop.component.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_0__["Router"],
            src_app_services_userservice_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"]])
    ], ToolpopComponent);
    return ToolpopComponent;
}());



/***/ }),

/***/ "./src/app/components/treatment-invoice-details/treatment-invoice-details.component.html":
/*!***********************************************************************************************!*\
  !*** ./src/app/components/treatment-invoice-details/treatment-invoice-details.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"treatmentInvoiceForm\">\r\n    <ion-grid>\r\n        <ion-row>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Treatment Type</ion-label>\r\n                    <ion-select (ionChange)=\"updateDataValue($event,'treatmentTypeMasterId')\" interface=\"popover\" ngDefaultControl formControlName=\"treatmentTypeMasterId\" id=\"treatmentTypeMasterId\">\r\n                        <ion-select-option value=\"1\"> Natural Bypass Therapy(ECP)</ion-select-option>\r\n                        <ion-select-option value=\"2\"> Bio Chemical Angioplasty (BCA)</ion-select-option>\r\n                        <ion-select-option value=\"3\">Both ECP and BCA</ion-select-option>\r\n\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n\r\n        </ion-row>\r\n        <ion-row>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"stacked\">Date</ion-label>\r\n                    <!-- <ion-datetime id=\"treatmentInvoiceDate\" (ionChange)=\"updateDataValue($event,'treatmentInvoiceDate')\" name=\"treatmentInvoiceDate\" ngDefaultControl formControlName=\"treatmentInvoiceDate\"></ion-datetime> -->\r\n                    <input ion-input [owlDateTimeFilter]=\"myFilter\" [owlDateTime]=\"dt1\" id=\"consulatationDate\" (ionChange)=\"updateDataValue($event,'treatmentInvoiceDate')\" ngDefaultControl formControlName=\"treatmentInvoiceDate\"   [owlDateTimeTrigger]=\"dt1\" placeholder=\"Date Time\"/>\r\n                    <owl-date-time #dt1 hour12Timer=\"true\" stepHour=\"1\" pickerType=\"calendar\" stepMinute=\"30\"> </owl-date-time>\r\n            \r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Invoice Amount</ion-label>\r\n                    <ion-input type=\"number\" ngDefaultControl formControlName=\"invoiceTotalamt\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-button float-right type=\"submit\">Submit</ion-button>\r\n    <ion-button float-right type=\"reset\">Reset</ion-button>\r\n</form>\r\n\r\n<ion-item-divider class=\"divider\">\r\n</ion-item-divider>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>Treatment Details</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable no-padding class=\"material fullscreenManual\" [headerHeight]=\"50\" [scrollbarH]='true' \r\n            [limit]=\"5\" [columnMode]=\"'flexi'\" [footerHeight]=\"50\" [rowHeight]=\"'auto'\" [rows]=\"rowsTreatmentInvoice\">\r\n                <ngx-datatable-column name=\"Treatment Invoice Date\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\">\r\n                        {{value | date : 'MMM d, y' }}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Treatment Type\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        {{row.treatmentMaster.treatmentName}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Treatment Status\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{value}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"No Of Sitting/Hours\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.treatmentMaster.totalNoOfSittings}}/{{row.treatmentMaster.totalHours}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Ref No\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.invoiceDomain.id}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>Invoice Details</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable  [rowClass]=\"getRowClass\"  #myTable class='material fullscreenManual'\r\n             [columnMode]=\"'flexi'\" [headerHeight]=\"50\" [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"'auto'\"  [scrollbarH]=\"'true'\" [rows]='rowsInvoice' >\r\n                <ngx-datatable-column name=\"Invoice No\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.id}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Type\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.invoiceType.typeName}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Generated By\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.generatedBy.username}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n                <ngx-datatable-column name=\"Payment Mode\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-select *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" value=\"\" name=\"paymentMode\" (ionChange)=\"updateValueInvoice($event, 'paymentMode', rowIndex)\">\r\n                            <ion-select-option value=\"cheque\">Cheque</ion-select-option>\r\n                            <ion-select-option value=\"online\">Online</ion-select-option>\r\n                            <ion-select-option value=\"cash\">Cash</ion-select-option>\r\n                        </ion-select>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Bank Name\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" name=\"bankName\" autofocus (blur)=\"updateValueInvoice($event, 'bankName', rowIndex)\" type=\"text\">\r\n\r\n                        </ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Reference Number\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" autofocus (blur)=\"updateValueInvoice($event, 'referenceNumber', rowIndex)\" type=\"text\"></ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-input *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" autofocus (blur)=\"updateValueInvoice($event, 'paymentAmount', rowIndex)\" type=\"number\"></ion-input>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Total Invoice Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.totalInvoiceAmt}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Balance Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.balanceAmt}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Invoice Status\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n\r\n                        <ion-select  value=\"{{row.invoiceStatus}}\" [disabled]=\"row.invoiceStatus=='Payement Completed'\" name=\"invoiceStatus\" (ionChange)=\"updateValueInvoice($event, 'cancelInvoice', rowIndex)\">\r\n                            <ion-select-option value=\"Total Payment Pending\">Pending</ion-select-option>\r\n                            <ion-select-option value=\"Partially Pending\">Partial</ion-select-option>\r\n                            <ion-select-option value=\"Payement Conpleted\">Completed</ion-select-option>\r\n                            <ion-select-option value=\"Invoice Cancelled\">Cancel</ion-select-option>\r\n\r\n                        </ion-select>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column width=\"200\" name=\"Payment Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-button *ngIf=\"row.invoiceStatus=='Total Payment Pending' ||  row.invoiceStatus=='Partially Pending'\" size=\"small\" shape=\"round\" (click)=\"generateReciept($event, 'name', rowIndex, row)\" color=\"primary\">Generate Reciept</ion-button>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>\r\n<br>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>Payement Receipts</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable #myTable class='material fullscreenManual' [columnMode]=\"'flexi'\" [headerHeight]=\"50\" \r\n            [sortType]=\"'multi'\" [footerHeight]=\"50\" [rowHeight]=\"'auto'\"  [scrollbarH]=\"'true'\" [rows]='rowsPayment'>\r\n                <ngx-datatable-column name=\"Invoice No\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.invoiceId}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Recived By\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\" let-row=\"row\" let-rowIndex=\"rowIndex\">\r\n                        {{row.recievedBy}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Date\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.paymentDate | date : 'MMM d, y, h:mm:ss a' }}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Reference Number\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-row=\"row\" let-value=\"value\">\r\n                        <ion-text> {{row.paymentReferenceNo}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Mode\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-text> {{row.paymentMode}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Payment Amount\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        <ion-text> {{row.paymentAmount}}</ion-text>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n                <ngx-datatable-column width=\"200\" name=\"Print\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n\r\n                        <ion-button size=\"small\" shape=\"round\" (click)=\"printReciept($event, 'name', rowIndex, row)\" color=\"primary\">Print Reciept</ion-button>\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n\r\n\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n<br>"

/***/ }),

/***/ "./src/app/components/treatment-invoice-details/treatment-invoice-details.component.scss":
/*!***********************************************************************************************!*\
  !*** ./src/app/components/treatment-invoice-details/treatment-invoice-details.component.scss ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".divider {\n  border-bottom: 2px solid black !important; }\n\n.noLines {\n  border-bottom: 0px !important; }\n\n/* Structure */\n\nion-grid {\n  border: 1px solid black !important; }\n\n.fullscreenManual {\n  height: auto !important;\n  width: 95%; }\n\n:host /deep/ .datatable-row-group {\n  will-change: transform; }\n\n:host /deep/ .ngx-datatable.material .datatable-header .datatable-row-right {\n  margin-left: -8px; }\n\n:host /deep/ .row-color {\n  background-color: lightgreen; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy90cmVhdG1lbnQtaW52b2ljZS1kZXRhaWxzL0M6XFxCYXNpY3NcXENcXHBvaW50ZXJzXFxzYWFvbGhlYXJ0VUkvc3JjXFxhcHBcXGNvbXBvbmVudHNcXHRyZWF0bWVudC1pbnZvaWNlLWRldGFpbHNcXHRyZWF0bWVudC1pbnZvaWNlLWRldGFpbHMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQ0FBeUMsRUFDNUM7O0FBRUQ7RUFDSSw4QkFBNkIsRUFDaEM7O0FBR0QsZUFBZTs7QUFFZjtFQUNJLG1DQUFrQyxFQUNyQzs7QUFFRDtFQUNJLHdCQUF1QjtFQUN2QixXQUFVLEVBQ2I7O0FBRUQ7RUFDSSx1QkFBc0IsRUFDekI7O0FBRUE7RUFDRyxrQkFBaUIsRUFDcEI7O0FBRUQ7RUFDSSw2QkFBNEIsRUFDL0IiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL3RyZWF0bWVudC1pbnZvaWNlLWRldGFpbHMvdHJlYXRtZW50LWludm9pY2UtZGV0YWlscy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kaXZpZGVyIHtcclxuICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCBibGFjayAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubm9MaW5lcyB7XHJcbiAgICBib3JkZXItYm90dG9tOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuXHJcbi8qIFN0cnVjdHVyZSAqL1xyXG5cclxuaW9uLWdyaWQge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2sgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmZ1bGxzY3JlZW5NYW51YWwge1xyXG4gICAgaGVpZ2h0OiBhdXRvICFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogOTUlO1xyXG59XHJcblxyXG46aG9zdCAvZGVlcC8gLmRhdGF0YWJsZS1yb3ctZ3JvdXAge1xyXG4gICAgd2lsbC1jaGFuZ2U6IHRyYW5zZm9ybTtcclxufVxyXG5cclxuIDpob3N0IC9kZWVwLyAubmd4LWRhdGF0YWJsZS5tYXRlcmlhbCAuZGF0YXRhYmxlLWhlYWRlciAuZGF0YXRhYmxlLXJvdy1yaWdodCB7XHJcbiAgICBtYXJnaW4tbGVmdDogLThweDtcclxufVxyXG5cclxuOmhvc3QgL2RlZXAvIC5yb3ctY29sb3Ige1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmVlbjtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/treatment-invoice-details/treatment-invoice-details.component.ts":
/*!*********************************************************************************************!*\
  !*** ./src/app/components/treatment-invoice-details/treatment-invoice-details.component.ts ***!
  \*********************************************************************************************/
/*! exports provided: TreatmentInvoiceDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TreatmentInvoiceDetailsComponent", function() { return TreatmentInvoiceDetailsComponent; });
/* harmony import */ var _services_common_common_util_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/common/common-util.service */ "./src/app/services/common/common-util.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var TreatmentInvoiceDetailsComponent = /** @class */ (function () {
    function TreatmentInvoiceDetailsComponent(activate, fb, customerService, flashProvider, commonService) {
        var _this = this;
        this.activate = activate;
        this.fb = fb;
        this.customerService = customerService;
        this.flashProvider = flashProvider;
        this.commonService = commonService;
        /**
         * Ct Angio Row Details
         */
        this.editingTreatmentInvoice = {};
        this.rowsTreatmentInvoice = [];
        this.columnsTreatmentInvoice = [];
        /**
        * Invoice Consultation Row Details
        */
        this.editingInvoice = {};
        this.rowsInvoice = [];
        this.rowInvoiceFromDb = [];
        this.columnsInvoice = [];
        /**
        * Payment Consultation Row Details
        */
        this.editingPayment = {};
        this.rowsPayment = [];
        this.columnsPayment = [];
        this.getRowClass = function (row) {
            if (!(row.invoiceStatus === 'Total Payment Pending' || row.invoiceStatus === 'Partially Pending')) {
                return {
                    'row-color': true
                };
            }
            else {
                return {
                    'row-color': false
                };
            }
        };
        this.myFilter = function (d) {
            var day = d.getDay();
            // Prevent Saturday and Sunday from being selected.
            return day !== 0;
        };
        this.treatmentInvoiceFromDb = this.activate.snapshot.data['data'];
        this.invoiceMasterType = this.activate.snapshot.data['invoiceType'];
        console.log(this.invoiceMasterType);
        this.invoiceMasterType.forEach(function (element) {
            if (element.typeName === 'TREATMENT') {
                _this.invoiceTypeId = element.id;
            }
        });
        this.rowsTreatmentInvoice = this.treatmentInvoiceFromDb.treatmentPlanList;
        if (this.treatmentInvoiceFromDb.treatmentPlanList.length > 0) {
            this.columnsTreatmentInvoice = Object.keys(this.treatmentInvoiceFromDb.treatmentPlanList[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        this.updateInvoiceAndPaymentDomain(this.treatmentInvoiceFromDb.treatmentPlanList);
    }
    TreatmentInvoiceDetailsComponent.prototype.updateInvoiceAndPaymentDomain = function (obj) {
        var _this = this;
        obj.filter(function (ele) {
            _this.rowsInvoice.push(ele.invoiceDomain);
            _this.rowInvoiceFromDb.push(ele.invoiceDomain);
            ele.invoiceDomain.invoiceReciptList.filter(function (val) {
                _this.rowsPayment.push(val);
            });
            return ele.invoiceDomain;
        });
        if (this.rowsInvoice.length > 0) {
            this.columnsInvoice = Object.keys(this.rowsInvoice[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        if (this.rowsPayment.length > 0) {
            this.columnsInvoice = Object.keys(this.rowsPayment[0]).map(function (key) {
                return {
                    'prop': key
                };
            });
        }
        this.rowsInvoice = this.rowsInvoice.slice();
    };
    TreatmentInvoiceDetailsComponent.prototype.ngOnInit = function () {
        this.treatmentInvoiceForm = this.createForm({
            id: [],
            treatmentTypeMasterId: [],
            treatmentStatus: [],
            treatmentPlanDetailsList: [],
            customerId: [this.treatmentInvoiceFromDb.id],
            invoiceMasterTypeId: [this.invoiceTypeId],
            invoiceTotalamt: [],
            treatmentInvoiceDate: []
        });
    };
    TreatmentInvoiceDetailsComponent.prototype.createForm = function (model) {
        return this.fb.group(model);
    };
    TreatmentInvoiceDetailsComponent.prototype.onSubmit = function () {
        var _this = this;
        console.log(this.treatmentInvoiceForm.value);
        this.customerService.saveTreatmentInvoiceDetails(this.treatmentInvoiceForm.value).subscribe(function (res) {
            console.log(res);
            _this.rowsTreatmentInvoice.push(res.document);
            _this.rowsTreatmentInvoice = _this.rowsTreatmentInvoice.slice();
            var val = [];
            val.push(res.document);
            _this.updateInvoiceAndPaymentDomain(val);
            _this.flashProvider.showGreen(res.error, 4000);
        }, function (err) {
            console.log(err);
            _this.flashProvider.showRed(err.error, 4000);
        });
    };
    TreatmentInvoiceDetailsComponent.prototype.updateDataValue = function (eve, tar) {
        this.treatmentInvoiceForm.get(tar).setValue(eve.target.value);
    };
    TreatmentInvoiceDetailsComponent.prototype.updateValueInvoice = function (event, cell, rowIndex) {
        /**
         * Bug needs to be solved the Balance amount not getting reset to original DB amount when entered zero
         */
        if (cell === 'paymentAmount') {
            var balAmt = this.rowInvoiceFromDb[rowIndex]['balanceAmt'];
            console.log(balAmt);
            var newBalAmt = Number(balAmt) - Number(event.target.value);
            if (isNaN(newBalAmt)) {
            }
            else if (newBalAmt < 0) {
                this.flashProvider.showRed('Kindly Enter Amount Less than the balance amount', 5000);
                event.target.value = '';
                return;
            }
            else {
                this.rowsInvoice[rowIndex]['balanceAmt'] = newBalAmt;
                this.rowsInvoice = this.rowsInvoice.slice();
                console.log(this.rowsInvoice);
            }
        }
        this.editingInvoice[rowIndex + '-' + cell] = false;
        this.rowsInvoice[rowIndex][cell] = event.target.value;
    };
    TreatmentInvoiceDetailsComponent.prototype.updateValuePayment = function (event, cell, rowIndex) {
        this.editingPayment[rowIndex + '-' + cell] = false;
        this.rowsPayment[rowIndex][cell] = event.target.value;
    };
    TreatmentInvoiceDetailsComponent.prototype.printReciept = function (event, cell, rowIndex, row) {
        var _this = this;
        this.customerService.printRecipt(row).subscribe(function (res) {
            var filename = 'in.pdf';
            console.log(res);
            _this.commonService.saveFile(res, filename);
        }, function (errr) {
            console.log(errr);
        });
    };
    TreatmentInvoiceDetailsComponent.prototype.generateReciept = function (event, cell, rowIndex, row) {
        var _this = this;
        console.log(row);
        this.customerService.generateReciept(row).subscribe(function (res) {
            console.log(res);
            _this.updateSingleInvoiceDomainAndAllPaymentList(res.document);
            _this.flashProvider.showGreen(res.error, 5000);
        }, function (err) {
            console.log(err);
            _this.flashProvider.showRed(err.error, 5000);
        });
    };
    TreatmentInvoiceDetailsComponent.prototype.updateSingleInvoiceDomainAndAllPaymentList = function (list) {
        var _this = this;
        this.rowsPayment = [];
        list.invoiceReciptList.filter(function (val) {
            _this.rowsPayment.push(val);
        });
        this.rowsPayment = this.rowsPayment.slice();
        var ind;
        this.rowsInvoice.forEach(function (ele, index) {
            if (ele.id === list.id) {
                ind = index;
            }
        });
        if (ind != null) {
            this.rowsInvoice[ind] = list;
            this.rowsInvoice = this.rowsInvoice.slice();
        }
    };
    TreatmentInvoiceDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-treatment-invoice-details',
            template: __webpack_require__(/*! ./treatment-invoice-details.component.html */ "./src/app/components/treatment-invoice-details/treatment-invoice-details.component.html"),
            styles: [__webpack_require__(/*! ./treatment-invoice-details.component.scss */ "./src/app/components/treatment-invoice-details/treatment-invoice-details.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"],
            _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_3__["CustomerService"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_2__["FlashMessageService"],
            _services_common_common_util_service__WEBPACK_IMPORTED_MODULE_0__["CommonUtilService"]])
    ], TreatmentInvoiceDetailsComponent);
    return TreatmentInvoiceDetailsComponent;
}());



/***/ }),

/***/ "./src/app/components/treatment-plan-detail/treatment-plan-detail.component.html":
/*!***************************************************************************************!*\
  !*** ./src/app/components/treatment-plan-detail/treatment-plan-detail.component.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <form (ngSubmit)=\"onSubmit()\" [formGroup]=\"treatmentPlanForm\">\r\n    <ion-grid>\r\n        <ion-row>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Treatment Type</ion-label>\r\n                    <ion-select (ionChange)=\"updateDataValue($event,'treatmentPlanId')\" ngDefaultControl formControlName=\"treatmentPlanId\" id=\"treatmentPlanId\">\r\n                        <ion-select-option value=\"\"></ion-select-option>\r\n                        <ion-select-option *ngFor=\"let treat of treatMentOptionList\" value=\"{{treat.value}}\">{{treat.text}}</ion-select-option>\r\n                    </ion-select>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row *ngIf=\"treatMentOptionList.length > 0\">\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Date</ion-label>\r\n                    <ion-datetime id=\"treatmentDate\" (ionChange)=\"updateDataValue($event,'treatmentDate')\" name=\"treatmentDate\" ngDefaultControl formControlName=\"treatmentDate\"></ion-datetime>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-col>\r\n                    <ion-item>\r\n                        <ion-label position=\"floating\">Duration</ion-label>\r\n                        <ion-input type=\"number\" ngDefaultControl max=\"60\" formControlName=\"duration\"></ion-input>\r\n                    </ion-item>\r\n                </ion-col>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row *ngIf=\"treatMentOptionList.length > 0\">\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Beggining B.P.</ion-label>\r\n                    <ion-input type=\"number\" ngDefaultControl formControlName=\"begBp\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Beggining H.P.</ion-label>\r\n                    <ion-input type=\"number\" ngDefaultControl formControlName=\"begHp\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row *ngIf=\"treatMentOptionList.length > 0\">\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">End B.P.</ion-label>\r\n                    <ion-input type=\"number\" ngDefaultControl formControlName=\"endBp\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n            <ion-col>\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">End H.P.</ion-label>\r\n                    <ion-input type=\"number\" ngDefaultControl formControlName=\"endHp\"></ion-input>\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n        <ion-row *ngIf=\"treatMentOptionList.length > 0\">\r\n            <ion-col size=\"8\">\r\n                <ion-item>\r\n                    <ion-label position=\"floating\">Complaints</ion-label>\r\n                    <ion-textarea id=\"complaints\" ngDefaultControl formControlName=\"complaints\" rows=\"2\" type=\"text\">\r\n                    </ion-textarea>\r\n\r\n\r\n                </ion-item>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-button *ngIf=\"treatMentOptionList.length > 0\" float-right type=\"submit\">Submit</ion-button>\r\n    <ion-button *ngIf=\"treatMentOptionList.length > 0\" float-right type=\"reset\">Reset</ion-button>\r\n</form> -->\r\n<!-- \r\n<ion-item-divider class=\"divider\">\r\n</ion-item-divider>\r\n<br> -->\r\n<ion-item>\r\n    <ion-label position=\"floating\">Select Invoice Ref</ion-label>\r\n    <ion-select (ionChange)=\"changeTreatmentPlanTable($event)\" interface=\"popover\" ngDefaultControl  id=\"treatmentPlanId\">\r\n        <ion-select-option *ngFor=\"let treat of treatMentOptionList\" value=\"{{treat.value}}\">{{treat.text}}</ion-select-option>\r\n    </ion-select>\r\n</ion-item>\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>ECP Treatment Plan Details History</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable no-padding class=\"material fullscreenManual\"\r\n             [headerHeight]=\"50\" [scrollbarH]='true' [limit]=\"5\" [columnMode]=\"'flexi'\" \r\n             [footerHeight]=\"50\" [rowHeight]=\"'auto'\" [rows]=\"rowsTreatmentDetail\">\r\n                <ngx-datatable-column name=\"Treatment Date\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\">\r\n                        {{value | date : 'MMM d, y, h:mm:ss a' }}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Duration\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.duration |  slice:2}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Visit Status\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.isTreatmentDone}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Complaints\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.complaints}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n\r\n<ion-grid>\r\n    <ion-row class=\"divider\">\r\n        <ion-col>\r\n            <ion-note color=\"primary\"><b><u><h2>BCA Treatment Plan Details History</h2></u></b></ion-note>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row>\r\n        <ion-col no-padding>\r\n            <ngx-datatable no-padding class=\"material fullscreenManual\"\r\n             [headerHeight]=\"50\" [scrollbarH]='true' [limit]=\"5\" [columnMode]=\"'flexi'\" \r\n             [footerHeight]=\"50\" [rowHeight]=\"'auto'\" [rows]=\"rowsTreatmentDetailBca\">\r\n                <ngx-datatable-column name=\"Treatment Date\">\r\n                    <ng-template ngx-datatable-cell-template let-value=\"value\">\r\n                        {{value | date : 'MMM d, y, h:mm:ss a' }}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n       \r\n                <ngx-datatable-column name=\"Visit Status\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.isTreatmentDone}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n                <ngx-datatable-column name=\"Complaints\">\r\n                    <ng-template ngx-datatable-cell-template let-rowIndex=\"rowIndex\" let-value=\"value\" let-row=\"row\">\r\n                        {{row.complaints}}\r\n                    </ng-template>\r\n                </ngx-datatable-column>\r\n            </ngx-datatable>\r\n\r\n\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>"

/***/ }),

/***/ "./src/app/components/treatment-plan-detail/treatment-plan-detail.component.scss":
/*!***************************************************************************************!*\
  !*** ./src/app/components/treatment-plan-detail/treatment-plan-detail.component.scss ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".divider {\n  border-bottom: 2px solid black !important; }\n\n.noLines {\n  border-bottom: 0px !important; }\n\n/* Structure */\n\nion-grid {\n  border: 1px solid black !important; }\n\n.fullscreenManual {\n  height: auto !important;\n  width: 95%; }\n\n:host /deep/ .datatable-row-group {\n  will-change: transform; }\n\n:host /deep/ .ngx-datatable.material .datatable-header .datatable-row-right {\n  margin-left: -8px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy90cmVhdG1lbnQtcGxhbi1kZXRhaWwvQzpcXEJhc2ljc1xcQ1xccG9pbnRlcnNcXHNhYW9saGVhcnRVSS9zcmNcXGFwcFxcY29tcG9uZW50c1xcdHJlYXRtZW50LXBsYW4tZGV0YWlsXFx0cmVhdG1lbnQtcGxhbi1kZXRhaWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQ0FBeUMsRUFDNUM7O0FBRUQ7RUFDSSw4QkFBNkIsRUFDaEM7O0FBR0QsZUFBZTs7QUFFZjtFQUNJLG1DQUFrQyxFQUNyQzs7QUFFRDtFQUNJLHdCQUF1QjtFQUN2QixXQUFVLEVBQ2I7O0FBRUQ7RUFDSSx1QkFBc0IsRUFDekI7O0FBRUE7RUFDRyxrQkFBaUIsRUFDcEIiLCJmaWxlIjoic3JjL2FwcC9jb21wb25lbnRzL3RyZWF0bWVudC1wbGFuLWRldGFpbC90cmVhdG1lbnQtcGxhbi1kZXRhaWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZGl2aWRlciB7XHJcbiAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgYmxhY2sgIWltcG9ydGFudDtcclxufVxyXG5cclxuLm5vTGluZXMge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcblxyXG4vKiBTdHJ1Y3R1cmUgKi9cclxuXHJcbmlvbi1ncmlkIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5mdWxsc2NyZWVuTWFudWFsIHtcclxuICAgIGhlaWdodDogYXV0byAhaW1wb3J0YW50O1xyXG4gICAgd2lkdGg6IDk1JTtcclxufVxyXG5cclxuOmhvc3QgL2RlZXAvIC5kYXRhdGFibGUtcm93LWdyb3VwIHtcclxuICAgIHdpbGwtY2hhbmdlOiB0cmFuc2Zvcm07XHJcbn1cclxuXHJcbiA6aG9zdCAvZGVlcC8gLm5neC1kYXRhdGFibGUubWF0ZXJpYWwgLmRhdGF0YWJsZS1oZWFkZXIgLmRhdGF0YWJsZS1yb3ctcmlnaHQge1xyXG4gICAgbWFyZ2luLWxlZnQ6IC04cHg7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/components/treatment-plan-detail/treatment-plan-detail.component.ts":
/*!*************************************************************************************!*\
  !*** ./src/app/components/treatment-plan-detail/treatment-plan-detail.component.ts ***!
  \*************************************************************************************/
/*! exports provided: TreatmentPlanDetailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TreatmentPlanDetailComponent", function() { return TreatmentPlanDetailComponent; });
/* harmony import */ var _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../services/flash/flash-message.service */ "./src/app/services/flash/flash-message.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../services/customer/customer.service */ "./src/app/services/customer/customer.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var TreatmentPlanDetailComponent = /** @class */ (function () {
    function TreatmentPlanDetailComponent(activate, fb, customerService, flashProvider) {
        var _this = this;
        this.activate = activate;
        this.fb = fb;
        this.customerService = customerService;
        this.flashProvider = flashProvider;
        this.treatMentOptionList = [{}];
        /**
           * Ct Angio Row Details
           */
        this.editingTreatmentDetail = {};
        this.rowsTreatmentDetail = [];
        this.columnsTreatmentDetail = [];
        this.rowsTreatmentDetailBca = [];
        this.treatmentPlanFromDb = this.activate.snapshot.data['data'];
        this.invoiceMasterType = this.activate.snapshot.data['invoiceType'];
        console.log(this.treatmentPlanFromDb.treatmentPlanList);
        if (this.treatmentPlanFromDb.treatmentPlanList.length > 0) {
            this.treatMentOptionList = [];
            this.treatmentPlanFromDb.treatmentPlanList.forEach(function (element, k) {
                _this.treatMentOptionList.push({ text: element.treatmentMaster.treatmentName + '- Inv Ref No :- ' + element.invoiceDomain.id,
                    value: element.id });
            });
        }
        console.log(this.rowsTreatmentDetail);
        if (this.treatmentPlanFromDb.treatmentPlanList.length > 0
            && this.treatmentPlanFromDb.treatmentPlanList[0].treatmentPlanDetailsList.length > 0) {
            this.columnsTreatmentDetail =
                Object.keys(this.treatmentPlanFromDb.treatmentPlanList[0].treatmentPlanDetailsList[0])
                    .map(function (key) {
                    return {
                        'prop': key
                    };
                });
        }
    }
    TreatmentPlanDetailComponent.prototype.changeTreatmentPlanTable = function (event) {
        var _this = this;
        this.treatmentPlanFromDb.treatmentPlanList.forEach(function (element, k) {
            if (element.treatmentPlanDetailsList.length > 0) {
                if (Number(event.target.value) === Number(element.id)) {
                    console.log(element.id);
                    element.treatmentPlanDetailsList.forEach(function (childEle) {
                        if (childEle.treatmentType === 'Treatment ECP') {
                            _this.rowsTreatmentDetail.push(childEle);
                        }
                        else {
                            _this.rowsTreatmentDetailBca.push(childEle);
                        }
                    });
                    _this.rowsTreatmentDetailBca = _this.rowsTreatmentDetailBca.slice();
                    _this.rowsTreatmentDetail = _this.rowsTreatmentDetail.slice();
                }
            }
        });
    };
    TreatmentPlanDetailComponent.prototype.ngOnInit = function () {
    };
    TreatmentPlanDetailComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
            selector: 'app-treatment-plan-detail',
            template: __webpack_require__(/*! ./treatment-plan-detail.component.html */ "./src/app/components/treatment-plan-detail/treatment-plan-detail.component.html"),
            styles: [__webpack_require__(/*! ./treatment-plan-detail.component.scss */ "./src/app/components/treatment-plan-detail/treatment-plan-detail.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
            _services_customer_customer_service__WEBPACK_IMPORTED_MODULE_2__["CustomerService"],
            _services_flash_flash_message_service__WEBPACK_IMPORTED_MODULE_0__["FlashMessageService"]])
    ], TreatmentPlanDetailComponent);
    return TreatmentPlanDetailComponent;
}());



/***/ }),

/***/ "./src/app/pipes/aadhar/aadhar-tranform.pipe.ts":
/*!******************************************************!*\
  !*** ./src/app/pipes/aadhar/aadhar-tranform.pipe.ts ***!
  \******************************************************/
/*! exports provided: AadharTranformPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AadharTranformPipe", function() { return AadharTranformPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AadharTranformPipe = /** @class */ (function () {
    function AadharTranformPipe() {
    }
    AadharTranformPipe.prototype.transform = function (value, args) {
        var theVal = value;
        if (value !== null) {
            var len = value.length;
            var theLoop = Number(len % 4);
            if (len === 4) {
                theVal = value + '-';
            }
            else if (len > 4 && len === 9) {
                theVal = value + '-';
            }
            else if (len > 9 && len === 14) {
            }
        }
        return theVal;
    };
    AadharTranformPipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'aadharTranform'
        })
    ], AadharTranformPipe);
    return AadharTranformPipe;
}());



/***/ }),

/***/ "./src/app/pipes/pipes.module.ts":
/*!***************************************!*\
  !*** ./src/app/pipes/pipes.module.ts ***!
  \***************************************/
/*! exports provided: PipesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PipesModule", function() { return PipesModule; });
/* harmony import */ var _aadhar_aadhar_tranform_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./aadhar/aadhar-tranform.pipe */ "./src/app/pipes/aadhar/aadhar-tranform.pipe.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var PipesModule = /** @class */ (function () {
    function PipesModule() {
    }
    PipesModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_aadhar_aadhar_tranform_pipe__WEBPACK_IMPORTED_MODULE_0__["AadharTranformPipe"]],
            imports: [],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
            exports: [_aadhar_aadhar_tranform_pipe__WEBPACK_IMPORTED_MODULE_0__["AadharTranformPipe"]],
            providers: []
        })
    ], PipesModule);
    return PipesModule;
}());



/***/ }),

/***/ "./src/app/services/common/common-util.service.ts":
/*!********************************************************!*\
  !*** ./src/app/services/common/common-util.service.ts ***!
  \********************************************************/
/*! exports provided: CommonUtilService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonUtilService", function() { return CommonUtilService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var CommonUtilService = /** @class */ (function () {
    function CommonUtilService() {
    }
    CommonUtilService.prototype.saveFile = function (data, filename) {
        console.log(data);
        var file = new Blob([data], { type: 'application/pdf' });
        var fileURL = URL.createObjectURL(file);
        window.open(fileURL);
    };
    CommonUtilService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], CommonUtilService);
    return CommonUtilService;
}());



/***/ }),

/***/ "./src/app/services/constants/auth-constants.service.ts":
/*!**************************************************************!*\
  !*** ./src/app/services/constants/auth-constants.service.ts ***!
  \**************************************************************/
/*! exports provided: AuthConstantsService, TOKEN_AUTH_USERNAME, TOKEN_AUTH_PASSWORD, TOKEN_NAME */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthConstantsService", function() { return AuthConstantsService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOKEN_AUTH_USERNAME", function() { return TOKEN_AUTH_USERNAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOKEN_AUTH_PASSWORD", function() { return TOKEN_AUTH_PASSWORD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOKEN_NAME", function() { return TOKEN_NAME; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var AuthConstantsService = /** @class */ (function () {
    function AuthConstantsService() {
    }
    AuthConstantsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], AuthConstantsService);
    return AuthConstantsService;
}());

var TOKEN_AUTH_USERNAME = 'devglan-client';
var TOKEN_AUTH_PASSWORD = 'devglan-secret';
var TOKEN_NAME = 'access_token';


/***/ }),

/***/ "./src/app/services/customer/customer.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/services/customer/customer.service.ts ***!
  \*******************************************************/
/*! exports provided: CustomerService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerService", function() { return CustomerService; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var CustomerService = /** @class */ (function () {
    function CustomerService(http) {
        this.http = http;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        };
    }
    CustomerService.prototype.saveCustomer = function (cust) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/addcustomer', cust, this.httpOptions);
    };
    CustomerService.prototype.getAllCustomerSortedList = function () {
        console.log(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl);
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/getAllCustomersList', this.httpOptions);
    };
    CustomerService.prototype.getCustomerById = function (id) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/detail/' + id, this.httpOptions);
    };
    CustomerService.prototype.saveDoctorDetails = function (doct) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/savedoctordetails', doct, this.httpOptions);
    };
    CustomerService.prototype.generateReciept = function (invoice) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/generatereciept', invoice, this.httpOptions);
    };
    CustomerService.prototype.printRecipt = function (invo) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/printreciept', invo, { responseType: 'blob' });
    };
    CustomerService.prototype.saveCtAngioDetails = function (doct) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/savectangiodetails', doct, this.httpOptions);
    };
    CustomerService.prototype.saveTreatmentInvoiceDetails = function (doct) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/savetreatmentdetails', doct, this.httpOptions);
    };
    CustomerService.prototype.saveTreatmentPlanDetails = function (doct) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/savetreatmentplandetails', doct, this.httpOptions);
    };
    CustomerService.prototype.getCustomerListByNameOrMobile = function (par) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpParams"]().set('searchParam', par);
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/getcustomerbysearch', { params: params });
    };
    CustomerService.prototype.cancelAndCreateNewInvoice = function (ele) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/cancelInvoice', ele, this.httpOptions);
    };
    CustomerService.prototype.getcustomeralltreatment = function (id) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/getcustomeralltreatment/' + id, this.httpOptions);
    };
    CustomerService.prototype.printMou = function (num) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'customer/printmou?ctConsultationId=' + num, { responseType: 'blob' });
    };
    CustomerService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]])
    ], CustomerService);
    return CustomerService;
}());



/***/ }),

/***/ "./src/app/services/dashboard/dasboard-resolve.service.ts":
/*!****************************************************************!*\
  !*** ./src/app/services/dashboard/dasboard-resolve.service.ts ***!
  \****************************************************************/
/*! exports provided: DasboardResolveService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DasboardResolveService", function() { return DasboardResolveService; });
/* harmony import */ var src_app_services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/dashboard/dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DasboardResolveService = /** @class */ (function () {
    function DasboardResolveService(dashBoard) {
        this.dashBoard = dashBoard;
    }
    DasboardResolveService.prototype.resolve = function (route, state) {
        var id = route.paramMap.get('id');
        return this.dashBoard.getInHouseAppointmentList();
    };
    DasboardResolveService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [src_app_services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_0__["DashboardService"]])
    ], DasboardResolveService);
    return DasboardResolveService;
}());



/***/ }),

/***/ "./src/app/services/dashboard/dashboard-bcadata-resolve.service.ts":
/*!*************************************************************************!*\
  !*** ./src/app/services/dashboard/dashboard-bcadata-resolve.service.ts ***!
  \*************************************************************************/
/*! exports provided: DashboardBCADataResolveService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardBCADataResolveService", function() { return DashboardBCADataResolveService; });
/* harmony import */ var _dashboard_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DashboardBCADataResolveService = /** @class */ (function () {
    function DashboardBCADataResolveService(dashBoard) {
        this.dashBoard = dashBoard;
    }
    DashboardBCADataResolveService.prototype.resolve = function (route, state) {
        var id = route.paramMap.get('id');
        return this.dashBoard.getPateintsQueueList();
    };
    DashboardBCADataResolveService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_dashboard_service__WEBPACK_IMPORTED_MODULE_0__["DashboardService"]])
    ], DashboardBCADataResolveService);
    return DashboardBCADataResolveService;
}());



/***/ }),

/***/ "./src/app/services/dashboard/dashboard-low-stock-resolve.service.ts":
/*!***************************************************************************!*\
  !*** ./src/app/services/dashboard/dashboard-low-stock-resolve.service.ts ***!
  \***************************************************************************/
/*! exports provided: DashboardLowStockResolveService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardLowStockResolveService", function() { return DashboardLowStockResolveService; });
/* harmony import */ var _dashboard_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DashboardLowStockResolveService = /** @class */ (function () {
    function DashboardLowStockResolveService(dashBoard) {
        this.dashBoard = dashBoard;
    }
    DashboardLowStockResolveService.prototype.resolve = function (route, state) {
        return this.dashBoard.getLowStockList();
    };
    DashboardLowStockResolveService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_dashboard_service__WEBPACK_IMPORTED_MODULE_0__["DashboardService"]])
    ], DashboardLowStockResolveService);
    return DashboardLowStockResolveService;
}());



/***/ }),

/***/ "./src/app/services/dashboard/dashboard-pending-payment-resolve.service.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/services/dashboard/dashboard-pending-payment-resolve.service.ts ***!
  \*********************************************************************************/
/*! exports provided: DashboardPendingPaymentResolveService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardPendingPaymentResolveService", function() { return DashboardPendingPaymentResolveService; });
/* harmony import */ var src_app_services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/dashboard/dashboard.service */ "./src/app/services/dashboard/dashboard.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var DashboardPendingPaymentResolveService = /** @class */ (function () {
    function DashboardPendingPaymentResolveService(dashBoard) {
        this.dashBoard = dashBoard;
    }
    DashboardPendingPaymentResolveService.prototype.resolve = function (route, state) {
        var id = route.paramMap.get('id');
        return this.dashBoard.getPaymentPendingList();
    };
    DashboardPendingPaymentResolveService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [src_app_services_dashboard_dashboard_service__WEBPACK_IMPORTED_MODULE_0__["DashboardService"]])
    ], DashboardPendingPaymentResolveService);
    return DashboardPendingPaymentResolveService;
}());



/***/ }),

/***/ "./src/app/services/dashboard/dashboard.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/services/dashboard/dashboard.service.ts ***!
  \*********************************************************/
/*! exports provided: DashboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardService", function() { return DashboardService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var DashboardService = /** @class */ (function () {
    function DashboardService(http) {
        this.http = http;
        this.isMenuOpen = new rxjs__WEBPACK_IMPORTED_MODULE_0__["BehaviorSubject"](true);
        this.navItem$ = this.isMenuOpen.asObservable();
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        };
        this.isOpen = false;
        this.change = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.callModalEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
    }
    DashboardService.prototype.addAppointment = function (cust) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/scheduleappointment', cust, this.httpOptions);
    };
    DashboardService.prototype.getPateintsQueueList = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/getpateintqueuelist', this.httpOptions);
    };
    DashboardService.prototype.updateTreatmentSchedule = function (res) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/updateandcompleteschedule', res, this.httpOptions);
    };
    DashboardService.prototype.getInHouseAppointmentList = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/getinhouseappointments', this.httpOptions);
    };
    DashboardService.prototype.getNewJoineeList = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/getnewjoinee', this.httpOptions);
    };
    DashboardService.prototype.markPatientAppointment = function (res) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/markappointment', res, this.httpOptions);
    };
    DashboardService.prototype.getPaymentPendingList = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/getpaymentpending', this.httpOptions);
    };
    DashboardService.prototype.changeScheduling = function (res) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/changescehduling', res, this.httpOptions);
    };
    DashboardService.prototype.emitMenuToggle = function (res) {
        console.log(res);
        this.isMenuOpen.next(res);
    };
    DashboardService.prototype.getMessage = function () {
        return this.isMenuOpen.asObservable();
    };
    DashboardService.prototype.getAppointmentForDate = function (res) {
        var param = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpParams"]().set('reqDate', res);
        console.log(param);
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/getappointmentbydate', { params: param });
    };
    DashboardService.prototype.getAllAppointment = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/getalldoctorappointment');
    };
    DashboardService.prototype.getLowStockList = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiUrl + 'dashboard/getlowstocks?limit=' + 10);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"])
    ], DashboardService.prototype, "change", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
        __metadata("design:type", Object)
    ], DashboardService.prototype, "callModalEvent", void 0);
    DashboardService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], DashboardService);
    return DashboardService;
}());



/***/ }),

/***/ "./src/app/services/flash/flash-message.service.ts":
/*!*********************************************************!*\
  !*** ./src/app/services/flash/flash-message.service.ts ***!
  \*********************************************************/
/*! exports provided: FlashMessageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FlashMessageService", function() { return FlashMessageService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FlashMessageService = /** @class */ (function () {
    function FlashMessageService() {
    }
    // show(mess, duration) {
    // }
    FlashMessageService.prototype.showGreen = function (message, duration) {
    };
    FlashMessageService.prototype.showRed = function (message, duration) {
    };
    FlashMessageService.prototype.hide = function () {
    };
    FlashMessageService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], FlashMessageService);
    return FlashMessageService;
}());



/***/ }),

/***/ "./src/app/services/guard/auth.guard.ts":
/*!**********************************************!*\
  !*** ./src/app/services/guard/auth.guard.ts ***!
  \**********************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @auth0/angular-jwt */ "./node_modules/@auth0/angular-jwt/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _userservice_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../userservice/user.service */ "./src/app/services/userservice/user.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AuthGuard = /** @class */ (function () {
    function AuthGuard(router, userService, jwtHelp) {
        this.router = router;
        this.userService = userService;
        this.jwtHelp = jwtHelp;
    }
    AuthGuard.prototype.canActivate = function (next, state) {
        console.log(this.jwtHelp.isTokenExpired(this.userService.getAccessToken()));
        if (!this.jwtHelp.isTokenExpired(this.userService.getAccessToken())) {
            return true;
        }
        else {
            this.router.navigate(['login']);
            return false;
        }
    };
    AuthGuard = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _userservice_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"], _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_0__["JwtHelperService"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ "./src/app/services/loader/loader-interceptor.service.ts":
/*!***************************************************************!*\
  !*** ./src/app/services/loader/loader-interceptor.service.ts ***!
  \***************************************************************/
/*! exports provided: LoaderInterceptorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoaderInterceptorService", function() { return LoaderInterceptorService; });
/* harmony import */ var _loader_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./loader.service */ "./src/app/services/loader/loader.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LoaderInterceptorService = /** @class */ (function () {
    function LoaderInterceptorService(loaderService) {
        this.loaderService = loaderService;
    }
    LoaderInterceptorService.prototype.intercept = function (req, next) {
        var _this = this;
        this.showLoader();
        return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (event) {
            if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpResponse"]) {
                _this.onEnd();
            }
        }, function (err) {
            _this.onEnd();
        }));
    };
    LoaderInterceptorService.prototype.onEnd = function () {
        this.hideLoader();
    };
    LoaderInterceptorService.prototype.showLoader = function () {
        this.loaderService.show();
    };
    LoaderInterceptorService.prototype.hideLoader = function () {
        this.loaderService.hide();
    };
    LoaderInterceptorService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_loader_service__WEBPACK_IMPORTED_MODULE_0__["LoaderService"]])
    ], LoaderInterceptorService);
    return LoaderInterceptorService;
}());



/***/ }),

/***/ "./src/app/services/loader/loader.service.ts":
/*!***************************************************!*\
  !*** ./src/app/services/loader/loader.service.ts ***!
  \***************************************************/
/*! exports provided: LoaderService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoaderService", function() { return LoaderService; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var LoaderService = /** @class */ (function () {
    function LoaderService() {
        this.loaderSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__["Subject"]();
        this.loaderState = this.loaderSubject.asObservable();
    }
    LoaderService.prototype.show = function () {
        this.loaderSubject.next({ show: true });
    };
    LoaderService.prototype.hide = function () {
        this.loaderSubject.next({ show: false });
    };
    LoaderService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], LoaderService);
    return LoaderService;
}());



/***/ }),

/***/ "./src/app/services/sales/sales.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/sales/sales.service.ts ***!
  \*************************************************/
/*! exports provided: SalesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesService", function() { return SalesService; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var SalesService = /** @class */ (function () {
    function SalesService(http) {
        this.http = http;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        };
    }
    SalesService.prototype.saveStock = function (cust) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'sales/savesales', cust, this.httpOptions);
    };
    SalesService.prototype.getAllSalesList = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'sales/getallsales');
    };
    SalesService.prototype.getSalesDetailById = function (res) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'sales/findsalesbyid/' + res);
    };
    SalesService.prototype.updateSales = function (res) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'sales/updatesales', res, this.httpOptions);
    };
    SalesService.prototype.printSalesRecipt = function (res) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'sales/printrecipt', res, { responseType: 'blob' });
    };
    SalesService.prototype.emailReciept = function (res) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'sales/emailreciept', res, this.httpOptions);
    };
    SalesService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]])
    ], SalesService);
    return SalesService;
}());



/***/ }),

/***/ "./src/app/services/stock/stock.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/stock/stock.service.ts ***!
  \*************************************************/
/*! exports provided: StockService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockService", function() { return StockService; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var StockService = /** @class */ (function () {
    function StockService(http) {
        this.http = http;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({
                'Content-Type': 'application/json',
            })
        };
    }
    StockService.prototype.saveStock = function (cust) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'stock/addstock', cust, this.httpOptions);
    };
    StockService.prototype.getAllStockCategory = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'stock/getStockCategory', this.httpOptions);
    };
    StockService.prototype.getAllStockByOrder = function () {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'stock/getAllStockList', this.httpOptions);
    };
    StockService.prototype.getStockByLikeName = function (eve) {
        var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpParams"]().set('searchParam', eve);
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'stock/getstockbysearch', { params: params });
    };
    StockService.prototype.getStockbyId = function (id) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'stock/getstockdetail/' + id, this.httpOptions);
    };
    StockService.prototype.getSalesStockDetailsById = function (id) {
        return this.http.get(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'stock/getsalesstockbydetails/' + id, this.httpOptions);
    };
    StockService.prototype.updateStock = function (res) {
        return this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl + 'stock/updatestock/' + res.id, res, this.httpOptions);
    };
    StockService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]])
    ], StockService);
    return StockService;
}());



/***/ }),

/***/ "./src/app/services/userservice/user.service.ts":
/*!******************************************************!*\
  !*** ./src/app/services/userservice/user.service.ts ***!
  \******************************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @auth0/angular-jwt */ "./node_modules/@auth0/angular-jwt/index.js");
/* harmony import */ var _constants_auth_constants_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../constants/auth-constants.service */ "./src/app/services/constants/auth-constants.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var UserService = /** @class */ (function () {
    function UserService() {
        this.jwtHelper = new _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_0__["JwtHelperService"]();
        this.accessToken = null;
    }
    UserService.prototype.getAccessToken = function () {
        return localStorage.getItem(_constants_auth_constants_service__WEBPACK_IMPORTED_MODULE_1__["TOKEN_NAME"]);
    };
    UserService.prototype.login = function (accessToken) {
        var decodedToken = this.jwtHelper.decodeToken(accessToken);
        console.log(decodedToken);
        this.isAdmin = decodedToken.authorities.some(function (el) { return el === 'ADMIN'; });
        this.accessToken = accessToken;
        localStorage.setItem(_constants_auth_constants_service__WEBPACK_IMPORTED_MODULE_1__["TOKEN_NAME"], accessToken);
    };
    UserService.prototype.logout = function () {
        this.accessToken = null;
        this.isAdmin = false;
        localStorage.removeItem(_constants_auth_constants_service__WEBPACK_IMPORTED_MODULE_1__["TOKEN_NAME"]);
    };
    UserService.prototype.isAdminUser = function () {
        return this.isAdmin;
    };
    UserService.prototype.isUser = function () {
        console.log(this.accessToken != null);
        return this.accessToken != null;
    };
    UserService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/app/utils/color.ts":
/*!********************************!*\
  !*** ./src/app/utils/color.ts ***!
  \********************************/
/*! exports provided: colors */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colors", function() { return colors; });
var colors = {
    red: {
        primary: '#ad2121',
        secondary: '#FAE3E3'
    },
    blue: {
        primary: '#1e90ff',
        secondary: '#D1E8FF'
    },
    yellow: {
        primary: '#e3bc08',
        secondary: '#FDF1BA'
    }
};


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    apiUrl: 'http://localhost:8082/'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Basics\C\pointers\saaolheartUI\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map